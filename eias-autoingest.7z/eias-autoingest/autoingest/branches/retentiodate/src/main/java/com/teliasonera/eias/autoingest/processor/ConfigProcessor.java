package com.teliasonera.eias.autoingest.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.processor.exception.XMLProcessingException;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

/**
 * Append configuration info to the message header to be used in following
 * processing steps
 * 
 * @author sce4799
 */

@Component
@Scope("prototype")
public class ConfigProcessor implements Processor {

    public static final String XML_VALIDATION = "doXmlValidation";
    public static final String CONTENT_ONLY_XML_VALIDATION = "doContentOnlyXmlValidation";
    public static final String XML_TRANSFORM = "doXmlTransform";
    public static final String CONTENT_FILE_LINKING = "doContentfileLinking";

    private RouteType config;

    public ConfigProcessor() {
    }

    public void setConfig(RouteType config) {
        this.config = config;
    }

    @Override
    public void process(Exchange exc) throws XMLProcessingException {
        final Logger LOG = LoggerFactory.getLogger(ConfigProcessor.class);
        Message msg = exc.getIn();
        // Add XML processing instructions
        msg.getHeaders().put(XML_VALIDATION, this.config.getIncomingXmlValidation().isExecute());
        msg.getHeaders().put(XML_TRANSFORM, this.config.getIncomingXmlTransform().isExecute());
        msg.getHeaders().put(CONTENT_FILE_LINKING, this.config.getContentfileLinking().isEnabled()); 
        if(this.config.isContentOnlyXmlValidation() != null) {
        	msg.getHeaders().put(CONTENT_ONLY_XML_VALIDATION, this.config.isContentOnlyXmlValidation());
        }
        else {
        	msg.getHeaders().put(CONTENT_ONLY_XML_VALIDATION, false);
        }
        LOG.debug("Added XML processing instructions..");
        LOG.debug("XML Validation.."+this.config.getIncomingXmlValidation().isExecute());
        LOG.debug("XML Transformation.."+this.config.getIncomingXmlTransform().isExecute());
    }

}

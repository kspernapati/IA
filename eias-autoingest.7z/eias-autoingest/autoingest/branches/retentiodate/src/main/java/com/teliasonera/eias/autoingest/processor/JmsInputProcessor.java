package com.teliasonera.eias.autoingest.processor;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.processor.exception.IARestException;

/**
 * Map attributes that need to be preserved from input message headers to
 * Exchange properties
 * 
 * @author sce4799
 *
 */

@Component
@Scope("prototype")
public class JmsInputProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(JmsInputProcessor.class);
	
	@Autowired
	private IngestMessageStore messageStore;

	public JmsInputProcessor() {}

	@Override
	public void process(Exchange exc) throws Exception {

		Message msg = exc.getIn();
		
		// Store the original message in case it is needed to be put in the reingest queue
		// Message will stay in the store for the duration of the ingest route handling
		this.messageStore.put(exc.getExchangeId(), cloneMessage(msg));
		
		LOG.debug("IngestMessageStore size: " + this.messageStore.size());
		
		exc.setProperty(IAConstants.IA_APP_NAME, msg.getHeader(IAConstants.IA_APP_NAME));
		exc.setProperty(IAConstants.IA_TENANT_NAME, msg.getHeader(IAConstants.IA_TENANT_NAME));
		exc.setProperty(IAConstants.IA_USERNAME, msg.getHeader(IAConstants.IA_USERNAME));
		exc.setProperty(IAConstants.IA_PASSWORD, msg.getHeader(IAConstants.IA_PASSWORD));
		// Store original exchange id as it is used as key in the message store
		exc.setProperty(IAConstants.IA_ORIG_EXCHANGE_ID, exc.getExchangeId());	
	}

	private static Map<String, Object> cloneMessage(Message in) throws IARestException {
		
		Map<String, Object> msgDetails = new HashMap<>();
		
		// Take a full clone of the original message. Otherwise content will not be preserved in processing
		
		Map<String, Object> origHeaders = in.getHeaders();
		Map<String, Object> headers = new HashMap<>();
		
		for(String s : origHeaders.keySet()) {
			headers.put(s, origHeaders.get(s));
		}
		
		InputStream body = in.getBody(InputStream.class);
		
		msgDetails.put("headers", headers);
		msgDetails.put("body", body);
		
		return msgDetails;
	}
}

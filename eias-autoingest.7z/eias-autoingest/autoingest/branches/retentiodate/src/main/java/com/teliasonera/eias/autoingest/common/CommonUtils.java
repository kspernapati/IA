package com.teliasonera.eias.autoingest.common;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FileFileFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.teliasonera.eias.autoingest.routeconfig.CamelUriType;
import com.teliasonera.eias.autoingest.routeconfig.OptionType;

/**
 * Collection of common utility methods
 * 
 * @author sce4799
 */

public class CommonUtils {
	
	public static final Logger LOG = LoggerFactory.getLogger(CommonUtils.class);
	
	public static final String EAS_XMLNS = "http://eas.documentum.emc.com/webservice/ingest";

	public static final int SIP_ID_LENGTH = 32;

	public static final Pattern STRIP_ACCENTS_PATTERN; // Pattern strips accents from characters, replacing with the base char
	public static final Pattern REMOVE_SPECIALS_PATTERN; // Remove all special characters
	public static final Pattern IA_FILENAME_PATTERN; // This pattern is used by EAS-GUI to validate file names in IA 3.2  P08

	static {
		STRIP_ACCENTS_PATTERN = Pattern.compile("[\\p{InCombiningDiacriticalMarks}]");
		REMOVE_SPECIALS_PATTERN = Pattern.compile("[^\\w,\\s-\\.]");
		IA_FILENAME_PATTERN = Pattern.compile("^[\\w,\\s-\\.]+$");
	}

	/**
	 * Build the generic Camel URI to be used in camel endpoint definitions
	 * 
	 * @param scheduler
	 * @return
	 */

	public static final String getCamelURI(CamelUriType uriType) {

		StringBuffer uri = new StringBuffer();

		uri.append(uriType.getType());
		uri.append(':');
		uri.append(uriType.getName());

		if (uriType.getOptions() != null) {
			uri.append(buildOptions(uriType.getOptions().getOption()));
		}

		return uri.toString();
	}

	/**
	 * Generate (unique) SIP package ID. Uniqueness is guaranteed only if UUID is used in the pattern. Supports String.format type formatting
	 * language. The string "%%UUID%% is replaced with the unique identifier if supported in the pattern.
	 * 
	 * @param pattern
	 * @return
	 */

	public static final String getSipID(String pattern) {
		Calendar c = Calendar.getInstance();
		String out = String.format(pattern, c);
		if (out.contains("%UUID%")) { // Generate UUID
			int uuidLen = SIP_ID_LENGTH - out.length() + 6;
			String uuid = Base64.encodeBase64URLSafeString(UUID.randomUUID().toString().getBytes());
			int beginIndex = uuid.length() - uuidLen;
			if (beginIndex < 0)
				beginIndex = 0;
			out = out.replaceAll("%UUID%", uuid.substring(beginIndex));
		}
		return out;
	}

	/**
	 * Return a scheduler start log message generated from message headers
	 * 
	 * @param jobName
	 * @param headers
	 * @return
	 */

	public static final String getSchedulerStartLogMessage(String jobName, Map<String, Object> headers) {
		StringBuilder out = new StringBuilder();
		SimpleDateFormat fmt = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		out.append("Job " + jobName + " started at: ");
		out.append(fmt.format((Date) headers.get("fireTime")));
		return out.toString();
	}

	/**
	 * Return a scheduler finished log message generated from message headers
	 * 
	 * @param jobName
	 * @param headers
	 * @return
	 */

	public static final String getSchedulerFinishedLogMessage(String jobName, Map<String, Object> headers) {

		StringBuilder out = new StringBuilder();

		SimpleDateFormat fmt = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

		out.append("Job " + jobName + " finished. ");
		// out.append("Execution time was ");
		// out.append(((long) headers.get("jobRunTime")) / 1000);
		// out.append(" sec. ");
		out.append("Next job execution is scheduled at ");
		out.append(fmt.format((Date) headers.get("nextFireTime")));

		return out.toString();

	}

	/**
	 * Converts a string (file name) to the format required by EAS-GUI 3.2 P08. Any accented chars or special chars in the file name cause the export
	 * from EAS-GUI to fail. For that reason file names need to be "normalized"
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */

	public static final String getIACompliantFileName(String fileName) throws ConversionException {

		// Normalize filename string
		fileName = Normalizer.normalize(fileName, Normalizer.Form.NFD);
		Matcher m = STRIP_ACCENTS_PATTERN.matcher(fileName);
		fileName = m.replaceAll("");

		Matcher m2 = REMOVE_SPECIALS_PATTERN.matcher(fileName);
		fileName = m2.replaceAll("_");

		// Validate result against IA pattern
		Matcher ia = IA_FILENAME_PATTERN.matcher(fileName);
		
		if (!ia.matches()) {
			throw new ConversionException(
					"Could not convert file name into IA compatible form. Result \"" + fileName + "\" doesn't match the required pattern!");
		}

		return fileName;
	}

	/**
	 * Recursively delete all EMPTY subdirs under the parent directory
	 * 
	 * @param parent
	 */
	
	public static final boolean cleanEmptySubdirs(File parent) throws IOException {
		
		if(!parent.isDirectory()) {
			throw new IllegalArgumentException("Error deleting folders: Parent path is not a directory!");
		}
		
		LOG.debug("CLEANUP: Dir is: " + parent.getPath());
		
		File[] files = parent.listFiles((FileFilter) FileFileFilter.FILE);
		File[] dirs = parent.listFiles((FileFilter) DirectoryFileFilter.DIRECTORY);
		
		LOG.debug("CLEANUP: Subdirs are: " + arrayToString(dirs));
		LOG.debug("CLEANUP: Files are: " + arrayToString(files));
		
		boolean canDelete = true;
		
		// Check subdirs first, recursively
		for(File f : dirs) {
			boolean isEmpty = cleanEmptySubdirs(f);
			if(isEmpty) {
				LOG.debug("CLEANUP: Directory " + f.getPath() + " is empty, deleting it");
				FileUtils.deleteDirectory(f);
			}
			else {
				LOG.debug("CLEANUP: Directory " + f.getPath() + " or one of the subdirs contains files, can't delete!");
				canDelete = false;	// If subdir has files, can't delete this one either
			}
		}
		
		// Check if this dir has files. If yes, can't delete
		// If subdir contains files, can't delete either
		if(files.length == 0) {
			LOG.debug("CLEANUP: Directory " + parent.getPath() + " is empty, it can be deleted");
			return canDelete;	// Propagate subdir deletion status
		}
		
		LOG.debug("CLEANUP: Directory " + parent.getPath() + " is not empty, it can't be deleted");
		return false;	// This or one of the subdirs has files, don't delete
	}
	
	private static final String arrayToString (File[] array) {
		StringBuilder bldr = new StringBuilder();
		bldr.append("[");
		for(File f : array) {
			bldr.append(f.getPath());
			bldr.append(", ");
		}
		bldr.append("]");
		return bldr.toString();
	}
	
	// =================== Private utilities ====================

	/**
	 * Build URI options
	 * 
	 * @param options
	 * @return
	 */

	private static final String buildOptions(List<OptionType> options) {

		StringBuilder opt = new StringBuilder();

		boolean isFirst = true;

		for (OptionType o : options) {
			if (isFirst) {
				opt.append('?');
				opt.append(o.getName());
				opt.append('=');
				opt.append(o.getValue());
				isFirst = false;
			} else {
				opt.append('&');
				opt.append(o.getName());
				opt.append('=');
				opt.append(o.getValue());
			}
		}

		return opt.toString();
	}

}

package com.teliasonera.eias.autoingest.processor;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Message;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.ContentDisposition;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;

/**
 * The AggregationStrategy is responsible of combining the original exchange containing the
 * SIP packet to be ingested as attachment with the IA-specific information that will be
 * queried separately from InfoArchive.
 * 
 * Aggregation can be guaranteed (by the route design) to be called exactly 2 times
 * 
 * @author sce4799
 *
 */

@Component
@Scope("prototype")
public class ReceiveSipAggregationStrategy implements AggregationStrategy {

	private static enum Params {
		FORMAT,
		FILENAME,
		FILE,
		ACCESSTOKEN,
		APP_ID;
	}

	private static final Logger LOG = LoggerFactory.getLogger(ReceiveSipAggregationStrategy.class);

	public ReceiveSipAggregationStrategy() {}

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

		if(oldExchange == null) {  // This is the first aggregation round
			LOG.debug("Aggregation called with oldExchange == null");
			return this.processFirstRound(newExchange);
		}

		LOG.debug("Aggregation called with two non-null parameters");

		return this.processSecondRound(oldExchange, newExchange);
	}

	/**
	 * Build the Multipart message body that is needed to send the SIP file for ingestion
	 * 
	 * @param params
	 * @return
	 */

	private MultipartBody buildMultipart(Map<Params, Object> params) {

		// Set headers for the Format part. This needs to be done manually to get it correct

		MultivaluedMap<String, String> hdr1 = new MultivaluedHashMap<>();

		hdr1.add("Content-Disposition", "form-data; name=format");
		hdr1.add("Content-Type", MediaType.TEXT_PLAIN);
		hdr1.add("Content-ID", "format");

		List<Attachment> attachments = new ArrayList<>();

		Attachment formdata = new Attachment(hdr1, params.get(Params.FORMAT));
		Attachment file = new Attachment("sip", (InputStream) params.get(Params.FILE), new ContentDisposition("form-data; name=sip; filename=" + params.get(Params.FILENAME)));

		attachments.add(formdata);
		attachments.add(file);

		return new MultipartBody(attachments);
	}

	/**
	 * Process the first round of aggregation
	 * 
	 * @param exchange
	 * @return
	 * @throws Exception
	 */

	private Exchange processFirstRound(Exchange exchange) {

		Message msg = null;
		if(exchange.hasOut())
			msg = exchange.getOut();
		else
			msg = exchange.getIn();

		Map<Params, Object> params = new HashMap<>();

		if(exchange.getProperty(IAConstants.IA_APP_UUID) == null) {	// This is the original message with the SIP file in body
			// Get the file attachment and set to the new message body
			params.put(Params.FORMAT, IAConstants.IA_SIP_FORMAT);
			params.put(Params.FILENAME, msg.getHeader(Exchange.FILE_NAME));
			params.put(Params.FILE, msg.getBody(InputStream.class));
			// Store the file name in exchange property for recovery purposes
			exchange.setProperty(Exchange.FILE_NAME, msg.getHeader(Exchange.FILE_NAME));
		}
		else {	// The exchange is the result from the IA application query
			params.put(Params.ACCESSTOKEN, exchange.getProperty(IAConstants.IA_TOKEN_TYPE) + " " + exchange.getProperty(IAConstants.IA_ACCESS_TOKEN));
			params.put(Params.APP_ID, exchange.getProperty(IAConstants.IA_APP_UUID));
		}

		msg.setBody(params);

		return exchange;
	}
	
	/**
	 * Process the second round of aggregation, with two non-null inputs
	 * 
	 * @param oldExchange
	 * @param newExchange
	 * @return
	 */

	private Exchange processSecondRound(Exchange oldExchange, Exchange newExchange) {
		// From here on can assume we're processing the second round of aggregation
		// Copy previously set properties from old exchange

		Message oldMsg = null;
		if(oldExchange.hasOut())
			oldMsg = oldExchange.getOut();
		else
			oldMsg = oldExchange.getIn();
		
		Message newMsg = null;
		if(newExchange.hasOut())
			newMsg = newExchange.getOut();
		else
			newMsg = newExchange.getIn();

		@SuppressWarnings("unchecked")
		Map<Params, Object> params = (Map<Params, Object>) oldMsg.getBody();

		// We want the returned exchange to be based on the one received from the REST query track:

		// The old exchange contains SIP package attachment.
		// Can safely assume that the new exchange is the one containing REST API info
		if(oldExchange.getProperty(IAConstants.IA_APP_UUID) == null) { 
			LOG.debug("SIP package message was received first...");

			params.put(Params.ACCESSTOKEN, newExchange.getProperty(IAConstants.IA_TOKEN_TYPE) + " " + newExchange.getProperty(IAConstants.IA_ACCESS_TOKEN));
			params.put(Params.APP_ID, newExchange.getProperty(IAConstants.IA_APP_UUID));

			newMsg.setHeader(CxfConstants.OPERATION_NAME, "receiveAip");
			newMsg.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.FALSE);
			newMsg.setHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);

			// Store the file name in exchange property for recovery purposes
			newExchange.setProperty(Exchange.FILE_NAME, oldExchange.getProperty(Exchange.FILE_NAME));

			// REST params are passed in Object[]
			Object[] newBody = new Object[] {params.get(Params.ACCESSTOKEN), params.get(Params.APP_ID), buildMultipart(params)};

			newMsg.setBody(newBody);

			newExchange.setPattern(ExchangePattern.InOut);

			return newExchange;
		}
		else {	// Things are the other way around... new exchange contains the SIP attachment
			LOG.debug("REST query results were received first...");

			params.put(Params.FORMAT, IAConstants.IA_SIP_FORMAT);
			params.put(Params.FILENAME, newMsg.getHeader(Exchange.FILE_NAME));
			params.put(Params.FILE, newMsg.getBody(InputStream.class));	// body already points to the old exchange...
			// Store the file name in exchange property for recovery purposes
			oldExchange.setProperty(Exchange.FILE_NAME, newMsg.getHeader(Exchange.FILE_NAME));

			oldMsg.setHeader(CxfConstants.OPERATION_NAME, "receiveAip");
			oldMsg.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.FALSE);
			oldMsg.setHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);

			// REST params are passed in Object[]
			Object[] newBody = new Object[] {params.get(Params.ACCESSTOKEN), params.get(Params.APP_ID), buildMultipart(params)};

			oldMsg.setBody(newBody);

			oldExchange.setPattern(ExchangePattern.InOut);

			return oldExchange;
		}
	}
}

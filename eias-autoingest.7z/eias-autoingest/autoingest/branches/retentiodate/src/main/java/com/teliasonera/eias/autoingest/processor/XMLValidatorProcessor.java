package com.teliasonera.eias.autoingest.processor;

import java.io.File;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.xml.XMLValidator;
import com.teliasonera.eias.autoingest.processor.exception.XMLValidationException;

/**
 * Wrapper bean to provide Camel POJO access to the XML validator
 * 
 * @author sce4799
 */

@Component
@Scope("prototype")
public class XMLValidatorProcessor implements Processor {

	@Autowired
	private XMLValidator validator;

	private File schema;

	/**
	 * Constructor
	 */

	private XMLValidatorProcessor() {
	}

	public void setSchema(File schema) {
		this.schema = schema;
	}

	@Override
	public void process(Exchange exc) throws Exception {

		try {
			this.validator.validate(this.schema, exc.getIn().getBody(File.class));
		} catch (Exception e) {
			throw new XMLValidationException(
					"XML validation failed for file " + exc.getIn().getHeader("CamelFileNameOnly"), e);
		}
	}
}

package com.teliasonera.eias.autoingest.beans.sip;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.PrefixFileFilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.teliasonera.eias.autoingest.beans.xml.XPathQueryUtil;
import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.routeconfig.ContentLinkType;
import com.teliasonera.eias.autoingest.routeconfig.LinkType;

import net.sf.saxon.tree.tiny.TinyElementImpl;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

/**
 * ContentFileLinker will generate one common XML element in the metadata XML (PDI)
 * according to commonly agreed format and parameters.
 * 
 * Will also verify that the content file names agree to EMC requirements if 
 * <code>renameFiles</code> is set to <code>true</code>
 * 
 * @author sce4799
 *
 */

@Component
@Scope("prototype")
public class ContentFileLinker {

    private static final Logger LOG = LoggerFactory.getLogger(ContentFileLinker.class);

    private static final String DEFAULT_MIME_TYPE = "application/octet-stream";
    private static final SimpleDateFormat XML_DATE_TIME;

    static {
        XML_DATE_TIME = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
    }

    @Autowired
    private XPathQueryUtil xpUtil;

    private File workDir;
    private String metaExtension;
    private boolean renameFiles;

    /**
     * Restricted constructor
     */

    private ContentFileLinker() {
        // Default values
        this.renameFiles = false;
        this.metaExtension = "xml";
    }

    // Setters

    /**
     * Set the working directory
     * 
     * @param workDir
     */

    public void setWorkDir(File workDir) {
        this.workDir = workDir;
    }

    /**
     * Set the file extension of the metadata file. Defaults to "xml". Needed
     * only if file name linking is used to identify content files.
     * 
     * @param metaExtension
     */

    public void setMetaExtension(String metaExtension) {
        this.metaExtension = metaExtension;
    }

    /**
     * If renameFiles is set to <code>true</code> files are renamed to IA
     * compliant form. If file names are not validated against EAS-GUI
     * requirement, exporting them from the archive may fail! This is a
     * requirement by EAS-GUI 3.2 P08 and earlier, may be fixed by EMC in later
     * versions.
     * 
     * @param renameFiles
     */

    public void setRenameFiles(boolean renameFiles) {
        this.renameFiles = renameFiles;
    }

    /**
     * Link all content files referred to in the XML input file properly to the
     * same XML, using common format and parameters
     * 
     * @param xml
     * @param links
     * @return
     * @throws IOException
     * @throws JDOMException
     * @throws XPathExpressionException
     * @throws FileNotFoundException
     */

    public OutputStream linkContentFiles(InputStream xml, String xmlName, List<ContentLinkType> links) throws ContentFileLinkerException {
        
        // InputStream is used more than once, need to "clone" it via
        // ByteArrayOutputStream
        ByteArrayOutputStream tmpOut = null;

        try {
            tmpOut = getBytes(xml);
            // Build the XML document
            SAXBuilder builder = new SAXBuilder();
            Document doc = builder.build(new ByteArrayInputStream(tmpOut.toByteArray()));

            // Get content files from the XML
            Map<File, Boolean> files = this.listContentFiles(new ByteArrayInputStream(tmpOut.toByteArray()), xmlName, links);

            LOG.debug("Returned files: " + files);
            // Check validity of returned files. Only one main file link allowed
            boolean mainLinkFound = false;
            for (File f : files.keySet()) {
                boolean isAttachment = files.get(f);
                if (mainLinkFound && !isAttachment) {
                    IOUtils.closeQuietly(tmpOut);
                    throw new ContentFileLinkerException("More than one main content file link specified in metadata file " + xmlName
                                                         + ". Only one main content file link is allowed!");
                }
                if (!isAttachment)
                    mainLinkFound = true;
            }

            // Create the content files element in the XML root
            Element root = doc.getRootElement();
            Element contentFiles = new Element("contentFiles", root.getNamespace());
            root.addContent(contentFiles);

            // For each content file linked, create the contentFile element
            for (File f : files.keySet()) {

                // Get file details first
                LOG.debug("Linking content file: " + f.getAbsolutePath());

                Path path = Paths.get(f.getAbsolutePath());
                String mimeType = Files.probeContentType(path);
                FileTime timeStamp = Files.getLastModifiedTime(path);
                Date date = new Date(timeStamp.toMillis());
                Boolean isAttachment = files.get(f);

                if (mimeType == null)
                    mimeType = DEFAULT_MIME_TYPE;

                // Build XML elements
                Element e1 = new Element("contentFile", root.getNamespace());

                // Add attribute attachment="true" if the file is an attachment. Attribute
                // is omitted for the main file
                // if there is only one file linked. This is then automatically the main
                // file.
                if (files.size() > 1) {
                    e1.setAttribute("attachment", isAttachment.toString());
                }

                // Original file name is preserved in this element regardless of the
                // rename option
                Element e2 = new Element("filename", root.getNamespace());
                e2.addContent(f.getName());

                // Element that contains file name details
                Element e3 = new Element("file", root.getNamespace());

                e3.setAttribute(new Attribute("format", FilenameUtils.getExtension(f.getName())));
                e3.setAttribute(new Attribute("mime_type", mimeType));
                e3.setAttribute(new Attribute("file_size", new Long(f.length()).toString()));

                // File renaming is required by EAS-GUI limitation to export file names
                // with accented chars or special chars
                // To mitigate this issue, files are renamed to conforming format if
                // enabled.
                if (this.renameFiles) { // Files are renamed to IA compliant format

                    String name = CommonUtils.getIACompliantFileName(f.getName());
                    e3.addContent(name);

                    if (!f.getName().equals(name)) { // Rename file if the name has
                                                         // changed
                        FileUtils.moveFile(f, new File(f.getParentFile(), name));
                        LOG.info("Content file " + f.getAbsolutePath() + " has been renamed to: " + name);
                    }
                } else { // Use original file name
                    e3.addContent(f.getName());
                }

                // File modification timestamp
                Element e4 = new Element("lastModified", root.getNamespace());
                e4.addContent(XML_DATE_TIME.format(date));

                // Add elements to content file list
                e1.addContent(e2);
                e1.addContent(e3);
                e1.addContent(e4);

                contentFiles.addContent(e1);
            }

            // Generate the output
            XMLOutputter output = new XMLOutputter(Format.getPrettyFormat());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            output.output(doc, out);

            xml.close();
            tmpOut.close();
            return out;
        } catch (Exception e) {
            throw new ContentFileLinkerException("Error occurred in ContentFileLinker" + e);
        } finally { // Ensure the resources are closed
            IOUtils.closeQuietly(xml, tmpOut);
        }
    }

    /**
     * List all content files linked in the metadata XML
     * 
     * @param xml
     * @param links
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     * @throws XPathExpressionException
     */

    private Map<File, Boolean> listContentFiles(InputStream xml, String xmlName, List<ContentLinkType> links) throws ContentFileLinkerException {
        LOG.debug("Listing content files..");
        Map<File, Boolean> contentFiles = new HashMap<>();

        // Allow only one linke of FILENAME type
        boolean filenameLinkFound = false;

        ByteArrayOutputStream tmpOut = new ByteArrayOutputStream();
        try {
            // Copy the stream to be able to use multiple times
            IOUtils.copy(xml, tmpOut);
            for (ContentLinkType link : links) {
                // Check link validity
                if (filenameLinkFound){
                    throw new ContentFileLinkerException("More than one content file link of type FILENAME found! [" + link.getXpath()
                    + "]. Only one link of this type is allowed in route configuration!");                    
                }
                    
                // Process by link type
                if (link.getType().equals(LinkType.FILENAME)) {
                    LOG.debug("FileName content linking specified");
                    // List files in the incoming dir that begin with the base filename
                    String baseName = FilenameUtils.removeExtension(xmlName);
                    Collection<File> files = FileUtils.listFiles(this.workDir, new PrefixFileFilter(baseName), null);

                    // Link file(s) with extension NOT matching 'XML' or what is defined
                    // in the configuration, to the work dir.
                    // This should only match one file in normal case. If this is not the
                    // case, the filename linking should not be used.
                    // All files with the same base name are moved because there is no way
                    // to make the distinction.
                    // Instead use XPATH linking that supports multiple content files /
                    // one metadata file
                    // Also excludes the Camel lock files for the metadata files
                    for (File f : files) {
                        String ext = FilenameUtils.getExtension(f.getName());

                        if (!ext.toLowerCase().contains(this.metaExtension.toLowerCase()) && !ext.toLowerCase().contains("lock")) {
                            contentFiles.put(f, new Boolean(link.isAttachment()));
                        }
                    }

                    filenameLinkFound = true;
                } else if (link.getType().equals(LinkType.XPATH)) {
                    LOG.debug("XPATH content link specified: " + link.getXpath());

                    // Get content file names from the metadata XML file
                    @SuppressWarnings("unchecked")
                    List<TinyElementImpl> names = (List<TinyElementImpl>)this.xpUtil.queryDocument(new ByteArrayInputStream(tmpOut.toByteArray()), link.getXpath(),
                                                                                                   XPathConstants.NODESET);
                    for (TinyElementImpl name : names) {
                        File f = new File(this.workDir, name.getStringValue());
                        contentFiles.put(f, new Boolean(link.isAttachment()));
                    }
                } else {
                    LOG.error("Unknown content file link type specified!");
                }
            }
        } catch (Exception e) {
            throw new ContentFileLinkerException("Error occurred in ContentFileLinker" + e);
        } finally {
            IOUtils.closeQuietly(tmpOut, xml);
        }

        return contentFiles;
    }

    /**
     * Read bytes from the InputStream and place them in the output (in memory)
     * 
     * @param in
     * @return
     * @throws IOException
     */

    private static ByteArrayOutputStream getBytes(InputStream in) throws ContentFileLinkerException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] buffer = new byte[1024];
            int len;

            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
            out.flush();
        } catch (IOException e) {
            throw new ContentFileLinkerException("Error occurred while reading Inputstream in ContentFileLinker" + e);
        }
        return out;
    }
}

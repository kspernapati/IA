package com.teliasonera.eias.autoingest.beans.email.notifytmpl;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
@Qualifier("notifyRouteErrorTemplBean")
public class NotifyRouteErrorTempl extends NotifyErrorTempl {

	public String runtimeHeaders;
	public String intRouteName;

	/**
	 * getRuntimeHeaders to get the value of runtimeHeaders
	 * 
	 * @return the runtimeHeaders
	 */
	public String getRuntimeHeaders() {
		return runtimeHeaders;
	}

	/**
	 * setRuntimeHeaders to set the value of runtimeHeaders
	 * 
	 * @param runtimeHeaders
	 *            the runtimeHeaders to set
	 */
	public void setRuntimeHeaders(String runtimeHeaders) {
		this.runtimeHeaders = runtimeHeaders;
	}

	/**
	 * getIntRouteName to get the value of intRouteName
	 * 
	 * @return the intRouteName
	 */
	public String getIntRouteName() {
		return intRouteName;
	}

	/**
	 * setIntRouteName to set the value of intRouteName
	 * 
	 * @param intRouteName
	 *            the intRouteName to set
	 */
	public void setIntRouteName(String intRouteName) {
		this.intRouteName = intRouteName;
	}

}

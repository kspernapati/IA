package com.teliasonera.eias.autoingest.processor;

import javax.ws.rs.core.MediaType;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;

/**
 * Input exchange is the result of the LoginToken request. Do necessary
 * processing and request the Tenant Info from the REST API
 * 
 * @author sce4799
 *
 */

@Component
@Scope("prototype")
public class TenantInfoRequestProcessor implements Processor {

	public TenantInfoRequestProcessor() {}
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		// Get the outbound message, this will be modified
		Message msg = exchange.getIn();
		
		msg.setHeader(CxfConstants.OPERATION_NAME, "getTenantInfo");
		msg.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.FALSE);
		msg.setHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);
		
		msg.setBody(new Object[] {exchange.getProperty(IAConstants.IA_TOKEN_TYPE) + " " + exchange.getProperty(IAConstants.IA_ACCESS_TOKEN)});
	}
}

package com.teliasonera.eias.autoingest.processor.exception;

public class XMLValidationException extends XMLProcessingException {

    private static final long serialVersionUID = -1469966432664087146L;

    public XMLValidationException() {
    }

    public XMLValidationException(String message) {
        super(message);
    }

    public XMLValidationException(Throwable cause) {
        super(cause);
    }

    public XMLValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public XMLValidationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

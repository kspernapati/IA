package com.teliasonera.eias.autoingest.beans.sip;

public class ContentFileLinkerException extends Exception {

    private static final long serialVersionUID = 6792918519817486646L;

    public ContentFileLinkerException() {
    }

    public ContentFileLinkerException(String message) {
        super(message);
    }

    public ContentFileLinkerException(Throwable cause) {
        super(cause);
    }

    public ContentFileLinkerException(String message, Throwable cause) {
        super(message, cause);
    }

    public ContentFileLinkerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

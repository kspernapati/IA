package com.teliasonera.eias.autoingest.processor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.xml.FileMetaAsXMLService;
import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.exception.FileMetadataExtractionException;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
public class FileMetadataProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(FileMetadataProcessor.class);
	
	@Autowired
	FileMetaAsXMLService fMetaService;
	
	private RouteType config;

	public void setConfig(RouteType config) {
		this.config = config;
	}

	@Override
	public void process(Exchange exchange) throws FileMetadataExtractionException {
		ByteArrayOutputStream xmlMetaOS = null;
		FileChannel fileChannel = null;
		try {
			String fileName = "";
			Message msg = exchange.getIn();
			
			LOG.debug("Generating file metadata... " + msg.getHeader(Exchange.FILE_NAME, String.class));
			
			// File renaming if enabled in config. This is done to solve the IA file name special char limitation in 
			// content-only use cases
			if(this.config.isContentOnlyRenameFiles() != null && this.config.isContentOnlyRenameFiles()) {
				String origName = msg.getHeader(Exchange.FILE_NAME_ONLY, String.class);
				fileName = CommonUtils.getIACompliantFileName(origName);
				xmlMetaOS = this.fMetaService.getMetainfoAsXMLStream(msg.getBody(File.class), new File(this.config.getContentOnlyFileEndpoint().getName()), msg.getHeader(Exchange.FILE_NAME, String.class), fileName);
				// Set overrule file name in headers, this will override whatever is set in other Camel headers
				msg.setHeader(Exchange.OVERRULE_FILE_NAME, fileName);
			}
			else {
				fileName = msg.getHeader(Exchange.FILE_NAME_ONLY, String.class);
				xmlMetaOS = this.fMetaService.getMetainfoAsXMLStream(msg.getBody(File.class), new File(this.config.getContentOnlyFileEndpoint().getName()), msg.getHeader(Exchange.FILE_NAME, String.class));
			}
			
			// Metadata file name will be FullFileName + Metafile extension All file names don't have 'common' file extension,
			// so can't assume to remove / replace it
			
//			String fileNameWithOutExt = FilenameUtils.removeExtension(fileName);
			String metaExtn = this.config.getMetadataFileExtension();
			String metafileName = FilenameUtils.normalizeNoEndSeparator(this.config.getIncomingFileEndpoint().getName()) + File.separator
					+ fileName + FilenameUtils.EXTENSION_SEPARATOR_STR + metaExtn;
			
			// Get exclusive lock to the metafile
			Path metafile = Paths.get(metafileName);
			fileChannel = FileChannel.open(metafile, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
			fileChannel.lock();
			
			// Write file to the channel
			ByteBuffer buf = ByteBuffer.wrap(xmlMetaOS.toByteArray());
			fileChannel.write(buf);
			
			fileChannel.close();
		} 
		catch (Exception e) {
			throw new FileMetadataExtractionException("Error occured while getting file metadata.", e);
		}
		finally {
			IOUtils.closeQuietly(xmlMetaOS);
			IOUtils.closeQuietly(fileChannel);
		}
	}

}

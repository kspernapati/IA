package com.teliasonera.eias.autoingest.beans.xml;

import java.io.File;
import java.net.URL;

import javax.xml.transform.Source;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

/**
 * Wrapper class for SchemaFactory, to provide thread-safety for
 * new schema initialization
 * 
 * @author sce4799
 *
 */

@Component
@Scope("singleton")
public class ConcurrentSchemaFactory {
	
	@Autowired
	private SchemaFactory factory;

	public ConcurrentSchemaFactory() {}

	public synchronized Schema newSchema() throws SAXException {
		return this.factory.newSchema();
	}
	
	public synchronized Schema newSchema(File schema) throws SAXException {
		return this.factory.newSchema(schema);
	}
	
	public synchronized Schema newSchema(Source schema) throws SAXException {
		return this.factory.newSchema(schema);
	}
	
	public synchronized Schema newSchema(Source[] schemas) throws SAXException {
		return this.factory.newSchema(schemas);
	}
	
	public synchronized Schema newSchema(URL schema) throws SAXException {
		return this.factory.newSchema(schema);
	}
}

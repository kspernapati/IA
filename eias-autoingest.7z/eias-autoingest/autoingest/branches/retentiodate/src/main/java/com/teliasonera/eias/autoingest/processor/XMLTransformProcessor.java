package com.teliasonera.eias.autoingest.processor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.OutputStream;
import java.nio.charset.Charset;

import javax.xml.transform.stream.StreamResult;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.xml.XMLTransformer;
import com.teliasonera.eias.autoingest.processor.exception.XMLTransformException;

@Component
@Scope("prototype")
public class XMLTransformProcessor implements Processor {

    @Autowired
    private XMLTransformer transform;

    private File xslt;

    public XMLTransformProcessor() {
    }

    public void setXslt(File xslt) {
        this.xslt = xslt;
    }

    @Override
    public void process(Exchange exc) throws Exception {

        try {
            // Transform the input
            StreamResult out = this.transform.transformXML(this.xslt, exc.getIn().getBody(File.class));
            // Add transformed XML to the exchange. No need to use setOut, Camel will use
            // the In message
            exc.getIn().setBody(streamToString(out.getOutputStream()));
        } catch (Exception e) {
            throw new XMLTransformException("XML transform failed for file " + exc.getIn().getHeader("CamelFileNameOnly"), e);
        }
    }

    /**
     * Convert the OutputStream to String while preserving the UTF-8 encoding
     * 
     * @param str
     * @return
     */

    private static String streamToString(OutputStream str) {
        ByteArrayOutputStream temp = (ByteArrayOutputStream)str;
        return new String(temp.toByteArray(), Charset.forName("UTF-8"));
    }
}

package com.teliasonera.eias.autoingest.restful;

import java.io.PrintWriter;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.message.Message;

/**
 * Apache CXF LoggingInInterceptor extension that only logs inbound messages with
 * HTTP response code greater than 207
 * 
 * @author sce4799
 *
 */

public class LoggingFaultInInterceptor extends LoggingInInterceptor {

	public LoggingFaultInInterceptor() {
		super();
	}

	public LoggingFaultInInterceptor(String phase) {
		super(phase);
	}

	public LoggingFaultInInterceptor(int lim) {
		super(lim);
	}

	public LoggingFaultInInterceptor(PrintWriter w) {
		super(w);
	}

	public LoggingFaultInInterceptor(String id, String phase) {
		super(id, phase);
	}

	public LoggingFaultInInterceptor(String id, int lim) {
		super(id, lim);
	}

	public LoggingFaultInInterceptor(String id, PrintWriter w) {
		super(id, w);
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		 // Determine HTTP response code from the message
		Integer responseCode = (Integer) message.get(Message.RESPONSE_CODE);
		
		// Log message only if it is a HTTP fault response
		if(responseCode != null && responseCode > 207) {
			super.handleMessage(message);
		}
	}
}

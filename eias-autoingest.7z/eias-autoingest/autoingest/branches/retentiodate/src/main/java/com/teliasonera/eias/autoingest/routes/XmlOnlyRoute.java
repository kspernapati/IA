package com.teliasonera.eias.autoingest.routes;

import org.apache.camel.LoggingLevel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.ConfigProcessor;
import com.teliasonera.eias.autoingest.processor.XMLMetadataProcessor;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
public class XmlOnlyRoute extends XmlContentRoute {
	
    @Autowired
	private XMLMetadataProcessor xMetaProcessor;
    
    public XmlOnlyRoute() {
    	super();
    }
    
    public XmlOnlyRoute(RouteType config) {
    	super(config);
    }

	/**
	 * Propagate {@link RouteConfig} to all the processors
	 */
	private void init() {
		this.xMetaProcessor.setConfig(config);
	}

	@Override
	public void configure() throws Exception {
		
		// Configure XML + Content route from superclass
		super.configure();
		
		// Initialize processors
 		init();
 		
 		// Route configuration
		from(CommonUtils.getCamelURI(this.config.getContentOnlyFileEndpoint())).id(this.config.getName() + "-XmlOnlyEndpoint") // fetch only the content files form the incoming dir
			.description(this.config.getName() + "-IncomingXML", "Incoming XML only processing", null)
			.threads(this.config.getReceiverThreadPoolSize())
			.process(this.configProcessor)
			.choice().id(this.config.getName() + "-DoContentOnlyXMLValidation") // Do XML validation if enabled in routeconfig
			.when(simple("${in.headers." + ConfigProcessor.CONTENT_ONLY_XML_VALIDATION + "}"))
				.log(LoggingLevel.DEBUG, "XML_VALIDATION enabled.Triggering Validation")
				.process(this.validator).id(this.config.getName() + "-IncomingXMLValidator") // Validate XML files
				.end()
			.process(this.xMetaProcessor).id(this.config.getName() + "-XmlMetadataProcessor") // get and copy the metadata file as well.		
			.to(CommonUtils.getCamelURI(this.config.getIncomingFileEndpoint())).id(this.config.getName() + "-XmlAndContentEndpoint"); // copy the file to the C+M processor
 	}
}

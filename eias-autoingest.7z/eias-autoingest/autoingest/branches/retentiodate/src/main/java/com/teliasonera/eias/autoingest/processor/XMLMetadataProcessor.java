package com.teliasonera.eias.autoingest.processor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.xml.XMLTransformer;
import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.exception.XMLMetadataExtractionException;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
public class XMLMetadataProcessor implements Processor {
	
	public static final String MIME_TYPE_XML = "text/xml";

	@Autowired
	private XMLTransformer transform;

	final Logger LOG = LoggerFactory.getLogger(XMLMetadataProcessor.class);
	private RouteType config;

	public void setConfig(RouteType config) {
		this.config = config;
	}

	@Override
	public void process(Exchange exchange) throws XMLMetadataExtractionException {
		
		ByteArrayOutputStream bStream = null;
		FileChannel fileChannel = null;
		
		try {
			String fileName = "";
			Message msg = exchange.getIn();
			
			File xmlFile = msg.getBody(File.class);
			
			// Put file properties to a map to be passed to the XML processor
			Map<String, String> params = new HashMap<>();
			
			// File renaming if enabled in config. This is done to solve the IA file name special char limitation in 
			// content-only use cases
			if(this.config.isContentOnlyRenameFiles() != null && this.config.isContentOnlyRenameFiles()) {
				String origName = msg.getHeader(Exchange.FILE_NAME_ONLY, String.class);
				fileName = CommonUtils.getIACompliantFileName(origName);
				// Set overrule file name in headers, this will override whatever is set in other Camel headers
				msg.setHeader(Exchange.OVERRULE_FILE_NAME, fileName);
				params.put("OBJECTNAME", origName);
			}
			else {
				fileName = msg.getHeader(Exchange.FILE_NAME_ONLY, String.class);
			}
			
			String metaExtn = this.config.getMetadataFileExtension();
			String fileNameWithOutExt = FilenameUtils.removeExtension(fileName);
			String metafileName = FilenameUtils.normalizeNoEndSeparator(this.config.getIncomingFileEndpoint().getName()) + File.separator + fileNameWithOutExt
					+ FilenameUtils.EXTENSION_SEPARATOR_STR + metaExtn;

			params.put("FILENAME", fileName);
			params.put("FORMAT", FilenameUtils.getExtension(fileName));
			params.put("SIZE", Long.toString(xmlFile.length()));
			params.put("MIMETYPE", MIME_TYPE_XML);

			StreamResult result = this.transform.transformXML(new StreamSource(new File(this.config.getIncomingXmlTransform().getFile())),
					new StreamSource(xmlFile), params);
			bStream = (ByteArrayOutputStream)result.getOutputStream();

			// Get exclusive FileLock on the file to be written. Prevents concurrent access
			Path metaFile = Paths.get(metafileName);
			fileChannel = FileChannel.open(metaFile, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
			// Getting lock...
			fileChannel.lock();
			
			// Write data to the channel
			ByteBuffer buf = ByteBuffer.wrap(bStream.toByteArray());
			fileChannel.write(buf);
			
			fileChannel.close();
			
			LOG.debug("Metadata file" + new File(metafileName).getAbsolutePath());
		} 
		catch (IOException e) {
			throw new XMLMetadataExtractionException("Error occured while getting file metadata.", e);
		} 
		catch (TransformerConfigurationException e) {
			throw new XMLMetadataExtractionException("TransformerConfigurationException Error occured ", e);
		} 
		catch (TransformerException e) {
			throw new XMLMetadataExtractionException("TransformerException Error occured ", e);
		}
		catch (Exception e) {
			throw new XMLMetadataExtractionException("Error during XML metadata extraction. ", e);
		}
		finally {
			IOUtils.closeQuietly(bStream);
			IOUtils.closeQuietly(fileChannel);
		}
	}

}

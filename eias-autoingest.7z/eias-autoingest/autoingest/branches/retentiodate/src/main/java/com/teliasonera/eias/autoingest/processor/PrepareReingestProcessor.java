package com.teliasonera.eias.autoingest.processor;

import java.io.InputStream;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;

@Component
@Scope("singleton")
public class PrepareReingestProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(PrepareReingestProcessor.class);
	
	@Autowired
	private IngestMessageStore messageStore;

	@Override
	public void process(Exchange exchange) throws Exception {
		
		// Retrieve original message from the message store and assign to the exchange
		// This will be sent to the ActiveMQ reingest queue
		
		String msgId = exchange.getProperty(IAConstants.IA_ORIG_EXCHANGE_ID, String.class);
		
		LOG.debug("Preparing message for re-ingestion...");
		LOG.debug("Original message ID is: " + msgId);
		
		Map<String, Object> origMsgDetails = this.messageStore.get(msgId);
		Message msg = exchange.getIn();
		
		prepareMessage(msg, origMsgDetails);
		
		this.messageStore.remove(msgId);
		LOG.debug("IngestMessageStore size: " + this.messageStore.size());
	}

	@SuppressWarnings("unchecked")
	private static void prepareMessage(Message msg, Map<String, Object> details) {
		msg.setHeaders((Map<String, Object>) details.get("headers"));
		LOG.debug("Setting headers: " + details.get("headers"));
		msg.setBody(details.get("body"));
		LOG.debug("Setting body: " + ((InputStream) details.get("body")).toString());
	}
}

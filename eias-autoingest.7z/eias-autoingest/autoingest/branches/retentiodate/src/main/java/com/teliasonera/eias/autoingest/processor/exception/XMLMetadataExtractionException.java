package com.teliasonera.eias.autoingest.processor.exception;

public class XMLMetadataExtractionException extends XMLProcessingException {

    private static final long serialVersionUID = -1469966432664087146L;

    public XMLMetadataExtractionException() {
    }

    public XMLMetadataExtractionException(String message) {
        super(message);
    }

    public XMLMetadataExtractionException(Throwable cause) {
        super(cause);
    }

    public XMLMetadataExtractionException(String message, Throwable cause) {
        super(message, cause);
    }

    public XMLMetadataExtractionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

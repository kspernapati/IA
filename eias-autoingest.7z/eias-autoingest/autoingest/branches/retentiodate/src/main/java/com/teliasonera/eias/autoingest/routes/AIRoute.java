package com.teliasonera.eias.autoingest.routes;

import org.apache.camel.spring.SpringRouteBuilder;

import com.teliasonera.eias.autoingest.routeconfig.RouteType;

/**
 * Superclass for EIAS specific Camel routes, enables dynamically setting up
 * routes. 
 * 
 * @author sce4799
 */

public abstract class AIRoute extends SpringRouteBuilder {
	
    protected RouteType config;

    public AIRoute(RouteType config) {
        super();
        this.config = config;
    }

    public AIRoute() {

    }

    public RouteType getConfig() {
        return config;
    }

    public void setConfig(RouteType config) {
        this.config = config;
    }

    @Override
    public abstract void configure() throws Exception;
}

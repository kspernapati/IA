package com.teliasonera.eias.autoingest.processor;

import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.IOUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * ConcurrentHashMap bean to be used as ingest message store.
 * Used for storing the original IngestQueue JMS message so
 * that it can be put to the ReIngestQueue as-is if needed.
 * 
 * @author sce4799
 *
 */

@Component
@Scope("singleton")
public class IngestMessageStore extends ConcurrentHashMap<String, Map<String, Object>> {

	private static final long serialVersionUID = 1L;

	@Override
	public Map<String, Object> remove(Object key) {
		
		// Close the InputStream contained in the details object to be removed
		Map<String, Object> obj = this.get(key);
		InputStream body = (InputStream) obj.get("body");
		IOUtils.closeQuietly(body);
		
		return super.remove(key);
	}
}

package com.teliasonera.eias.autoingest.processor.exception;

public class FileMetadataExtractionException extends XMLProcessingException {

    private static final long serialVersionUID = -1469966432664087146L;

    public FileMetadataExtractionException() {
    }

    public FileMetadataExtractionException(String message) {
        super(message);
    }

    public FileMetadataExtractionException(Throwable cause) {
        super(cause);
    }

    public FileMetadataExtractionException(String message, Throwable cause) {
        super(message, cause);
    }

    public FileMetadataExtractionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

package com.teliasonera.eias.autoingest.restful;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("")
public interface IALoginService {
	
	@POST
	@Path("/login")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAccessToken(
			@HeaderParam("Authorization") String authorization,
			@QueryParam("grant_type") String grantType,
			@QueryParam("username") String username,
			@QueryParam("password") String password);
	
	@POST
	@Path("/login")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAccessToken(
			@HeaderParam("Authorization") String authorization,
			@QueryParam("grant_type") String grantType,
			@QueryParam("username") String userName,
			@QueryParam("password") String password,
			@QueryParam("scope") String scope);

}

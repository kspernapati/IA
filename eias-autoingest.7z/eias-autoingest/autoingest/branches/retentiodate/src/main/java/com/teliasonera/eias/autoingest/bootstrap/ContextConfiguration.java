package com.teliasonera.eias.autoingest.bootstrap;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.transform.TransformerFactory;
import javax.xml.validation.SchemaFactory;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.activemq.store.PersistenceAdapter;
import org.apache.activemq.store.kahadb.KahaDBPersistenceAdapter;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.jaxrs.CxfRsEndpoint;
import org.apache.camel.component.metrics.routepolicy.MetricsRoutePolicyFactory;
import org.apache.camel.spring.javaconfig.CamelConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.xml.sax.SAXException;

import com.teliasonera.eias.autoingest.beans.routemgmt.AIRouteFactory;
import com.teliasonera.eias.autoingest.beans.routemgmt.RouteConfigManager;
import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.restful.LoggingFaultInInterceptor;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;
import com.teliasonera.eias.autoingest.routes.AIRoute;
import com.teliasonera.eias.autoingest.routes.IAIngestServiceRoute;
import com.teliasonera.eias.autoingest.routes.IAReingestQueueHandlerRoute;

import net.sf.saxon.lib.NamespaceConstant;
import net.sf.saxon.xpath.XPathFactoryImpl;

/**
 * class provides the different content configurations
 * 
 * @author exq6006
 */
@Configuration
@ComponentScan("com.teliasonera.eias.autoingest")
@PropertySources({ @PropertySource("classpath:/config/autoingest.properties") })
public class ContextConfiguration extends CamelConfiguration {

	private static final Logger LOG = LoggerFactory.getLogger(ContextConfiguration.class);
	
	@Value("${activemq.datadir:/tmp/activemq}")
	private String activemqDir;
	
	@Value("${camel.shutdown.timeout:600000}")
	private String camelShutdownTimeout;
	
	@Value("${executor.core.pool.size:5}")
	private String corePoolSize;
	
	@Value("${executor.max.pool.size:10}")
	private String maxPoolSize;
	
	@Autowired
	private RouteConfigManager routeMgr;
	
	@Autowired
	private AIRouteFactory routeFactory;
	
	// Static Camel routes are autowired as Spring beans...
	@Autowired
	private IAIngestServiceRoute ingestRoute;
	
	@Autowired
	private IAReingestQueueHandlerRoute restFailRoute;

	@Override
	public List<RouteBuilder> routes() {

		List<RouteBuilder> allRoutes = new ArrayList<RouteBuilder>();

		if (routeMgr.getRouteConfig() == null)	 {
			try {
				routeMgr.updateConfig();
			} 
			catch (FileNotFoundException | JAXBException | SAXException | URISyntaxException e1) {
				LOG.error("Problem loading Routes configuration from route config XML. Can not continue, EIAS will shutdown now.", e1);
				throw new IllegalStateException("Problem loading Routes configuration from route config XML. Can not continue, EIAS will shutdown now.", e1);
			}
		}
		
		// Dynamically create AutoIngest routes
		
		RouteConfig routeCfg = routeMgr.getRouteConfig();
		List<RouteType> routeTypes = routeCfg.getRoute();
		
		for (RouteType routeType : routeTypes) {
			if (routeType.isEnabled()) {
				try {
					AIRoute route = this.routeFactory.getRouteInstance(routeType.getRouteType());
					route.setConfig(routeType);
					allRoutes.add(route);
				} catch (Exception e) {
					LOG.error("Couldn't instantiate route defined in the route config xml for route type [%s]. Route will not be started..",
							new String[] { routeType.getRouteType().value() }, e);
				}
			}
		}
		
		// Explicitly add other static routes
		this.ingestRoute.setConfig(routeCfg.getRestConfig());
		this.restFailRoute.setConfig(routeCfg.getRestConfig());
		
		allRoutes.add(this.ingestRoute);
		allRoutes.add(this.restFailRoute);
		
		return allRoutes;
	}

	@Bean
	@Override
	public CamelContext camelContext() throws Exception {
		
		CamelContext context = super.camelContext();
		
		// Configure the shutdown strategy for the Camel
		context.getShutdownStrategy().setTimeout(Long.parseLong(this.camelShutdownTimeout));
		LOG.info("Camel shutdown trategy is : " + context.getShutdownStrategy());
		
		// ******** Configure the ActiveMQ component using VM internal broker ******
		// Persistence
		KahaDBPersistenceAdapter pa = new KahaDBPersistenceAdapter();
		pa.setDirectory(new File(this.activemqDir + "/kahadb"));
		pa.setBrokerName("localhost");
		
		// ActiveMQ broker, configured as bean. Make sure broker is started
		BrokerService broker = this.amqBroker();
		LOG.info("ActiveMQ broker is started: " + broker.isStarted());
		
		// ActiveMQ component for Camel (Use existing broker, don't auto-create)
		context.addComponent("activemq", ActiveMQComponent.activeMQComponent("vm://localhost?create=false"));
		
		// Fault logger interceptors for CXF REST endpoints
		CxfRsEndpoint loginService = (CxfRsEndpoint) context.getEndpoint(CommonUtils.getCamelURI(this.routeMgr.getRestConfig().getLoginServiceEndpoint()));
    	CxfRsEndpoint restService = (CxfRsEndpoint) context.getEndpoint(CommonUtils.getCamelURI(this.routeMgr.getRestConfig().getRestApiEndpoint()));
    	
    	loginService.getInInterceptors().add(new LoggingFaultInInterceptor());
    	restService.getInInterceptors().add(new LoggingFaultInInterceptor());
		
    	// Enable Camel route metrics
    	context.addRoutePolicyFactory(new MetricsRoutePolicyFactory());
    	
		return context;
	}
	
	@Bean
	@Scope("singleton")
	public BrokerService amqBroker() throws Exception {
		BrokerService broker = new BrokerService();
		broker.addConnector("vm://localhost");
		broker.setBrokerName("localhost");
		broker.setPersistent(true);
		broker.setUseJmx(true);
		broker.setPersistenceAdapter(this.persistenceAdapter());
		broker.setTmpDataDirectory(new File(this.activemqDir + "/tmp"));
		broker.start();
		return broker;
	}
	
	@Bean
	@Scope("singleton")
	public PersistenceAdapter persistenceAdapter() {
		KahaDBPersistenceAdapter pa = new KahaDBPersistenceAdapter();
		pa.setDirectory(new File(this.activemqDir + "/kahadb"));
		pa.setBrokerName("localhost");
		return pa;
	}
	
	/**
	 * ThreadPoolTaskExecutor to be used in multi-threaded SIP processing
	 * 
	 * @return
	 */
	
	@Bean
	@Scope("singleton")
	public ThreadPoolTaskExecutor taskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(Integer.parseInt(this.corePoolSize));
		executor.setMaxPoolSize(Integer.parseInt(this.maxPoolSize));
		executor.setThreadNamePrefix("SipProcessing - ");
		return executor;
	}
	
	/** 
	 * 	Beans used by XML processors
	 */
	
	@Bean
	@Scope("singleton")
	@Autowired
	public TransformerFactory transformerFactory(@Value("${xml.transformer.factory}") String trfFactory) {
		System.setProperty("javax.xml.transform.TransformerFactory", trfFactory);
		return TransformerFactory.newInstance();
	}
	
	@Bean
	@Scope("singleton")
	@Autowired
	public SchemaFactory schemaFactory(@Value("${xml.schema.factory}") String schemaFactory) {
		System.setProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema", schemaFactory);
		return SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
	}
	
	@Bean
	@Scope("singleton")
	@Autowired
	public XPathFactory xpathFactory(@Value("${xml.xpath.factory}") String xpathFactory) throws XPathFactoryConfigurationException {
		System.setProperty("javax.xml.xpath.XPathFactory:" + NamespaceConstant.OBJECT_MODEL_SAXON, xpathFactory);
		return XPathFactoryImpl.newInstance(NamespaceConstant.OBJECT_MODEL_SAXON);
	}
}

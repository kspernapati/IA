package com.teliasonera.eias.autoingest.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.processor.exception.IARestException;

@Component
@Scope("prototype")
public class IngestSipResponseProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(IngestSipResponseProcessor.class);

	public IngestSipResponseProcessor() {}
	
	@Autowired
	private IngestMessageStore messageStore;

	@Override
	public void process(Exchange exchange) throws Exception {
		
		Message msg = null;
		
		if(exchange.hasOut()) {
			msg = exchange.getOut();
		}
		else {
			msg = exchange.getIn();
		}

		JSONObject response = new JSONObject(msg.getBody(String.class));
		
		String aipId = response.getString("aipId");
		String state = response.getString("state");
		
		// Check that correct response was received
		if(state == null || !(state.equalsIgnoreCase("Completed") || state.equalsIgnoreCase("Waiting commit"))) {
			throw new IARestException("Ingestion of AIP [" + aipId + "] failed!");
		}
		
		// AIP was successfully ingested
		LOG.info("AIP with ID [" + aipId + "] was ingested successfully");
		
		this.messageStore.remove(exchange.getProperty(IAConstants.IA_ORIG_EXCHANGE_ID, String.class));
		LOG.debug("MessageStore size is: " + this.messageStore.size());
	}

}

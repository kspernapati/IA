package com.teliasonera.eias.autoingest.beans.email.notifytmpl;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/** Class for Notification. all the different kinds of notifications should extend this class
 * @author exq6006
 *
 */
@Component
@Scope("prototype")
@Qualifier("notifyTemplBean")
public class NotifyTempl {
	
	/**
	 *  Notification message to be sent
	 */
	public String message;
	
	
	/**
	 * getMessage to get the value of message
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * setMessage to set the value of message
	 * 
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}



}

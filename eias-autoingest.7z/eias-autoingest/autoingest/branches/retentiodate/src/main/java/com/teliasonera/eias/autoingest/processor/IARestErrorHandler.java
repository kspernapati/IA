package com.teliasonera.eias.autoingest.processor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.email.MailService;
import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.routeconfig.RestConfigType;

/**
 * Process error messages received from the IA REST API
 * 
 * @author sce4799
 *
 */

@Component
@Scope("singleton")
public class IARestErrorHandler implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(IARestErrorHandler.class);
	
	@Autowired
	private MailService mail;
	
	@Autowired
	private IngestMessageStore messageStore;

	private RestConfigType config;
	
	public IARestErrorHandler() {}
	
	public void setConfig(RestConfigType config) {
		this.config = config;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void process(Exchange exchange) throws Exception {
		
		LOG.warn("Message " + exchange.getExchangeId() + " was routed to error handler!");
		
		Exception ex = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
		
		if(ex != null) {
			LOG.error("Exception caught with message: " + ex.getMessage());
		}
		
		LOG.warn("Message " + exchange.getExchangeId() + " payload will be saved to ingestion error directory: " + this.config.getIngestErrorEndpoint().getName());
		
		
		// Write message payload to the error dir
		Message msg = exchange.getIn();
		Map<String, Object> origMsgDetails = this.messageStore.get(exchange.getProperty(IAConstants.IA_ORIG_EXCHANGE_ID, String.class));
		
		msg.setHeaders((Map<String, Object>) origMsgDetails.get("headers"));
		
		File outFile = new File(new File(this.config.getIngestErrorEndpoint().getName()), msg.getHeader(Exchange.FILE_NAME_ONLY, String.class));
		
		FileOutputStream out = null;
		InputStream body = null;
		
		try {
			out = new FileOutputStream(outFile);
			body = (InputStream) origMsgDetails.get("body");
			IOUtils.copy(body, out);
			out.flush();
			out.close();
			body.close();
		}
		catch(Exception e) {
			LOG.error("Error while writing payload to error dir!", e);
		}
		finally {
			IOUtils.closeQuietly(out);
			IOUtils.closeQuietly(body);
		}
		
		// Remove this message from the message store
		this.messageStore.remove(exchange.getProperty(IAConstants.IA_ORIG_EXCHANGE_ID, String.class));
		
		LOG.debug("IngestMessageStore size is: " + this.messageStore.size());
		
		mail.notifyError(ex, "Trying to ingest exchange " + exchange.getExchangeId() + 
				"resulted in an unrecoverable error. Payload will be saved in ingestion error directory " + 
				this.config.getIngestErrorEndpoint().getName());
	}
}

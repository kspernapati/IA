package com.teliasonera.eias.autoingest.beans.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.Validator;

import org.apache.commons.io.IOUtils;
import org.codehaus.stax2.XMLInputFactory2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

@Component
@Scope("singleton")
public class XMLValidator {

	private static final Logger LOG = LoggerFactory.getLogger(XMLValidator.class);

	@Autowired
	private ConcurrentSchemaFactory schemaFact;

	// Default constructor
	public XMLValidator() {}

	/**
	 * Validate the XML against the schema
	 * 
	 * @param xsd
	 * @param xml
	 * @throws IOException
	 * @throws SAXException
	 */

	public void validate(InputStream xsd, InputStream xml) throws IOException, SAXException {
		try {
			// Read the schema file
			Schema schema = this.schemaFact.newSchema(new SAXSource(new InputSource(xsd)));

			Validator val = schema.newValidator();
			// Validate source file
			LOG.debug("Validating source file..");

			val.validate(new SAXSource(new InputSource(xml)));

		} 
		finally {
			IOUtils.closeQuietly(xml, xsd);
		}

	}

	/**
	 * Validate the XML file against the schema file
	 * 
	 * @param schema
	 * @param xml
	 * @throws SAXException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */

	public void validate(File schema, File xml) throws SAXException, FileNotFoundException, IOException {
		
		if (schema == null || xml == null) {
			throw new FileNotFoundException("Given file is pointing to null!");
		}
		
		LOG.debug("XML validation started for file " + xml.getName());
		LOG.debug("Schema used " + schema.getAbsolutePath());
		
		InputStream xsdStream = null;
		InputStream xmlStream = null;
		
		try {
			xsdStream = new FileInputStream(schema);
			xmlStream = new FileInputStream(xml);
			this.validate(xsdStream, xmlStream);
		} 
		finally {
			IOUtils.closeQuietly(xsdStream, xmlStream);
		}
	}

	/**
	 * Validate XML file in Stream processing mode, using StAX Use this for large XML files to minimize memory usage
	 * 
	 * @param xsd
	 * @param xml
	 * @throws IOException
	 * @throws XMLStreamException
	 * @throws SAXException
	 */

	public void validateStAX(InputStream xsd, InputStream xml) throws IOException, XMLStreamException, SAXException {

		XMLInputFactory xmlin = XMLInputFactory2.newInstance();

		XMLStreamReader schReader = null;
		XMLStreamReader xmlReader = null;

		try {
			schReader = xmlin.createXMLStreamReader(xsd);
			xmlReader = xmlin.createXMLStreamReader(xml);

			// Read the schema file
			Schema schema = this.schemaFact.newSchema(new StAXSource(schReader));

			Validator val = schema.newValidator();

			// Validate input file
			val.validate(new StAXSource(xmlReader));
		} finally {
			if (schReader != null)
				schReader.close();
			if (xmlReader != null)
				xmlReader.close();
		}
	}

	/**
	 * Return a JAXB schema for the given InputStream
	 * 
	 * @param schema
	 * @return
	 * @throws SAXException
	 */

	public Schema getSchema(InputStream schema) throws SAXException {
		try {
			return this.schemaFact.newSchema(new StreamSource(schema));
		} finally {
			IOUtils.closeQuietly(schema);
		}
	}

	/**
	 * Return a JAXB schema for the given File
	 * 
	 * @param schema
	 * @return
	 * @throws FileNotFoundException
	 * @throws SAXException
	 */

	public Schema getSchema(File schema) throws FileNotFoundException, SAXException, IOException {
		if (schema == null) {
			throw new FileNotFoundException("Schema file is null!");
		}

		InputStream is = null;
		Schema s = null;

		try {
			is = new FileInputStream(schema);
			s = this.getSchema(is);
		} finally {
			IOUtils.closeQuietly(is);
		}

		return s;
	}
}

package com.teliasonera.eias.autoingest.routes;

import org.apache.camel.CamelContext;
import org.apache.camel.LoggingLevel;
import org.apache.camel.spring.SpringRouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.IngestErrorQueueHandler;
import com.teliasonera.eias.autoingest.routeconfig.RestConfigType;


@Component
@Scope("singleton")
public class IAReingestQueueHandlerRoute extends SpringRouteBuilder {

	@Autowired
	private IngestErrorQueueHandler errorQueueHandler;
	
	private RestConfigType config;
	
	public IAReingestQueueHandlerRoute() {
		super();
	}
	
	public IAReingestQueueHandlerRoute(RestConfigType config) {
		super();
		this.config = config;
	}
	
	public void setConfig(RestConfigType config) {
		this.config = config;
	}

	@Override
	public void configure() throws Exception {
		
		CamelContext ctx = this.getContext();
		
		this.errorQueueHandler.setProducer(ctx.createProducerTemplate());
		this.errorQueueHandler.setConsumer(ctx.createConsumerTemplate());
		
		from(CommonUtils.getCamelURI(this.config.getRestFailQueueEndpoint())).id("ReingestQueueEndpoint")
			.description("ReingestQueueHandler", "Handles the REST API error queue", null)
			.log(LoggingLevel.INFO, "Starting re-ingest queue processing")
			.process(this.errorQueueHandler).id("ErrorQueueHandler")
			.log(LoggingLevel.INFO, "Error queue handling complete");
	}

}

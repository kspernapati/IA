package com.teliasonera.eias.autoingest.processor;

import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.sip.SIPGenerator;
import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.exception.SipProcessorException;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
public class SipProcessor implements Processor {

    private static final Logger LOG = LoggerFactory.getLogger(SipProcessor.class);

    @Autowired
    private SIPGenerator sipGen;

    private RouteType config;

    public SipProcessor() {
    }

    public void setConfig(RouteType config) {
        this.config = config;
        this.sipGen.setConfig(this.config); // Propagate config to SIP generator too
    }

    @Override
    public void process(Exchange exc) throws SipProcessorException {
        Map<String, Object> headers = exc.getIn().getHeaders();
        LOG.info(CommonUtils.getSchedulerStartLogMessage("'SIP Processor start'", headers));
        try {
            this.sipGen.generateSIPs();
        } catch (Exception e) {
            throw new SipProcessorException("SIP Processing failed!", e);// Wrap thrown error into wrapper exception
        }
        LOG.info(CommonUtils.getSchedulerFinishedLogMessage("'SIP Processor end'", headers));
    }

}

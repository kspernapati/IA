package com.teliasonera.eias.autoingest.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

/**
 * Append exchange headers with parameters needed for SIP ingestion
 * Headers are used because Exchange properties are lost in 
 * JMS queue serialization
 * 
 * @author sce4799
 *
 */

@Component
@Scope("prototype")
public class PrepareSipIngestProcessor implements Processor {

	private RouteType config;
	
	public PrepareSipIngestProcessor() {}

	public void setConfig(RouteType config) {
		this.config = config;
	}
	
	@Override
	public void process(Exchange exchange) throws Exception {

		Message msg = exchange.getIn();
		
		// Set necessary properties
		msg.setHeader(IAConstants.IA_APP_NAME, this.config.getApplicationName());
		msg.setHeader(IAConstants.IA_TENANT_NAME, this.config.getIaTenantName());
		msg.setHeader(IAConstants.IA_USERNAME, this.config.getIngestUser());
		msg.setHeader(IAConstants.IA_PASSWORD, this.config.getIngestPasswd());
		msg.setHeader("JMSExpiration", Long.MAX_VALUE);		// Set message expiration time in the JMS queue to max value
	}

}

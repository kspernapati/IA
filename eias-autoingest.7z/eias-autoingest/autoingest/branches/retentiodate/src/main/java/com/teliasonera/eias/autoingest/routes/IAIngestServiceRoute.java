package com.teliasonera.eias.autoingest.routes;

import java.lang.reflect.InvocationTargetException;
import java.net.ConnectException;
import java.util.Calendar;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Predicate;
import org.apache.camel.component.cxf.jaxrs.CxfRsEndpoint;
import org.apache.camel.spring.SpringRouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.processor.AipURLResponseProcessor;
import com.teliasonera.eias.autoingest.processor.AppUrlRequestProcessor;
import com.teliasonera.eias.autoingest.processor.GetLoginTokenProcessor;
import com.teliasonera.eias.autoingest.processor.IARestErrorHandler;
import com.teliasonera.eias.autoingest.processor.IngestSipRequestProcessor;
import com.teliasonera.eias.autoingest.processor.IngestSipResponseProcessor;
import com.teliasonera.eias.autoingest.processor.JmsInputProcessor;
import com.teliasonera.eias.autoingest.processor.PrepareReingestProcessor;
import com.teliasonera.eias.autoingest.processor.ReceiveSipAggregationStrategy;
import com.teliasonera.eias.autoingest.processor.TenantInfoRequestProcessor;
import com.teliasonera.eias.autoingest.routeconfig.RestConfigType;

@Component
@Scope("singleton")
public class IAIngestServiceRoute extends SpringRouteBuilder {
	
	public static final String INGEST_SERVICE_URI = "activemq:queue:sip.ingest?preserveMessageQos=true";
	public static final String REINGEST_QUEUE_URI = "activemq:queue:sip.reingestion?preserveMessageQos=true";
	
	private static final Logger LOG = LoggerFactory.getLogger(IAIngestServiceRoute.class);
	
	private RestConfigType config;
	
	@Autowired private JmsInputProcessor jmsInputProcessor;
	@Autowired private ReceiveSipAggregationStrategy receiveSipAggregationStrategy;
	@Autowired private GetLoginTokenProcessor getLoginTokenProcessor;
	@Autowired private TenantInfoRequestProcessor tenantInfoRequestProcessor;
	@Autowired private AppUrlRequestProcessor appUrlRequestProcessor;
	@Autowired private AipURLResponseProcessor aipURLResponseProcessor;
	@Autowired private IngestSipRequestProcessor ingestSipRequestProcessor;
	@Autowired private IngestSipResponseProcessor ingestSipResponseProcessor;
	@Autowired private IARestErrorHandler iaRestErrorHandler;
	@Autowired private PrepareReingestProcessor prepareReingestProcessor;
	
	public IAIngestServiceRoute() {
		super();
	}
	
	public IAIngestServiceRoute(RestConfigType config) {
		super();
		this.config = config;
	}
	
	public RestConfigType getConfig() {
		return this.config;
	}
	
	public void setConfig(RestConfigType config) {
		this.config = config;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void configure() throws Exception {
		
		LOG.debug("Start Ingestion route configuration");
		CamelContext ctx = this.getContext();
		
		// Initialization
		this.iaRestErrorHandler.setConfig(this.config);
		this.getLoginTokenProcessor.setProducer(ctx.createProducerTemplate());
		
		// Configure REST endpoints
		CxfRsEndpoint loginService = (CxfRsEndpoint) ctx.getEndpoint(CommonUtils.getCamelURI(this.config.getLoginServiceEndpoint()));
    	CxfRsEndpoint restService = (CxfRsEndpoint) ctx.getEndpoint(CommonUtils.getCamelURI(this.config.getRestApiEndpoint()));
    	
		// Unrecoverable errors are handled here. Default action is to move immediately to undeliverable SIP folder
    	onException(Exception.class)
    		.handled(true)
    		.process(this.iaRestErrorHandler);
		
		from(INGEST_SERVICE_URI).id("IngestQueueEndpoint")
			.description("RestIngestRoute-Main", "Main component of the REST based ingestion route", null)
			.onException(InvocationTargetException.class, ConnectException.class)	// This exception is thrown if service is unavailable. Retry.
				.maximumRedeliveries(this.config.getRedeliveryAttempts())
				.redeliveryDelay(this.config.getRedeliveryDelay())
				.maximumRedeliveryDelay(this.config.getMaxRedeliveryDelay())
				.useExponentialBackOff()
				.handled(true)
				.log(LoggingLevel.WARN, "IA REST API seems to be unavailable. Moving message to await reingestion")
				.setExchangePattern(ExchangePattern.InOnly)
				.process(this.prepareReingestProcessor).id("PrepareReingestProcessor")
				.to(REINGEST_QUEUE_URI).id("ReingestQueueEndpoint")
				.end()
			.process(this.jmsInputProcessor).id("JMSMessageProcessor")
			//------ Query REST API for IA info. Original message saved by multi-casting to 
			//       mock endpoint and re-aggregating with API response  -------
			.multicast(this.receiveSipAggregationStrategy).id("MultiCast-Query")
				.stopOnException()
				.to("direct:getApplicationInfo", "mock:doNothing").id("GetApplicationInfo, DuplicateExchange") // Send to mock endpoint to get the same response back for aggregation
				.end()
			.log(LoggingLevel.DEBUG, "Message aggregation done")
			//------ Receive SIP package ------
			.setExchangePattern(ExchangePattern.InOut)
			.to(restService).id("ReceiveSIP")	// Receive SIP stage
			//------ Ingest SIP package ------
			.removeHeaders("*") // Clear all message headers
			.process(this.ingestSipRequestProcessor).id("IngestRequestProcessor")
			// SIP reception can take time and cause login token to expire. If so, request new one from IAWA
			.choice().id("ValidateLoginToken")
				.when(new Predicate() {		// Check login token validity
					@Override
					public boolean matches(Exchange exchange) {
						Calendar expiry = exchange.getProperty(IAConstants.IA_LOGIN_EXPIRY, Calendar.class);
						Calendar now = Calendar.getInstance();
						if(expiry.before(now)) {
							return true;	// Token has expired, request new
						}
						return false;
					}})
				.log(LoggingLevel.INFO, "Login token expired, requesting new one from IAWA")
				.process(this.getLoginTokenProcessor).id("RequestNewTokenProcessor")
				.end()
			.to(restService).id("IngestSIP")	// Ingest SIP stage
			.process(this.ingestSipResponseProcessor).id("ValidateIngestionProcessor")
			.to("mock:end").id("MockEndpointForTest");	// Mock endpoint for test purposes
		
		// IA application query over REST
		
		from("direct:getApplicationInfo").id("GetApplicationInfo")
			.description("RestIngestRoute-Query", "Application query component of the REST ingestion route", null)
			.onException(InvocationTargetException.class, ConnectException.class)	// This exception is thrown if service is unavailable. Retry.
				.maximumRedeliveries(this.config.getRedeliveryAttempts())
				.redeliveryDelay(this.config.getRedeliveryDelay())
				.maximumRedeliveryDelay(this.config.getMaxRedeliveryDelay())
				.handled(true)
				.useExponentialBackOff()
				.log(LoggingLevel.WARN, "IA REST API seems to be unavailable. Moving message to await reingestion")
				.setExchangePattern(ExchangePattern.InOnly)
				.process(this.prepareReingestProcessor).id("PrepareReingestProcessor")
				.to(REINGEST_QUEUE_URI).id("ReingestQueueEndpoint")
				.end()
			//------ Get the login token ---------
			.removeHeaders("*")	// Remove unnecessary headers
			.setExchangePattern(ExchangePattern.InOut)
			.process(this.getLoginTokenProcessor).id("LoginTokenRequestProcessor")	// POJO producer, requests login token from IAWA
			.log(LoggingLevel.DEBUG, "Login request processed")
			//------ Get tenant and Application info --------
			.process(this.tenantInfoRequestProcessor).id("TenantInfoRequestProcessor")
			.to(restService).id("QueryTenantInfo")	// Query IA tenant info
			.log(LoggingLevel.DEBUG, "Tenant info retrieved")
			.process(this.appUrlRequestProcessor).id("AppURLRequestProcessor")
			.to(restService).id("QueryApplicationInfo")	// Query IA application URL
			.log(LoggingLevel.DEBUG, "Application info retrieved")
			.process(this.aipURLResponseProcessor).id("AipURLResponseProcessor");
		
		// Request login token from IAWA
		from("direct:getLoginToken").id("GetLoginToken")
			.description("RestIngestRoute-GetLoginToken", "Request login token from IAWA", null)
			.errorHandler(noErrorHandler())		// Throw exception to the caller, no global handling here
			.to(loginService).id("RequestLoginToken");
	}
}

package com.teliasonera.eias.autoingest.beans.sip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.stax2.XMLInputFactory2;
import org.codehaus.stax2.XMLOutputFactory2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import com.emc.eas.sip.ObjectFactory;
import com.emc.eas.sip.PdiHash;
import com.emc.eas.sip.Sip;
import com.teliasonera.eias.autoingest.beans.xml.XMLValidator;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
public class PDICreator {

	private static final Logger LOG = LoggerFactory.getLogger(PDICreator.class);

	public static final String PDI_FILENAME = "eas_pdi.xml";
	public static final String XML_BACKUP_DIR = "backup";
	public static final String PDI_HASH_TYPE = "SHA-256";

	// Control the output indentation
	private static final char INDENT_CHAR = ' ';
	private static final int INDENT_MULT = 2;

	@Autowired
	private XMLValidator validator;

	private RouteType config;

	// Variables for "stateful" XML output writing
	private int depthCnt;
	private int prevState;

	public PDICreator() {
	}

	public void setConfig(RouteType config) {
		this.config = config;
	}

	public void createPDI(File sipDir, Sip sip) throws XMLStreamException, FileNotFoundException, IOException, SAXException {

		if(this.config == null) {
			throw new IllegalArgumentException("Configuration is not initialized!");
		}

		LOG.info("PDI creation started.." + sipDir.getAbsolutePath());
		if (!sipDir.isDirectory()) {
			LOG.error(sipDir.getAbsolutePath() + " is not a directory!");
			throw new IllegalArgumentException(sipDir.getAbsolutePath() + " is not a directory!");
		}

		File pdiFile = new File(sipDir, PDI_FILENAME);

		XMLOutputFactory xmlof = XMLOutputFactory2.newInstance();
		XMLInputFactory xmlif = XMLInputFactory2.newInstance();
		String namespace = sip.getDss().getPdiSchema();
		XMLStreamWriter writer = null;

		// List XML metadata files
		Collection<File> xmlFiles = FileUtils.listFiles(sipDir, new SuffixFileFilter(this.config.getMetadataFileExtension(), IOCase.INSENSITIVE),
				null);
		OutputStream os = null;

		try {
			// Set up output file
			os = new FileOutputStream(pdiFile);
			writer = xmlof.createXMLStreamWriter(os, "UTF-8");

			this.depthCnt = 0; // Maintain indentation depth count for "Pretty Printing" output

			writer.setDefaultNamespace(namespace);
			writer.writeStartDocument("UTF-8", "1.0");
			writer.writeCharacters("\n");
			writer.writeStartElement(namespace, this.config.getPdiRootElement());
			writer.writeNamespace("", namespace);
			this.prevState = XMLStreamConstants.START_ELEMENT;

			// Process all XML files in the directory

			for (File f : xmlFiles) {
				LOG.debug("Processing all XML file in directory.." + f.getName());
				XMLStreamReader reader = null;
				InputStream is = null;

				// Write the XML file as-is to the output stream, omit only XML declaration
				try {
					is = new FileInputStream(f);
					reader = xmlif.createXMLStreamReader(is, "UTF-8");
					while (reader.hasNext()) {
						this.writeToOutput(reader, writer);
						reader.next();
					}
				} catch (XMLStreamException e) {
					throw e;
				} catch (FileNotFoundException e) {
					throw e;
				} finally {
					if (reader != null)
						reader.close();
					if (is != null)
						IOUtils.closeQuietly(is);
				}
			}

			// End document
			writer.writeEndDocument();
		} 
		catch (XMLStreamException e) {
			throw e;
		} 
		catch (FileNotFoundException e) {
			throw e;
		} 
		finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
			if (os != null)
				IOUtils.closeQuietly(os);
		}

		// Validate the created PDI file
		// Multi-threaded processing has issue at initialization stage of the processor and sometimes
		// throws a NullPointer at first validation rounds after application restart. To prevent this to
		// stop the processing, adding a wait & retry mechanism in case NullPointer is thrown

		if (this.config.getPdiXmlValidation().isExecute()) {
			FileInputStream sch = null;
			FileInputStream xml = null;
			try {
				LOG.info("Validating PDI file.." + pdiFile.getName());
				sch = new FileInputStream(this.config.getPdiXmlValidation().getFile());
				xml = new FileInputStream(pdiFile);

				this.validator.validateStAX(sch, xml);

				LOG.info("PDI validation passed for " + pdiFile.getAbsolutePath());
			}
			catch(Exception e) {
				throw e;
			}
			finally {
				IOUtils.closeQuietly(sch);
				IOUtils.closeQuietly(xml);
			}
		}

		// Processing was successful, move XML files into backup directory
		File bacupDir = new File(sipDir, XML_BACKUP_DIR);

		for (File f : xmlFiles) {
			try {
				FileUtils.moveFileToDirectory(f, bacupDir, true);
			} catch (IOException e) {
				LOG.error("Error moving file: " + f.getAbsolutePath());
				throw e;
			}
		}
		// Generate PDI HASH and add to SIP
		InputStream is = null;
		String hashStr = "";

		try {
			is = new FileInputStream(pdiFile);
			hashStr = Base64.encodeBase64String(DigestUtils.sha256(is));
		} finally {
			IOUtils.closeQuietly(is);
		}

		ObjectFactory of = new ObjectFactory();
		PdiHash hash = of.createPdiHash();
		hash.setAlgorithm(PDI_HASH_TYPE);
		hash.setEncoding("base64");
		hash.setValue(hashStr);

		sip.setPdiHash(hash);
	}

	/**
	 * Handle writing XML events into the output streamwriter. Produces "Pretty Printed" output
	 * 
	 * @param rdr
	 * @param wtr
	 * @throws XMLStreamException
	 */

	private void writeToOutput(XMLStreamReader rdr, XMLStreamWriter wtr) throws XMLStreamException {

		switch (rdr.getEventType()) {
		case XMLStreamConstants.START_DOCUMENT:
			// Do nothing, XML declaration is omitted
			break;
		case XMLStreamConstants.START_ELEMENT:
			this.depthCnt++; // Increment depth count

			if (this.prevState == XMLStreamConstants.START_ELEMENT)
				wtr.writeCharacters("\n"); // Newline between consecutive start elements
			wtr.writeCharacters(StringUtils.repeat(INDENT_CHAR, depthCnt * INDENT_MULT)); // Write indentation
			wtr.writeStartElement(rdr.getPrefix(), rdr.getLocalName(), rdr.getNamespaceURI());
			writeAttributes(rdr, wtr);
			writeNamespaces(rdr, wtr);

			// Save state for next round
			this.prevState = rdr.getEventType();
			break;
		case XMLStreamConstants.ATTRIBUTE:
			writeAttributes(rdr, wtr);
			break;
		case XMLStreamConstants.END_ELEMENT:
			if (this.prevState == XMLStreamConstants.END_ELEMENT)
				wtr.writeCharacters(StringUtils.repeat(INDENT_CHAR, depthCnt * INDENT_MULT)); // Write indentation  for  consecutive  end  elements
			wtr.writeEndElement();
			wtr.writeCharacters("\n"); // Always write newline after end element
			this.depthCnt--; // Decrement depth count Save state for next round
			this.prevState = rdr.getEventType();
			break;
		case XMLStreamConstants.NAMESPACE:
			writeNamespaces(rdr, wtr);
			break;
		case XMLStreamConstants.CHARACTERS:
			wtr.writeCharacters(getTextData(rdr));
			break;
		case XMLStreamConstants.CDATA:
			wtr.writeCData(getTextData(rdr));
			break;
		case XMLStreamConstants.COMMENT:
			wtr.writeComment(getTextData(rdr));
			break;
		case XMLStreamConstants.SPACE:
			// Omit whitespace
			break;
		case XMLStreamConstants.END_DOCUMENT:
			// Do nothing, would prematurely end the document...
			break;
		default:
			// XML events that are not implemented may be ignored (for example PROCESSING_INSTRUCTION is not needed in the PDI)
			LOG.debug("Unsupported XML event: " + rdr.getEventType());
			break;
		}

	}

	/**
	 * Helper to write XML attributes
	 * 
	 * @param rdr
	 * @param wtr
	 * @throws XMLStreamException
	 */

	private static void writeAttributes(XMLStreamReader rdr, XMLStreamWriter wtr) throws XMLStreamException {
		for (int i = 0; i < rdr.getAttributeCount(); i++) {
			wtr.writeAttribute(rdr.getAttributePrefix(i), rdr.getAttributeNamespace(i), rdr.getAttributeLocalName(i), rdr.getAttributeValue(i));
		}
	}

	/**
	 * Helper to write XML namespaces
	 * 
	 * @param rdr
	 * @param wtr
	 * @throws XMLStreamException
	 */

	private static void writeNamespaces(XMLStreamReader rdr, XMLStreamWriter wtr) throws XMLStreamException {
		for (int i = 0; i < rdr.getNamespaceCount(); i++) {
			wtr.writeNamespace(rdr.getNamespacePrefix(i), rdr.getNamespaceURI(i));
		}
	}

	/**
	 * Helper to get XML string data
	 * 
	 * @param rdr
	 * @return
	 */

	private static String getTextData(XMLStreamReader rdr) {
		int start = rdr.getTextStart();
		int length = rdr.getTextLength();
		return StringUtils.trim(new String(rdr.getTextCharacters(), start, length));
	}
}

package com.teliasonera.eias.autoingest.processor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.teliasonera.eias.autoingest.beans.sip.ContentFileLinker;
import com.teliasonera.eias.autoingest.beans.sip.ContentFileLinkerException;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
public class ContentFileLinkerProcessor implements Processor {
    private static final Logger LOG = LoggerFactory.getLogger(ContentFileLinkerProcessor.class);
    
    @Autowired
    private ContentFileLinker linker;

    private RouteType config;

    public ContentFileLinkerProcessor() {
    }

    public void setConfig(RouteType config) {
        this.config = config;

        // Initialize the linker with the new configuration
        this.initLinker();
    }

    @Override
    public void process(Exchange exc) throws ContentFileLinkerException {
        LOG.info("Content linker started..");
        OutputStream xmlStr = this.linker.linkContentFiles(exc.getIn().getBody(InputStream.class), (String)exc.getIn().getHeader("CamelFileNameOnly"), this.config.getContentLinks().getContentLink());
         exc.getIn().setBody(os2String(xmlStr));
        try {
            xmlStr.close();
        } catch (IOException e) {
            throw new ContentFileLinkerException("Error occurred while closing stream in ContentFileLinkerProcessor" + e);
        }
    }

    // Initialize the file linker

    private void initLinker() {
        this.linker.setMetaExtension(this.config.getMetadataFileExtension());
        this.linker.setWorkDir(new File(this.config.getSipProcessorWorkDirEndpoint().getName()));
        this.linker.setRenameFiles(this.config.getContentfileLinking().isRenameFiles());
    }

    private static String os2String(OutputStream os) {
         byte[] bytes = ((ByteArrayOutputStream)os).toByteArray();
        String out = new String(bytes, Charset.forName("UTF-8"));
         return out;
    }
}

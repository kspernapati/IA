package com.teliasonera.eias.autoingest.routes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.FileMetadataProcessor;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
public class ContentOnlyRoute extends XmlContentRoute {

	@Autowired
	private FileMetadataProcessor fMetaProcessor;

	public ContentOnlyRoute() {
		super();
	}
	
	public ContentOnlyRoute(RouteType config) {
		super(config);
	}
	
	/**
	 * Propagate {@link RouteConfig} to all the processors
	 */
	private void init() {
		this.fMetaProcessor.setConfig(config);

	}

	@Override
	public void configure() throws Exception {
		
		// Configure XML + Content route from superclass
		super.configure();
		
		// Initialize processors
 		init();
 		
 		// Route configuration
		from(CommonUtils.getCamelURI(this.config.getContentOnlyFileEndpoint())).id(this.config.getName() + "-ContentOnlyEndpoint") // fetch only the content files form the incoming dir
			.description(this.config.getName() + "-IncomingContentOnly", "Incoming content only processing", null)
			.threads(this.config.getReceiverThreadPoolSize())
			.process(this.fMetaProcessor).id(this.config.getName() + "-FileMetadataProcessor") // get and copy the metadata file as well.		
			.to(CommonUtils.getCamelURI(this.config.getIncomingFileEndpoint())).id(this.config.getName() + "-XmlAndContentEndpoint"); // copy the file to the C+M processor
 	}

}

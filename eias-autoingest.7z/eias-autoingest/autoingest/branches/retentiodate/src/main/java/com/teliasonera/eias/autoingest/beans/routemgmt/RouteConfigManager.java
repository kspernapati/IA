package com.teliasonera.eias.autoingest.beans.routemgmt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import com.teliasonera.eias.autoingest.routeconfig.RestConfigType;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

/**
 * Maintain the Camel RouteConfig XML file
 * 
 * @author sce4799
 *
 */

@Component
@Scope("singleton")
public class RouteConfigManager {
	
	private static final Logger LOG = LoggerFactory.getLogger(RouteConfigManager.class);

    private static final String CONFIG_SCHEMA = "route_config.xsd";
    private static final String CONFIG_FILE = "route_config.xml";
    private static final String DEFAULT_CFG_DIR = "config";

    @Autowired
    private RouteConfigFactory factory;

    /**
     * Loading from classpath config folder
     */
    @Value("classpath:" + "" + DEFAULT_CFG_DIR + "/" + CONFIG_SCHEMA)
    private InputStream routeConfigSchema;

    /**
     * Loading from classpath config folder
     */
    @Value("classpath:" + "" + DEFAULT_CFG_DIR + "/" + CONFIG_FILE)
    private InputStream routeConfigFile;

    /**
     * Load route config from location specified by property.
     * This overrides classpath location if defined
     */
    @Value("file:${route.config.file:#{null}}")
    private File routeConfigFileOverride;
    
    private RouteConfig routeConfig;

    /**
     * Constructor
     */

    public RouteConfigManager() {
    }

    /**
     * Get the current RouteConfig object
     * 
     * @return
     */

    public RouteConfig getRouteConfig() {
        return this.routeConfig;
    }

    /**
     * Forces the updating of RouteConfig from source XML file 
     * 
     * @throws URISyntaxException
     */

    public void updateConfig() throws FileNotFoundException, JAXBException, SAXException, URISyntaxException {
    	// Check if route config location property is set, use it if defined. Otherwise use classpath location
    	if(this.routeConfigFileOverride != null && this.routeConfigFileOverride.exists() 
    			&& this.routeConfigFileOverride.isFile() && this.routeConfigFileOverride.canRead()) {
    		FileInputStream xmlFileStr = new FileInputStream(this.routeConfigFileOverride);
    		this.routeConfig = this.factory.getRouteConfig(this.routeConfigSchema, xmlFileStr);
    	}
    	else {
    		this.routeConfig = this.factory.getRouteConfig(this.routeConfigSchema, this.routeConfigFile);
    	}
    }

    /**
     * Get names of all routes defined in the current config file
     * 
     * @return List of route names
     */

    public List<String> getRouteNames() {

        List<RouteType> routes = this.routeConfig.getRoute();

        List<String> names = new ArrayList<>();

        for (RouteType r : routes) {
            names.add(r.getName());
        }

        return names;
    }

    /**
     * Get a route configuration object by its name
     * 
     * @param name - Route name
     * @return RouteType object if the object with given name is found, null
     *         otherwise
     */

    public RouteType getRoute(String name) {

        List<RouteType> routes = this.routeConfig.getRoute();

        for (RouteType r : routes) {
            if (r.getName().equals(name))
                return r;
        }

        LOG.error("Could not find route configuration with name [%s]", name);
        
        return null;
    }
    
    /**
     * Get the REST API configurations from RouteConfig
     * 
     * @return RestConfigType
     */
    public RestConfigType getRestConfig() {
    	return this.routeConfig.getRestConfig();
    }
}

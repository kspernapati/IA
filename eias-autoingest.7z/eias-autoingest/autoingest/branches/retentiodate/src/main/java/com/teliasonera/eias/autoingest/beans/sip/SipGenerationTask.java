package com.teliasonera.eias.autoingest.beans.sip;

import java.io.File;
import java.io.FileNotFoundException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.emc.eas.sip.Sip;
import com.teliasonera.eias.autoingest.common.ZipUtils;

public class SipGenerationTask implements Runnable {
	
	private static final Logger LOG = LoggerFactory.getLogger(SipGenerationTask.class);

	private File targetDir;
	private File ingestQueueDir;
	private Sip sip;
	private PDICreator pdiCreator;
	
	public SipGenerationTask(File targetDir, File ingestQueueDir, Sip sip, PDICreator pdiCreator) throws IllegalArgumentException, FileNotFoundException {
		this.targetDir = targetDir;
		this.ingestQueueDir = ingestQueueDir;
		this.sip = sip;
		this.pdiCreator = pdiCreator;
	}

	@Override
	public void run() {
		
		LOG.info("Starting SIP package generation for " + this.targetDir.getPath());
		
		try {
			JAXBContext ctx = JAXBContext.newInstance("com.emc.eas.sip");
			Marshaller marshaller = ctx.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		
			// Create PDI
			LOG.debug("Creating PDI file for " + this.targetDir.getPath());
			this.pdiCreator.createPDI(this.targetDir, sip);
			
			// Write the SIP XML
			File sipXml = new File(this.targetDir, SIPGenerator.SIP_XML_NAME);
			
			LOG.debug("Creating SIP file " + sipXml.getAbsolutePath());
			marshaller.marshal(sip, sipXml);
			
			// ZIP the target folder
			LOG.debug("Compressing SIP folder " + this.targetDir.getPath());
			File zipFile = ZipUtils.zipDirectory(this.targetDir, this.targetDir.getParentFile());
			
			// Move ZIP to the ingest queue dir
			LOG.debug("Moving ZIP file " + zipFile.getPath() + " to ingest queue dir");
			FileUtils.moveFileToDirectory(zipFile, this.ingestQueueDir, true);
			
			// If successful so far, the work dir can be deleted as SIP generation was successful
			LOG.debug("Deleting SIP work directory " + this.targetDir.getPath());
			FileUtils.deleteDirectory(this.targetDir);
			
			LOG.info("SIP generation for [" + this.targetDir.getPath() + "] completed successfully");
		} 
		catch (Exception e) {
			LOG.error("SIP processing for [" + this.targetDir.getPath() + "] has failed with: " + e.getMessage(), e);
		}
	}
}

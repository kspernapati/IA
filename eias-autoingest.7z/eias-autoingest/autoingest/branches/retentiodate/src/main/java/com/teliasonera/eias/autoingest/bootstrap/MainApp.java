package com.teliasonera.eias.autoingest.bootstrap;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.system.ApplicationPidFileWriter;
import org.springframework.boot.system.EmbeddedServerPortFileWriter;
import org.springframework.boot.web.support.SpringBootServletInitializer;

import io.hawt.springboot.EnableHawtio;
import io.hawt.system.ConfigManager;
import io.hawt.web.AuthenticationFilter;

/**
 * Main BootStrap class from Spring boot.
 * 
 * @author exq6006
 */
@SpringBootApplication
@EnableHawtio
public class MainApp extends SpringBootServletInitializer {
	private static final Logger LOG = LoggerFactory.getLogger(MainApp.class);
	
	@Autowired
	private ServletContext context;
	
	@Value("${version}")
	private String appVersion;
	
	/**
	 * Hawtio setup
	 */
	
	@PostConstruct
	public void init() {
		LOG.info("Starting application version: " + appVersion);
		final ConfigManager configManager = new ConfigManager();
		configManager.init();
		this.context.setAttribute("ConfigManager", configManager);
	}
	
	/**
	 * Configure SpringApplicationBuilder
	 */
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		LOG.debug("Initializing EIAS application via Spring Boot");
		// Add application listeners
		application.application().addListeners(new ApplicationPidFileWriter(), new EmbeddedServerPortFileWriter());
		
		return application.sources(MainApp.class);
	}

	public static void main(String[] args) throws Exception {
		// System properties
		System.setProperty(AuthenticationFilter.HAWTIO_AUTHENTICATION_ENABLED, "false");
		System.setProperty("org.apache.camel.jmx", "true");
		
		// Run application
		SpringApplication.run(MainApp.class, args);
	}
}

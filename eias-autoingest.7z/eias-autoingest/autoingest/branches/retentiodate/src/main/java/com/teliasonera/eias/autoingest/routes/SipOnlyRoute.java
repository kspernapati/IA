package com.teliasonera.eias.autoingest.routes;

import org.apache.camel.LoggingLevel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.GlobalErrorHandler;
import com.teliasonera.eias.autoingest.processor.PrepareSipIngestProcessor;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@Component
@Scope("prototype")
@Qualifier("sipOnlyRoute")
public class SipOnlyRoute extends AIRoute {

	@Autowired
	private PrepareSipIngestProcessor prepareIngestProcessor;
	
	@Autowired
	private GlobalErrorHandler globalErrorHandler;

	public SipOnlyRoute() {
		super();
	}

	public SipOnlyRoute(RouteType config) {
		super(config);
	}

	@Override
	public void configure() throws Exception {

		// Initialize processors
		this.prepareIngestProcessor.setConfig(this.config);

		// ============== Route configuration ===============

		// Global error handler
		// All exceptions here are handled by GlobalErrorHandler. No redeliveries
		errorHandler(deadLetterChannel(CommonUtils.getCamelURI(this.config.getErrorDirEndpoint()))
			.onPrepareFailure(this.globalErrorHandler)	// Perform global handling
			.maximumRedeliveries(0)
			.loggingLevel(LoggingLevel.ERROR)
			.logNewException(true)
			.logStackTrace(true)); 

		// Main route - Send SIP files directly to ingestion queue
		
		from(CommonUtils.getCamelURI(this.config.getIncomingFileEndpoint())).id(this.config.getName() + "-SipOnlyEndpoint")
			.description(this.config.getName() + "-SIPOnly", "Send complete SIP packages for ingestion", null)
			.process(this.prepareIngestProcessor).id(this.config.getName() + "-PrepareIngestProcessor")
			.to(IAIngestServiceRoute.INGEST_SERVICE_URI).id(this.config.getName() + "-IngestQueueEndpoint");
	}


}

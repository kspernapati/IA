package com.teliasonera.eias.autoingest.beans.xml;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileAttribute;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.filemetadata.BasicFileAttributeView;
import com.teliasonera.eias.autoingest.filemetadata.CustomFileAttributesView;
import com.teliasonera.eias.autoingest.filemetadata.FileAttributeView;
import com.teliasonera.eias.autoingest.filemetadata.ObjectFactory;

/**
 * class responsible for extracting the metadata into xml which is based on {@link FileAttribute}. Check the
 * filemeta.xsd for more details.
 * 
 * Modification to file path generation. File path needs to be relative, take it from the Camel Exchange
 * - sce4799
 * 
 * @author exq6006
 */

@Component
@Scope("prototype")
public class FileMetaAsXMLService {
	private static final String DEFAULT_MIME_TYPE = "application/octet-stream";
	private static final String DEFAULT_FORMAT = "binary";
	private static final Logger LOG = LoggerFactory.getLogger(FileMetaAsXMLService.class);

	private ObjectFactory objFactory;
	private DatatypeFactory dtFactory;
	
	public FileMetaAsXMLService() throws Exception {
		this.init();
	}

	public ByteArrayOutputStream getMetainfoAsXMLStream(File sourceFile, File baseDir, String path) throws JAXBException, DatatypeConfigurationException, IOException {
		LOG.debug("sourceFile is >>>>>>>>>>>>>> " + sourceFile);
		ByteArrayOutputStream xmlDocAsBAStream = new ByteArrayOutputStream();
		
		JAXBContext jaxbContext = JAXBContext.newInstance("com.teliasonera.eias.autoingest.filemetadata");
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		
		// output pretty printed
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
 		jaxbMarshaller.marshal(getMetaInfoAsXML(sourceFile, baseDir, path), xmlDocAsBAStream);
 		
		return xmlDocAsBAStream;
	}
	
	public ByteArrayOutputStream getMetainfoAsXMLStream(File sourceFile, File baseDir, String path, String overruleName) throws JAXBException, DatatypeConfigurationException, IOException {
		LOG.debug("sourceFile is >>>>>>>>>>>>>> " + sourceFile);
		ByteArrayOutputStream xmlDocAsBAStream = new ByteArrayOutputStream();
		
		JAXBContext jaxbContext = JAXBContext.newInstance("com.teliasonera.eias.autoingest.filemetadata");
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		
		// output pretty printed
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
 		jaxbMarshaller.marshal(getMetaInfoAsXML(sourceFile, baseDir, path, overruleName), xmlDocAsBAStream);
 		
		return xmlDocAsBAStream;
	}

	private JAXBElement<FileAttributeView> getMetaInfoAsXML(File file, File baseDir, String path) throws IOException {
		FileAttributeView eiasFattrributesView = this.objFactory.createFileAttributeView();
		eiasFattrributesView.setBasicFileAttributes(getBasicFileAttr(file));
		eiasFattrributesView.setCustomFileAttributes(getCustomeFileAttributes(file, baseDir, path));
		return this.objFactory.createFileAttributes(eiasFattrributesView);

	}
	
	private JAXBElement<FileAttributeView> getMetaInfoAsXML(File file, File baseDir, String path, String overruleName) throws IOException {
		FileAttributeView eiasFattrributesView = this.objFactory.createFileAttributeView();
		
		// Set the overruled file name
		BasicFileAttributeView basicAttrs = getBasicFileAttr(file);
		basicAttrs.setObjectName(basicAttrs.getName());
		basicAttrs.setName(overruleName);
		
		eiasFattrributesView.setBasicFileAttributes(basicAttrs);
		eiasFattrributesView.setCustomFileAttributes(getCustomeFileAttributes(file, baseDir, path));
		return this.objFactory.createFileAttributes(eiasFattrributesView);

	}

	/**
	 * <xs:complexType name="customFileAttributesView"> <xs:sequence> <xs:element type="xs:string" name="format" /> <!--
	 * http://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html#probeContentType-java.nio.file.Path- -->
	 * <xs:element type="xs:string" name="mimeType" /> <!--
	 * https://docs.oracle.com/javase/8/docs/api/java/nio/file/Path.html --> <xs:element type="xs:string" name="path" />
	 * </xs:sequence> </xs:complexType>
	 * 
	 * @param file
	 * @throws IOException
	 */
	protected CustomFileAttributesView getCustomeFileAttributes(File file, File baseDir, String path) throws IOException {
		String mimeType = Files.probeContentType(file.toPath());
		if (mimeType == null) {
			mimeType = DEFAULT_MIME_TYPE;
		}
		
		if(!baseDir.isDirectory() || !baseDir.exists()) {
			throw new IllegalArgumentException("BaseDir with path [" + baseDir.getAbsolutePath() + "] does not point to a directory!");
		}

//		Path filePath = file.getAbsoluteFile().toPath();
//		Path baseDirPath = baseDir.getAbsoluteFile().toPath();
//		Path relativeFilePath = baseDirPath.relativize(filePath);
		
		// Get the relative path of the source file from the Camel Message, passed as parameter
		CustomFileAttributesView eiasCustomFAttrs = objFactory.createCustomFileAttributesView();
		String format = FilenameUtils.getExtension(file.getName());
		if(format == null || format.equals("")) {
			format = DEFAULT_FORMAT;
		}
		eiasCustomFAttrs.setFormat(format);
		eiasCustomFAttrs.setMimeType(mimeType);
		eiasCustomFAttrs.setPath(path);
		return eiasCustomFAttrs;
	}

	/**
	 * <!-- read definitions from
	 * https://docs.oracle.com/javase/8/docs/api/java/nio/file/attribute/BasicFileAttributeView.html -->
	 * <xs:complexType name="basicFileAttributeView"> <xs:sequence> <xs:element type="xs:string" name="name" />
	 * <xs:element type="xs:dateTime" name="lastModifiedTime" /> <xs:element type="xs:dateTime" name="creationTime" />
	 * <xs:element type="xs:long" name="size" /> <!--consider below optional -->
	 * <xs:element type="xs:dateTime" name="lastAccessTime" minOccurs="0" maxOccurs="1" />
	 * <xs:element type="xs:boolean" name="isRegularFile" minOccurs="0" maxOccurs="1" />
	 * <xs:element type="xs:boolean" name="isDirectory" minOccurs="0" maxOccurs="1" />
	 * <xs:element type="xs:boolean" name="isSymbolicLink" minOccurs="0" maxOccurs="1" />
	 * <xs:element type="xs:boolean" name="isOther" minOccurs="0" maxOccurs="1" />
	 * <xs:element type="xs:string" name="fileKey" minOccurs="0" maxOccurs="1" /> </xs:sequence> </xs:complexType>
	 * 
	 * @param file
	 * @throws IOException
	 */
	protected BasicFileAttributeView getBasicFileAttr(File file) throws IOException {
		BasicFileAttributes jFileBasicAttrs = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
		BasicFileAttributeView eiasFileBasicAttrs = objFactory.createBasicFileAttributeView();

		GregorianCalendar gCal = (GregorianCalendar) GregorianCalendar.getInstance();
		//name
		eiasFileBasicAttrs.setName(file.getName());

		//setLastModifiedTime
		gCal.clear();
		gCal.setTimeInMillis(jFileBasicAttrs.lastModifiedTime().toMillis());
		eiasFileBasicAttrs.setLastModifiedTime(this.dtFactory.newXMLGregorianCalendar(gCal));

		//setCreationTime
		gCal.clear();
		gCal.setTimeInMillis(jFileBasicAttrs.creationTime().toMillis());
		eiasFileBasicAttrs.setCreationTime(this.dtFactory.newXMLGregorianCalendar(gCal));

		//setSize
		eiasFileBasicAttrs.setSize(Files.size(file.toPath()));

		//setCreationTime
		gCal.clear();
		gCal.setTimeInMillis(jFileBasicAttrs.lastAccessTime().toMillis());
		eiasFileBasicAttrs.setLastAccessTime(this.dtFactory.newXMLGregorianCalendar(gCal));

		// isRegularFile
		eiasFileBasicAttrs.setIsRegularFile(jFileBasicAttrs.isRegularFile());

		// isDirectory
		eiasFileBasicAttrs.setIsDirectory(jFileBasicAttrs.isDirectory());

		// isSymbolicLink
		eiasFileBasicAttrs.setIsDirectory(jFileBasicAttrs.isSymbolicLink());

		// setIsOther
		eiasFileBasicAttrs.setIsOther(jFileBasicAttrs.isOther());

		//fileKey
		eiasFileBasicAttrs
				.setFileKey((jFileBasicAttrs.fileKey() == null) ? "unknown" : jFileBasicAttrs.fileKey().toString());
		return eiasFileBasicAttrs;
	}

	private void init() throws DatatypeConfigurationException {
		LOG.debug("Intializing File metadata types");
		this.objFactory = new ObjectFactory();
		this.dtFactory = DatatypeFactory.newInstance();

	}
}

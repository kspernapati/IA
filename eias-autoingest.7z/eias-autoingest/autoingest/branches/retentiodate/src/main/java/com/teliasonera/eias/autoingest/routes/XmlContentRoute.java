package com.teliasonera.eias.autoingest.routes;

import java.io.File;

import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.sip.ContentFileLinkerException;
import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.processor.ConfigProcessor;
import com.teliasonera.eias.autoingest.processor.ContentFileLinkerProcessor;
import com.teliasonera.eias.autoingest.processor.ContentFileMoveProcessor;
import com.teliasonera.eias.autoingest.processor.EmptyDirCleanupProcessor;
import com.teliasonera.eias.autoingest.processor.GlobalErrorHandler;
import com.teliasonera.eias.autoingest.processor.PrepareSipIngestProcessor;
import com.teliasonera.eias.autoingest.processor.SipProcessor;
import com.teliasonera.eias.autoingest.processor.XMLErrorHandler;
import com.teliasonera.eias.autoingest.processor.XMLTransformProcessor;
import com.teliasonera.eias.autoingest.processor.XMLValidatorProcessor;
import com.teliasonera.eias.autoingest.processor.exception.ContentFileMoverException;
import com.teliasonera.eias.autoingest.processor.exception.SipProcessorException;
import com.teliasonera.eias.autoingest.processor.exception.XMLProcessingException;
import com.teliasonera.eias.autoingest.processor.exception.XMLTransformException;
import com.teliasonera.eias.autoingest.processor.exception.XMLValidationException;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

/**
 * Apache Camel route for receiving "XML metadata + Content file" type files for EIAS ingestion Route is meant to be configured at runtime, thus not
 * declared as Spring Component
 * 
 * @author sce4799
 */
@Component
@Scope("prototype")
public class XmlContentRoute extends AIRoute {

	private static final Logger LOG = LoggerFactory.getLogger(XmlContentRoute.class);

	private static final int MISSING_FILE_DELIVERY_ATTEMPTS = 10;
	private static final long MISSING_FILE_DELIVERY_DELAY = 5000L;
	private static final long MISSING_FILE_MAX_DELIVERY_DELAY = 300000L;

	@Autowired
	protected ConfigProcessor configProcessor;

	@Autowired
	protected XMLValidatorProcessor validator;

	@Autowired
	protected XMLTransformProcessor transform;

	@Autowired
	private ContentFileMoveProcessor fileMover;

	@Autowired
	private ContentFileMoveProcessor fileErrorHandler;

	@Autowired
	private ContentFileLinkerProcessor linker;

	@Autowired
	private XMLErrorHandler xmlErrHandler;

	@Autowired
	private SipProcessor sipProcessor;

	@Autowired
	private PrepareSipIngestProcessor prepareIngestProcessor;
	
	@Autowired
	private EmptyDirCleanupProcessor emptyDirCleanupProcessor;

	@Autowired
	private GlobalErrorHandler globalErrorHandler;

	private int missingFileDeliveryAttempts;
	private long missingFileDeliveryDelay;
	private long missingFileMaxDeliveryDelay;

	// ================ Constructors ==============

	public XmlContentRoute() {
		super();
	}

	public XmlContentRoute(RouteType config) {
		super(config);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void configure() throws Exception {
		LOG.info("Started XMLContentRoute..");

		// ============== Initialization ===============

		// Initialize XML processors
		LOG.debug("Initialize XML processors..");
		this.configProcessor.setConfig(this.config);
		this.validator.setSchema(new File(this.config.getIncomingXmlValidation().getFile()));
		this.transform.setXslt(new File(this.config.getIncomingXmlTransform().getFile()));

		// Set up content file mover for successful files
		this.fileMover.setConfig(this.config);
		this.fileMover.setTargetDir(this.config.getSipProcessorWorkDirEndpoint().getName());

		// Set up content file mover for failures
		LOG.debug("Set up error handlers..");
		this.fileErrorHandler.setConfig(this.config);
		this.fileErrorHandler.setTargetDir(this.config.getErrorDirEndpoint().getName());
		this.fileErrorHandler.setErrorMover(true);

		// Setup Exception processor
		xmlErrHandler.setConfig(config);

		// Initialize content file linker
		this.linker.setConfig(this.config);

		// Initialize SIP processor
		this.sipProcessor.setConfig(this.config);

		// Initialize prepare ingest processor
		this.prepareIngestProcessor.setConfig(this.config);

		// Initialize global error handler
		LOG.debug("Initializing Global Error Handler..");
		this.globalErrorHandler.setConfig(config);

		// Initialize constants from config
		LOG.debug("Initialize constants from config..");
		this.initConst();


		// ============== Route configuration ===============

		// Global error handler
		// All exceptions here are handled by GlobalErrorHandler. No redeliveries
		errorHandler(deadLetterChannel(CommonUtils.getCamelURI(this.config.getErrorDirEndpoint()))
			.onPrepareFailure(this.fileErrorHandler)	// Handle moving content files if any
			.onPrepareFailure(this.globalErrorHandler)	// Perform global handling
			.maximumRedeliveries(0)
			.loggingLevel(LoggingLevel.ERROR)
			.logNewException(true)
			.logStackTrace(true)); 

		// =======================================
		// File receiver route
		// Receive incoming files, apply XSD validation and XSLT and move files +  content  to SIP work dir

		LOG.debug("XML ContentRoute FileEndPoint .." + this.config.getIncomingFileEndpoint());

		from(CommonUtils.getCamelURI(this.config.getIncomingFileEndpoint())).id(this.config.getName() + "-XmlAndContentEndpoint")
			.description(this.config.getName() + "-IncomingXMLContent", "Incoming XML + Content processing", null)
			.onException(XMLProcessingException.class, XMLValidationException.class, XMLTransformException.class) // Exception handler: XML exceptions  are  irrecoverable, fail  immediately
				.maximumRedeliveries(0) // No retries for XML errors
				.useOriginalMessage() // Original message is stored in case processing causes corruption
				.process(this.xmlErrHandler).id(this.config.getName() + "-XmlErrorHandler") // Log & process the exception
				.process(this.fileErrorHandler).id(this.config.getName() + "-FileErrorHandler") // Move related content files to error folder
				.end()
			.process(this.configProcessor).id(this.config.getName() + "-ConfigProcessor") // Append configuration options into  message header
			.choice().id(this.config.getName() + "-DoXMLValidation") // Do XML validation if enabled in routeconfig
				.when(simple("${in.headers." + ConfigProcessor.XML_VALIDATION + "}"))
				.log(LoggingLevel.DEBUG, "XML_VALIDATION enabled.Triggering Validation")
				.process(this.validator).id(this.config.getName() + "-ValidateXML") // Validate XML files
				.end()
			.choice().id(this.config.getName() + "-DoXMLTransform") // Do XML transform if enabled in routeconfig
				.when(simple("${in.headers." + ConfigProcessor.XML_TRANSFORM + "}"))
				.log(LoggingLevel.DEBUG, "XML_TRANSFORM enabled.Triggering Transformation")
				.process(this.transform).id(this.config.getName() + "-TransformXML") // Transform validated XML files
				.end()
			.onException(ContentFileMoverException.class, ContentFileLinkerException.class) // Error handler for the case if content file is not present at the time of processing
				.maximumRedeliveries(this.missingFileDeliveryAttempts) // Retry content file move for a number of times
				.redeliveryDelay(this.missingFileDeliveryDelay) // Set the delay  between  retry attempts
				.useExponentialBackOff() // Increase retry delay each time
				.maximumRedeliveryDelay(this.missingFileMaxDeliveryDelay)
				.log(LoggingLevel.ERROR, LOG,simple("One of the content files not found! Message ${in.headers.CamelFileName} will be failed!").getText())
				.process(this.fileErrorHandler).id(this.config.getName() + "-FileErrorHandler") // Move related content files to  error folder
				.end() //end of the exception handling
			.threads(this.config.getReceiverThreadPoolSize())
			.process(this.fileMover).id(this.config.getName() + "-FileMover") // Move related content files to target folder
				.choice().id(this.config.getName() + "-DoContentLinking") // Do content linking if  enabled in routeconfig
				.when(simple("${in.headers." + ConfigProcessor.CONTENT_FILE_LINKING + "}"))
				.log(LoggingLevel.DEBUG, "CONTENT_FILE_LINKING enabled.Triggering Linking") // Validate XML files
				.process(this.linker).id(this.config.getName() + "-ContentFileLinker") // Add common-format content file links to  the XML
				.end()
			.to("log:com.teliasonera.eias.autoingest.routes.XMLContentRoute?level=INFO&groupSize=100")
			.to(CommonUtils.getCamelURI(this.config.getSipProcessorWorkDirEndpoint())).id(this.config.getName() + "-SipProcessorEndpoint");

		// ============================================
		// SIP Processing route
		// Generates SIP packages from files present in the work dir
		// Quartz scheduler for SIP processing
		LOG.debug("Starting SIP Generation route..");
		from(CommonUtils.getCamelURI(this.config.getSipProcessScheduler())).id(this.config.getName() + "-SipProcessorScheduler") //CRON based SIP scheduler
			.description(this.config.getName() + "-SIPGeneration", "SIP Package Processing", null)
			.onException(SipProcessorException.class)
				.maximumRedeliveries(0)//If SIP processing fails for some reason, retry is  not possible
				.handled(true) // true since we have handled exception
				.process(this.xmlErrHandler).id(this.config.getName() + "-XMLErrorHandler") // Log the received error
				.end()
			.process(this.sipProcessor).id(this.config.getName() + "-SipProcessor")
			.to("log:com.teliasonera.eias.autoingest.routes.XMLContentRoute?level=INFO").id(this.config.getName() + "-Log");

		// =====================================
		// InfoArchive 4.0 ingestion using the REST API
		// Ingestion queue is using ActiveMQ message queue
		// Ingestion errors are handled in the REST ingestion route

		if(this.config.isIngestEnabled()) {
			LOG.debug("Starting Archiving route..");

			from(CommonUtils.getCamelURI(this.config.getIngestQueueDirEndpoint())).id(this.config.getName() + "-SipIngestEndpoint")
				.description(this.config.getName() + "-SipIngestion", "Send processed SIP to ingestion", null)
				.process(this.prepareIngestProcessor).id(this.config.getName() + "-PrepareIngestProcessor")
				.setExchangePattern(ExchangePattern.InOnly)
				.to(IAIngestServiceRoute.INGEST_SERVICE_URI).id(this.config.getName() + "-IngestQueueEndpoint");
		}
		else {
			LOG.info("Ingestion for the route [" + this.config.getName() + "] has been disabled!");
		}

		// =====================================
		// Incoming directory cleanup of empty directories. Used if enabled in configuration
		// Camel doesn't delete directories when the content files are moved away. This task can 
		// be used to clean up empty subdirs from the incoming (or any other) directory
		
		if(this.config.getIncomingEmptyDirCleanup().isEnabled()) {
			LOG.debug("Starting incoming dir cleanup scheduler route..");
			
			// Set up dir cleanup processor
			this.emptyDirCleanupProcessor.setTarget(new File(this.config.getIncomingEmptyDirCleanup().getTargetPath()));
			
			from(CommonUtils.getCamelURI(this.config.getIncomingEmptyDirCleanup().getScheduler())).id(this.config.getName() + "-IncomingDirCleanup")
				.description(this.config.getName() + "-EmptyDirCleanup", "Clean up empty subdirs in incoming directory", null)
				.log(LoggingLevel.INFO, "Cleaning up empty subdirectories in the incoming directory...")
				.process(this.emptyDirCleanupProcessor);
		}
	}

	/**
	 * Try to initialize constants from config, fall back to defaults
	 */

	private void initConst() {

		if (this.config.getMissingFileDeliveryAttempts() == null)
			this.missingFileDeliveryAttempts = MISSING_FILE_DELIVERY_ATTEMPTS;
		else
			this.missingFileDeliveryAttempts = this.config.getMissingFileDeliveryAttempts();

		if (this.config.getMissingFileDeliveryDelay() == null)
			this.missingFileDeliveryDelay = MISSING_FILE_DELIVERY_DELAY;
		else
			this.missingFileDeliveryDelay = this.config.getMissingFileDeliveryDelay();

		if (this.config.getMissingFileMaxDeliveryDelay() == null)
			this.missingFileMaxDeliveryDelay = MISSING_FILE_MAX_DELIVERY_DELAY;
		else
			this.missingFileMaxDeliveryDelay = this.config.getMissingFileMaxDeliveryDelay();
	}
}

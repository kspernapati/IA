package com.teliasonera.eias.autoingest.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.beans.email.MailService;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

/**
 * Class responsible for handling the exceptions globally <br>
 * This will extract data from exchange pacakge and move to error end point.
 * Logs error in the log file. Notify support team by sending email.
 */

@Component
@Scope("prototype")
public class GlobalErrorHandler implements Processor {
	
    private static final Logger LOG = LoggerFactory.getLogger(GlobalErrorHandler.class);
    
    @Autowired
    MailService mail;

    private RouteType config;

    public RouteType getConfig() {
        return config;
    }

    /**
     * @param config
     */
    public void setConfig(RouteType config) {
        this.config = config;
    }

    /**
     * Global error handling, mainly produces logs for the errors
     */
    
    @Override
    public void process(Exchange exchange) throws Exception {
        Exception excep = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        LOG.error("Error happened at Global Error handler", excep);
        String message = "No message";
        if (exchange.getIn().getHeaders().containsKey("CamelFileAbsolutePath")) {
            String srcfilePath = exchange.getIn().getHeader("CamelFileAbsolutePath").toString();
            LOG.debug(String.format("Moving... src [file] %s to the Error location [%s]", new Object[] {srcfilePath, config.getErrorDirEndpoint().getName()}));
//            FileUtils.moveToDirectory(new File(srcfilePath), new File(config.getErrorDirEndpoint().getName()), true);
//            message = String.format("Moved src [file] %s to the Error location [%s]", new Object[] {srcfilePath, config.getErrorDirEndpoint().getName()});
            LOG.debug(message);
        }
        mail.notifyRouteError(excep, message, getConfig(), exchange);
    }

}

package com.teliasonera.eias.autoingest.common;

public final class IAConstants {

	public static final String IA_TOKEN_TYPE = "token_type";
	public static final String IA_ACCESS_TOKEN = "access_token";
	public static final String IA_USERNAME = "username";
	public static final String IA_PASSWORD = "password";
	public static final String IA_APP_NAME = "application_name";
	public static final String IA_TENANT_NAME = "tenant_name";
	public static final String IA_TENANT_UUID = "tenant_uuid";
	public static final String IA_APP_UUID = "application_uuid";
	public static final String IA_SIP_FORMAT = "sip_zip";
	public static final String IA_AIP_UUID = "aip_uuid";
	public static final String IA_LOGIN_EXPIRY = "login_expiry_time";
	public static final String IA_ORIG_EXCHANGE_ID = "original_exchange_id";
}

package com.teliasonera.eias.autoingest.beans.routemgmt;

import org.apache.commons.lang.NotImplementedException;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.routeconfig.RouteTypeType;
import com.teliasonera.eias.autoingest.routes.AIRoute;
import com.teliasonera.eias.autoingest.routes.ContentOnlyRoute;
import com.teliasonera.eias.autoingest.routes.SipOnlyRoute;
import com.teliasonera.eias.autoingest.routes.XmlContentRoute;
import com.teliasonera.eias.autoingest.routes.XmlOnlyRoute;

/**
 * This class is using Spring Lookup method capability to instantiate correct Camel route prototype
 * according to the given parameter. Class is declared as abstract and Spring will extend it dynamically.
 * 
 * Look for Spring documentation for more information on the Lookup capability
 * 
 * @author sce4799
 *
 */

@Component
@Scope("singleton")
public class AIRouteFactory {

	public AIRouteFactory() {}

	public AIRoute getRouteInstance(RouteTypeType type) {
		
		// Add new route templates to the switch statement if needed. Also create an abstract lookup method for the template.
		
		switch (type) {
			case XML_CONTENT_ROUTE:
				return this.getXmlContentRoute();
			case XML_ONLY_ROUTE:
				return this.getXmlOnlyRoute();
			case CONTENT_ONLY_ROUTE:
				return this.getContentOnlyRoute();
			case SIP_ONLY_ROUTE:
				return this.getSipOnlyRoute();
			default:
				throw new NotImplementedException("The AutoIngest route of type [" + type.value() + "] has not been implemented!");
		}
	}
	
	// Lookup methods that will be dynamically implemented by Spring by overriding below implementations. 
	// Make sure the Route templates referenced here are defined with 'prototype' scope!
	
	@Lookup("xmlContentRoute")
	public XmlContentRoute getXmlContentRoute() {
		return null;
	}
	
	@Lookup("contentOnlyRoute")
	public ContentOnlyRoute getContentOnlyRoute() {
		return null;
	}
	
	@Lookup("xmlOnlyRoute")
	public XmlOnlyRoute getXmlOnlyRoute() {
		return null;
	}
	
	@Lookup("sipOnlyRoute")
	public SipOnlyRoute getSipOnlyRoute() {
		return null;
	}
}

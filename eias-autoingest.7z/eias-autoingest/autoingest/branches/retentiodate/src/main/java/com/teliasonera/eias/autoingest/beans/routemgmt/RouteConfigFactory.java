package com.teliasonera.eias.autoingest.beans.routemgmt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import com.teliasonera.eias.autoingest.beans.xml.XMLValidator;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;

@Component
@Scope("singleton")
public class RouteConfigFactory {

    private static final Logger LOG = LoggerFactory.getLogger(RouteConfigFactory.class);

    @Autowired
    private XMLValidator validator;

    private RouteConfigFactory() {
    }

    /**
     * Return a new RouteConfig object for the given schema and XML file
     * 
     * @param schemaFile
     * @param xmlFile
     * @return
     * @throws JAXBException
     * @throws SAXException
     * @throws FileNotFoundException
     */

    public RouteConfig getRouteConfig(File schemaFile, File xmlFile) throws JAXBException, SAXException, FileNotFoundException {

        if (schemaFile == null || xmlFile == null) {
            throw new FileNotFoundException("Input file is null!");
        }

        return this.getRouteConfig(new FileInputStream(schemaFile), new FileInputStream(xmlFile));
    }

    /**
     * Return a new RouteConfig object for the given schema and XML file
     * 
     * @param schemaFile
     * @param xmlFile
     * @return
     * @throws JAXBException
     * @throws SAXException
     */

    public RouteConfig getRouteConfig(InputStream schemaFile, InputStream xmlFile) throws JAXBException, SAXException {

        try {
            JAXBContext ctx = JAXBContext.newInstance(RouteConfig.class);
            Schema schema = this.validator.getSchema(schemaFile);
            Unmarshaller unmarshaller = ctx.createUnmarshaller();
            unmarshaller.setSchema(schema);

            return (RouteConfig)unmarshaller.unmarshal(xmlFile);
        } catch (Exception e) {
            throw e;
        } finally {
            try {
                if (schemaFile != null)
                    schemaFile.close();
                if (xmlFile != null)
                    xmlFile.close();
            } catch (IOException e) {
                LOG.error("Error closing streams", e);
            }
        }
    }
}

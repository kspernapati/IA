package com.teliasonera.eias.autoingest.processor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.core.MediaType;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.processor.exception.IARestException;

@Component
@Scope("prototype")
public class AppUrlRequestProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(AppUrlRequestProcessor.class);
	
	private static final Pattern UUIDPattern = Pattern.compile("^.*/systemdata/tenants/(.*)$");

	public AppUrlRequestProcessor() {}

	@Override
	public void process(Exchange exchange) throws Exception {
		
		Message msg = null;
		
		if(exchange.hasOut()) {
			msg = exchange.getOut();
		}
		else {
			msg = exchange.getIn();
		}
		
		// Get the previous response & extract the tenant info
		JSONObject resp = new JSONObject(msg.getBody(String.class));
		JSONObject data = resp.getJSONObject("_embedded");
		
		JSONArray tenants = data.getJSONArray("tenants");
		
		// Find the tenant by name
		LOG.debug("Finding the InfoArchive tenant...");
		
		JSONObject links = null;
		
		for(int i=0; i < tenants.length(); i++) {
			JSONObject tenant = tenants.getJSONObject(i);
			
			if(tenant.getString("name").equals(exchange.getProperty(IAConstants.IA_TENANT_NAME))) {
				LOG.debug("Selected tenant: " + tenant.getString("name"));
				links = tenant.getJSONObject("_links");
				break;	// Loop can exit now, the tenant was found
			}
		}
		
		// Correct IA tenant was not found, exit!
		if(links == null) {
			throw new IARestException("InfoARchive tenant [" + exchange.getProperty(IAConstants.IA_TENANT_NAME) + "] not found!");
		}
		
		// Get the tenant UUID from the content link
		String link = links.getJSONObject("self").getString("href").trim();
		LOG.debug("Link found: " + link);
		Matcher m = UUIDPattern.matcher(link);
		m.matches();
		String uuid = m.group(1);
		
		if(uuid ==  null || uuid.equals("")) {
			throw new IARestException("Could not find tenant UUID for tenant [" + exchange.getProperty(IAConstants.IA_TENANT_NAME) + "]");
		}
		
		// Set the UUID as exchange property
		exchange.setProperty(IAConstants.IA_TENANT_UUID, uuid);
		
		LOG.debug("Tenant UUID found: " + uuid);
		
		// Set properties for the new message
		
		Message newMsg = exchange.getIn();
		
		// Set message headers
		newMsg.setHeader(CxfConstants.OPERATION_NAME, "getApplicationInfo");
		newMsg.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.FALSE);
		newMsg.setHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);
		
		// Set parameters, get access token from exchange property
		newMsg.setBody(new Object[] {exchange.getProperty(IAConstants.IA_TOKEN_TYPE) + " " + exchange.getProperty(IAConstants.IA_ACCESS_TOKEN), uuid});
	}

}

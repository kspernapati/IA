package com.teliasonera.eias.autoingest.bootstrap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import io.hawt.config.ConfigFacade;

@Configuration
public class HawtioConfiguration extends WebMvcConfigurerAdapter {
	
	/**
	 * Set things up to be in offline mode
	 * @return
	 * @throws Exception
	 */
	
	@Value("${hawtio.username")
	private String hawtioUsername;
	
	@Value("${hawtio.password")
	private String hawtioPassword;
	
	@Bean
	public ConfigFacade configFacade() throws Exception {
		ConfigFacade config = new ConfigFacade() {
			@Override
			public boolean isOffline() {
				return true;
			}
		};
		config.init();
		return config;
	}
	
	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addRedirectViewController("/", "/hawtio/index.html");
		registry.addViewController("/hawtio").setViewName("forward:/hawtio/index.html");
	}
}

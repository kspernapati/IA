package com.teliasonera.eias.autoingest.processor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.processor.exception.IARestException;

@Component
@Scope("prototype")
public class AipURLResponseProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(AipURLResponseProcessor.class);
	
	private static final Pattern AipUuidPattern = Pattern.compile("^.*/systemdata/applications/(.*)$");

	public AipURLResponseProcessor() {}

	@Override
	public void process(Exchange exchange) throws Exception {
		
		Message msg = null;
		
		if(exchange.hasOut()) {
			msg = exchange.getOut();
		}
		else {
			msg = exchange.getIn();
		}
		
		// Get the application AIP UUID from the response
		
		LOG.debug("Finding the correct IA application...");
		
		JSONObject resp = new JSONObject(msg.getBody(String.class));
		JSONArray apps = resp.getJSONObject("_embedded").getJSONArray("applications");
		
		JSONObject links = null;
		
		// Find the application by name
		for(int i=0; i < apps.length(); i++) {
			JSONObject app = apps.getJSONObject(i);
			
			if(app.getString("name").equals(exchange.getProperty(IAConstants.IA_APP_NAME))) {
				LOG.debug("Selected application with name " + app.getString("name"));
				links = app.getJSONObject("_links");
				break;	// Correct application found
			}
		}
		
		if(links == null) {
			throw new IARestException("Application with name [" + exchange.getProperty(IAConstants.IA_APP_NAME) + "] was not found!");
		}
		
		// Get the applciation UUID from the content link
		String link = links.getJSONObject("self").getString("href").trim();
		Matcher m = AipUuidPattern.matcher(link);
		m.matches();
		String uuid = m.group(1);
		
		if(uuid == null || uuid.equals("")) {
			throw new IARestException("Application UUID could not be found for application [" + exchange.getProperty(IAConstants.IA_APP_NAME) + "]");
		}
		
		// Save the UUID in exchange parameters
		exchange.setProperty(IAConstants.IA_APP_UUID, uuid);
	}

}
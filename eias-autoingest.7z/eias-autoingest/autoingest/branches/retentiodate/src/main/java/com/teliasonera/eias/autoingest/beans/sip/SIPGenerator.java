package com.teliasonera.eias.autoingest.beans.sip;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.emc.eas.sip.ObjectFactory;
import com.emc.eas.sip.Sip;
import com.emc.eas.sip.Sip.Dss;
import com.teliasonera.eias.autoingest.beans.xml.XPathQueryUtil;
import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

import net.sf.saxon.tree.tiny.TinyElementImpl;

/**
 * 
 * Class is responsible for generating the SIP packages. 
 * 
 * Generation of multi-sip DSS sets can be enabled by configuration.
 * 
 * NOTE: SIP GENERATOR DOES NOT SUPPORT MULTI-THREADING IN CAMEL LEVEL.
 * 
 * The PDI generation and SIP compressing tasks are multi-threaded at SIPGenerator level using a TaskExecutor
 * 
 * @author sce4799
 */
@Component
@Scope("prototype")
public class SIPGenerator {

	private static final Logger LOG = LoggerFactory.getLogger(SIPGenerator.class);

	private static final String DIR_PREFIX = "eias_autoingest_";
	
	public static final String SIP_XML_NAME = "eas_sip.xml";

	public final int MOVE_ERROR_RETRY = 5;

	@Autowired
	private ThreadPoolTaskExecutor executor;
	
	@Autowired
	private XPathQueryUtil xpUtil;
	
	@Autowired
	private PDICreatorFactory pdiCreatorFactory;

	private RouteType config;
	private ObjectFactory objFactory;
	private DatatypeFactory dtFactory;

	private int maxFiles;
	private long maxSize;
	private File baseDir;

	// Contains generated SIP instances and target SIP dir references as result from the distribute task
	private Map<Sip, File> sipDirs;

	// Constructor
	private SIPGenerator() {}

	public void setConfig(RouteType config) {
		this.config = config;
	}

	public void generateSIPs() throws Exception {
		// Start SIP generation
		this.init();

		// Check if subdirectories or ZIP files exist in the work dir. This means previous  SIP packaging run was
		// most likely terminated prematurely. In this case, try to recover the files from incomplete SIPs and
		// include them in this processing run

		File[] subdirs = this.baseDir.listFiles((FileFilter) DirectoryFileFilter.INSTANCE);
		
		LOG.debug("Sub directories " + subdirs.toString());
		  
		// Go through subdirs (if any) and recover files
		for (File dir : subdirs) {
		      LOG.info("Started recovering files from "+dir.getPath());
		 
		    // Ignore current dir
		    if (dir.getAbsolutePath().equals(this.baseDir.getAbsolutePath()))
		        continue;
		
		    boolean result = this.recoverFiles(dir);
		    if (!result)
		        LOG.error("Recovering incompleted SIP run files for " + dir.getAbsolutePath() + " was unsuccessful! Please check logs for errors!");
		}
		
		// Distribute files into SIP package working dirs

		LOG.info("Starting processing SIP files...");
		
		// List all XML files in the directory
		Collection<File> xmlFiles = FileUtils.listFiles(this.baseDir,
				new SuffixFileFilter(this.config.getMetadataFileExtension(), IOCase.INSENSITIVE), null);
		
		if (xmlFiles.size() == 0) { // No files found to process!
			LOG.info("SIPGenerator completed successfully. No files were processed!");
			return;
		}
		
		this.distributeFiles(xmlFiles);
		
		LOG.info("Files distributed successfully into SIP directories");

		// Spawn SIP generator tasks for all SIP packages to be generated and send to the executor pool
		
		List<Future<?>> taskResults = new ArrayList<>();
		File ingestQueueDir = new File(this.config.getIngestQueueDirEndpoint().getName());
		
		for(Sip sip : this.sipDirs.keySet()) {
			PDICreator instance = this.pdiCreatorFactory.getPDICreator();
			instance.setConfig(this.config);
			SipGenerationTask task = new SipGenerationTask(this.sipDirs.get(sip), ingestQueueDir, sip, instance);
			taskResults.add(this.executor.submit(task));
		}
	}

	/**
	 * Initialise the SIP processor
	 * 
	 * @throws DatatypeConfigurationException
	 */

	private void init() throws DatatypeConfigurationException {
		LOG.debug("Intializing SIP data types..");
		this.objFactory = new ObjectFactory();
		this.dtFactory = DatatypeFactory.newInstance();
		this.sipDirs = new HashMap<>();
		this.maxFiles = this.config.getMaxObjectsPerSIP().intValue();
		this.maxSize = this.config.getMaxCiSizePerSIP().longValue();
		this.baseDir = new File(this.config.getSipProcessorWorkDirEndpoint().getName());
	}

	/**
	 * Initialize the DSS section of the SIP XML. This is shared between all sub-packages if isMultiSipDSS is enabled in the configuration.
	 * Otherwise new DSS is generated for each SIP package.
	 */

	private Dss createNewDss() {
		Dss dss = this.objFactory.createSipDss();
		
		XMLGregorianCalendar configRetentionDate = this.config.getBaseRetentionDate();

		GregorianCalendar now = (GregorianCalendar) GregorianCalendar.getInstance();
		//GregorianCalendar bRetentionDate = new GregorianCalendar();
		//bRetentionDate.setTime(configRetentionDate);
		
				
		XMLGregorianCalendar c = this.dtFactory.newXMLGregorianCalendar(now);
		dss.setApplication(this.config.getApplicationName());
		
		if (configRetentionDate != null)
			dss.setBaseRetentionDate(configRetentionDate);	
		else	
			dss.setBaseRetentionDate(c); // Retention date is set to the time DSS is produced
		
		dss.setEntity(this.config.getEntityName());
		dss.setHolding(this.config.getHoldingName());
		dss.setId(CommonUtils.getSipID(this.config.getArchiveID()));
		dss.setPdiSchema(this.config.getPdiSchema());
		dss.setPriority(0); //Default priority used
		dss.setProducer(this.config.getProducerName());
		dss.setProductionDate(c);

		return dss;
	}
	
	/**
	 * Return a new SIP instance, initialize it and create associated work directory
	 * 
	 * @param index
	 * @return
	 */

	private Sip createNewSIP(int index, Dss dss) {
		GregorianCalendar now = (GregorianCalendar) GregorianCalendar.getInstance();
		XMLGregorianCalendar cal = this.dtFactory.newXMLGregorianCalendar(now);
		Sip sip = this.objFactory.createSip();
		sip.setDss(dss);
		sip.setProductionDate(cal);
		sip.setSeqno(1);
		sip.setIsLast(true);
		// Create the work dir for this SIP file
		File workDir = new File(this.baseDir, DIR_PREFIX + dss.getId() + "_" + index);
		this.sipDirs.put(sip, workDir);

		return sip;
	}

	/**
	 * Distribute files in the collection into subdirs (working dirs) to build the actual SIP files included in the DSS. Metadata XML and associated
	 * content files are moved to these directories.
	 * 
	 * @param xmlFiles
	 * @throws XPathExpressionException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */

	private void distributeFiles(Collection<File> xmlFiles) throws XPathExpressionException, FileNotFoundException, IOException {
		// Process each metadata file
		int aiuCnt = 0;
		long size = 0;
		int sipCnt = 1;

		LOG.debug("Started distributing files to SIP dirs");
		
		// Create initial SIP & DSS
		Dss currentDss = this.createNewDss();
		Sip currentSip = this.createNewSIP(sipCnt, currentDss);
		
		Iterator<File> itr = xmlFiles.iterator();
		
		while (itr.hasNext()) {
			File xml = itr.next();
			List<File> contentFiles = this.getContentFiles(xml);
			// Move files
			aiuCnt++;
			LOG.debug(String.format("xml File [%s] with content Files [%s] to dir [%s]", xml, contentFiles, sipDirs.get(currentSip)));
			try {
				FileUtils.moveFileToDirectory(xml, sipDirs.get(currentSip), true);
			} catch (Exception e1) {
				if (!isRetryASucess(currentSip, xml, e1))
					throw e1;
			}
			LOG.debug(String.format("Moving xml File[%s] with content Files [%s] to dir [%s]", xml, contentFiles, sipDirs.get(currentSip)));
			for (File f : contentFiles) {
				size += f.length();
				try {
					FileUtils.moveFileToDirectory(f, sipDirs.get(currentSip), true);
				} catch (Exception e1) {
					if (!isRetryASucess(currentSip, f, e1))
						throw e1;
				}
			}

			// Check if new SIP needs to be created. Only run this block if there is still
			// more stuff to process. Otherwise allow loop to end.
			if ((aiuCnt >= this.maxFiles || size >= this.maxSize) && itr.hasNext()) {
				LOG.debug(String.format("Either Max AIU Count [%s] or Max Size [%s] reached for old SIP [%s]. creating new SIP", aiuCnt, size,
						currentSip));
				
				currentSip.setAiuCount(aiuCnt);
				
				if(this.config.isMultiSipDSS()) {	// Generate a single DSS from all SIP folders if MultiSipDSS is enabled
					currentSip.setIsLast(false); // setting the current SIP TO Complete 
					currentSip = this.createNewSIP(sipCnt, currentDss); // create new SIP with current DSS
				}
				else {	// Each SIP package will be a complete DSS on its own
					currentSip.setIsLast(true);
					currentDss = this.createNewDss();	// Create a new DSS element
					currentSip = this.createNewSIP(1, currentDss); // create new SIP with NEW DSS (seqno is always 1)
				}
				sipCnt++;
				aiuCnt = 0;
				size = 0;
			}
		}
		// Current SIP is now the last SIP in the set
		currentSip.setAiuCount(aiuCnt);
		currentSip.setIsLast(true);
	}

	/**
	 * Attempt to Retry
	 * @param currentDir
	 * @param file
	 * @param origExcp
	 * @return
	 * @throws Exception
	 */
	private boolean isRetryASucess(Sip currentDir, File file, Exception origExcp) {
		int rtrycnt = 0;
		boolean isRetrySuccess = false;
		if (currentDir == null || file == null || sipDirs.get(currentDir) == null) {
			return false;
		}
		LOG.warn("SILENT & IGNORE: Failed to move for [" + file + "] [" + rtrycnt + "] time(s).. Retrying to recover...........", origExcp);
		while (rtrycnt <= this.MOVE_ERROR_RETRY) {
			rtrycnt = rtrycnt + 1;
			try {
				LOG.debug("Retrying move for [" + file + "]  [" + rtrycnt + "] time(s)...............");
				FileUtils.moveFileToDirectory(file, sipDirs.get(currentDir), true);
				isRetrySuccess = true;
				LOG.info("SUCCESS in Retrying move for [" + file + "] [" + rtrycnt + "] time(s)...............");
				break;
			} catch (Exception e) {
				LOG.warn("SILENT & IGNORE: Failed move for [" + file + "] [" + rtrycnt + "] time(s).. Retrying to recover...........", e);
			}
		}
		return isRetrySuccess;
	}

	/**
	 * List all content files associated with this metadata file
	 * 
	 * @param xml
	 * @return
	 * @throws XPathExpressionException
	 * @throws IOException
	 */

	private List<File> getContentFiles(File xml) throws XPathExpressionException, IOException {
		List<File> files = new ArrayList<>();

		@SuppressWarnings("unchecked")
		List<TinyElementImpl> names = (List<TinyElementImpl>) xpUtil.queryDocument(new FileInputStream(xml), this.config.getCommonContentLink(),
				XPathConstants.NODESET);
		for (TinyElementImpl name : names) {
			files.add(new File(this.baseDir, name.getStringValue()));
		}
		return files;
	}

	/**
	 * Try to recover files from previously terminated SIP processing run. Moves files to baseDir so that they can be included in the new processing
	 * run. If this fails, just log the errors since the the situation may not be possible to recover at run-time
	 * 
	 * @param dir
	 * @return
	 */

	 private boolean recoverFiles(File dir) {
	
	    LOG.info("Starting SIP folder recovery run for folder: " + dir.getAbsolutePath());
	
	    File xmlBackupDir = new File(dir, PDICreator.XML_BACKUP_DIR);
	    File easSipXML = new File(dir, SIP_XML_NAME);
	    File easPdiXML = new File(dir, PDICreator.PDI_FILENAME);
	
	    boolean isSuccessful = true;
	
	    // Recover XML files from backup
	    if (xmlBackupDir.exists()) {
	        Collection<File> files = FileUtils.listFiles(xmlBackupDir, new SuffixFileFilter("xml", IOCase.INSENSITIVE), null);
	
	        for (File f : files) {
	            try {
	                FileUtils.moveFileToDirectory(f, this.baseDir, false);
	            } catch (IOException e) {
	                LOG.error("Error while trying to recover XML file " + f.getAbsolutePath(), e);
	                isSuccessful = false;
	            }
	        }
	    }
	
	    // Delete PDI and SIP XML files if they exist
	    if (easSipXML.exists())
	        easSipXML.delete();
	
	    if (easPdiXML.exists())
	        easPdiXML.delete();
	
	    // Move the rest of the files to baseDir
	    Collection<File> files = FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, null);
	
	    for (File f : files) {
	        try {
	            FileUtils.moveFileToDirectory(f, this.baseDir, false);
	        } catch (IOException e) {
	            LOG.error("Error while trying to recover file " + f.getAbsolutePath(), e);
	            isSuccessful = false;
	        }
	    }
	
	    // If everything was successful it's safe to delete the old working dir
	    if (isSuccessful) {
	        try {
	            FileUtils.deleteDirectory(dir);
	        } catch (IOException e) {
	            LOG.error("Error removing old SIP working dir: " + dir.getAbsolutePath(), e);
	        }
	    }
	
	    // All done
	    LOG.info("Recovery run for folder " + dir.getAbsolutePath() + " completed.");
	
	    return isSuccessful;
	}
}

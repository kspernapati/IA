package com.teliasonera.eias.autoingest.processor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.core.MediaType;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.processor.exception.IARestException;

@Component
@Scope("prototype")
public class IngestSipRequestProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(IngestSipRequestProcessor.class);
	
	private static final Pattern ingestPattern = Pattern.compile("^.*/systemdata/aips/(.*)/ingest$");

	public IngestSipRequestProcessor() {}
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		exchange.setPattern(ExchangePattern.InOut);
		
		Message msg = exchange.getIn();

		// Get the Receive SIP response message
		LOG.debug("body class is " + msg.getBody().getClass().getName());
		
		JSONObject response = new JSONObject(exchange.getIn().getBody(String.class));
		
		// Check that the SIP is in correct state
		if(!response.getString("state").equalsIgnoreCase("Waiting ingestion")) {
			LOG.debug("Incorrect SIP state: " + response.getString("state"));
			throw new IARestException("Received SIP is not in correct state for ingestion. Current state is [" + response.getString("state") + "]");
		}
		
		// Extract the AIP id
		
		JSONObject links = response.getJSONObject("_links");
		
		Matcher m = ingestPattern.matcher(links.getJSONObject("http://identifiers.emc.com/ingest").getString("href"));
		m.matches();
		String aipId = m.group(1);
		
		// Set AIP ID as exchange property
		exchange.setProperty(IAConstants.IA_AIP_UUID, aipId);
		
		// Prepare ingest message
		// This message needs to be sent using the CXFRS HTTP API, the proxy API sets unwanted headers that can't be removed later
		
		msg.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.TRUE);
		msg.setHeader(Exchange.HTTP_METHOD, "PUT");
		msg.setHeader(Exchange.HTTP_PATH, links.getJSONObject("http://identifiers.emc.com/ingest").getString("href"));
		msg.setHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON);
		msg.setHeader("Authorization", exchange.getProperty(IAConstants.IA_TOKEN_TYPE) + " " + exchange.getProperty(IAConstants.IA_ACCESS_TOKEN));
		
		// Reset body
		msg.setBody(null);
	}
}

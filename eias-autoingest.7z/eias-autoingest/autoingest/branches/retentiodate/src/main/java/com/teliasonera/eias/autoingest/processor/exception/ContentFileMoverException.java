package com.teliasonera.eias.autoingest.processor.exception;

public class ContentFileMoverException extends Exception {

    private static final long serialVersionUID = 7434888155387057296L;

    public ContentFileMoverException() {
    }

    public ContentFileMoverException(String message) {
        super(message);
    }

    public ContentFileMoverException(Throwable cause) {
        super(cause);
    }

    public ContentFileMoverException(String message, Throwable cause) {
        super(message, cause);
    }

    public ContentFileMoverException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause);
    }

}

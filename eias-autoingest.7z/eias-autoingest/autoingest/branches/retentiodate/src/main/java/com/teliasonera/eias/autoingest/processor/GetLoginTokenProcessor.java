package com.teliasonera.eias.autoingest.processor;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.processor.exception.IARestException;

@Component
@Scope("singleton")
public class GetLoginTokenProcessor implements Processor {
	
	private static final Logger LOG = LoggerFactory.getLogger(GetLoginTokenProcessor.class);
	private static final SimpleDateFormat FORMAT = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	
	public GetLoginTokenProcessor() {}
	
	// Camel templates
	private ProducerTemplate producer;
	
	public void setProducer(ProducerTemplate producer) {
		this.producer = producer;
	}
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		// Request new login token and embed it into the incoming Exchange
		Endpoint endpoint = exchange.getContext().getEndpoint("direct:getLoginToken");
		Exchange request = endpoint.createExchange(ExchangePattern.InOut);
		
		this.processRequest(request, exchange.getProperty(IAConstants.IA_USERNAME), exchange.getProperty(IAConstants.IA_PASSWORD));
		
		if(this.producer == null) {
			LOG.error("ProducerTemplate is null!");
			throw new IARestException("ProducerTemplate not initialized!");
		}
		
		// Put original exchange ID as exchange parameter. This allows to fetch original message in case 
		// in needs to be put to the ActiveMQ re-delivery queue
		request.setProperty(IAConstants.IA_ORIG_EXCHANGE_ID, exchange.getProperty(IAConstants.IA_ORIG_EXCHANGE_ID, String.class));
		
		// Send to IAWA endpoint
		Exchange response = this.producer.send(endpoint, request);
		
		// Check if request was successful
		if(response.isFailed()) {
			LOG.debug("Login token request failed, throwing the exception further");
			throw response.getException();
		}
		
		Map<String, Object> props = this.processResponse(response);
		
		// Map login token values to original exchange properties
		for(String prop : props.keySet()) {
			exchange.setProperty(prop, props.get(prop));
		}
	}

	/**
	 * Process login token request
	 * 
	 * @param exchange
	 * @throws Exception
	 */
	
	private void processRequest(Exchange exchange, Object username, Object password) throws Exception {
		
		Message msg = exchange.getIn();
		
		// Set the message properties for LoginService
		msg.setHeader(CxfConstants.OPERATION_NAME, "getAccessToken");
		msg.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.FALSE);
		msg.setHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);
		
		// Query parameters are put to the message body in exact order of the method signature, using an Object[]
		
		Object[] params = new Object[] {"Basic aW5mb2FyY2hpdmUuaWF3YTpzZWNyZXQ=", IAConstants.IA_PASSWORD, username, password};
		
		// Set the message body
		msg.setBody(params);
	}
	
	private Map<String, Object> processResponse(Exchange exchange) throws Exception {
		
		Message msg = null;
		
		if(exchange.hasOut()) {
			msg = exchange.getOut();
		}
		else {
			msg = exchange.getIn();
		}
		
		// Get the login token response from the exchange
		JSONObject loginResp = new JSONObject(msg.getBody(String.class));
		
		// Get login token properties
		Map<String, Object> props = new HashMap<>();
		
		// This throws JSONException if property is not found in the response (i.e. login failed...)
		props.put(IAConstants.IA_TOKEN_TYPE, loginResp.getString(IAConstants.IA_TOKEN_TYPE));
		props.put(IAConstants.IA_ACCESS_TOKEN, loginResp.getString(IAConstants.IA_ACCESS_TOKEN));
		
		// Save login token expiry time
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.SECOND, loginResp.getInt("expires_in"));
		
		props.put(IAConstants.IA_LOGIN_EXPIRY, cal);
		
		LOG.debug("Login token will expire at: " + FORMAT.format(cal.getTime()));
		
		return props;
	}
}

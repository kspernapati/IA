package com.teliasonera.eias.autoingest.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Enumeration;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipFile;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

public class ZipUtils {

    private static final int BUFFER = 1024;

    private ZipUtils() {}

    /**
     * Compresses contents of a directory into a zip file with the same name as
     * the dir. Root is the directory root, everything inside is included. Zip
     * is placed in targetDir.
     * 
     * @param dir
     */

    public static File zipDirectory(File srcDir, File targetDir) throws FileNotFoundException, IOException {

        File zipFile = new File(targetDir, srcDir.getName() + ".zip");

        byte[] buf = new byte[BUFFER];

        ZipArchiveOutputStream os = null;

        try {
            os = new ZipArchiveOutputStream(new FileOutputStream(zipFile));

            // List all files
            Collection<File> files = FileUtils.listFiles(srcDir, TrueFileFilter.INSTANCE, null);

            for (File f : files) {

                os.putArchiveEntry(new ZipArchiveEntry(f.getName()));

                InputStream is = null;

                try {
                    is = new FileInputStream(f);
                    int bytes = 0;

                    while ((bytes = is.read(buf, 0, BUFFER)) != -1) {
                        os.write(buf, 0, bytes);
                    }

                    os.flush();
                    os.closeArchiveEntry();
                } finally {
                    IOUtils.closeQuietly(is);
                }
            }
        } finally {
            os.flush();
            IOUtils.closeQuietly(os);
        }

        return zipFile;
    }

    /**
     * Extracts a ZIP file. Will not handle directories in the archive, only
     * works for flat archives like the SIP file.
     * 
     * @param fin
     * @param targetDir
     * @throws FileNotFoundException
     * @throws IOException
     */

    public static void unzipArchive(File fin, File targetDir) throws FileNotFoundException, IOException {

        ZipFile zip = null;

        try {
            zip = new ZipFile(fin);

            Enumeration<ZipArchiveEntry> entries = zip.getEntries();

            while (entries.hasMoreElements()) {

                ZipArchiveEntry e = entries.nextElement();

                if (!targetDir.exists())
                    targetDir.mkdirs();

                File file = new File(targetDir, e.getName());
                InputStream is = null;

                try {
                    is = zip.getInputStream(e);
                    FileUtils.copyInputStreamToFile(is, file);
                    is.close();
                    file.setLastModified(e.getLastModifiedDate().getTime());
                } finally {
                    IOUtils.closeQuietly(is);
                }
            }
        } finally {
            ZipFile.closeQuietly(zip);
        }

    }
}

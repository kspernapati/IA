package com.teliasonera.eias.autoingest.processor.exception;

public class SipProcessorException extends Exception {

    private static final long serialVersionUID = -2209342352629425810L;

    public SipProcessorException() {
    }

    public SipProcessorException(String message) {
        super(message);
    }

    public SipProcessorException(Throwable cause) {
        super(cause);
    }

    public SipProcessorException(String message, Throwable cause) {
        super(message, cause);
    }

    public SipProcessorException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

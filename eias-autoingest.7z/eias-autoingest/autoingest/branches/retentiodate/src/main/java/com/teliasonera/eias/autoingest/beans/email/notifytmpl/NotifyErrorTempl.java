package com.teliasonera.eias.autoingest.beans.email.notifytmpl;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/** class for providing notification of exceptions in different routes
 * @author exq6006
 *
 */
@Component
@Scope("prototype")
@Qualifier("notifyErrorTemplBean")
public class NotifyErrorTempl extends NotifyTempl {

	public String exceptionTrace;
	/**
	 * getExceptionTrace to get the value of exceptionTrace
	 * 
	 * @return the exceptionTrace
	 */
	public String getExceptionTrace() {
		return exceptionTrace;
	}

	/**
	 * setExceptionTrace to set the value of exceptionTrace
	 * 
	 * @param exceptionTrace
	 *            the exceptionTrace to set
	 */
	public void setExceptionTrace(String exceptionTrace) {
		this.exceptionTrace = exceptionTrace;
	}

}

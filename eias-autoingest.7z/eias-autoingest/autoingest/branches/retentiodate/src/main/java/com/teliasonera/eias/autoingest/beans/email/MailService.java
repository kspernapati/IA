package com.teliasonera.eias.autoingest.beans.email;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.camel.Exchange;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.teliasonera.eias.autoingest.beans.email.notifytmpl.NotifyErrorTempl;
import com.teliasonera.eias.autoingest.beans.email.notifytmpl.NotifyRouteErrorTempl;
import com.teliasonera.eias.autoingest.beans.email.notifytmpl.NotifyTempl;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@SuppressWarnings("deprecation")
@Component
@Scope("singleton")
public class MailService {
	Logger LOG = LoggerFactory.getLogger(MailService.class);

	@Value("${email.default.error.tolist:jussi.lehtiniemi@teliacompany.com}")
	private String toAddressList;

	@Value("${email.from:eiasadmin@teliacompany.com}")
	private String fromAddress;

	@Value("${email.subject:Notification from EIAS AutoIngest}")
	private String subject;

	@Value("${route.error.notify.template.loc:/mailtemplates/errorNotifyTemplate2.html}")
	private String routErrorTemplLoc;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private VelocityEngine velocityEngine;

	@Autowired
	@Qualifier("notifyRouteErrorTemplBean")
	private NotifyRouteErrorTempl notifyRTErr;

	@Autowired
	@Qualifier("notifyErrorTemplBean")
	private NotifyErrorTempl notifyErr;

	@Autowired
	@Qualifier("notifyTemplBean")
	private NotifyTempl notify;
	
	private String hostName;

	public MailService() {
		LOG.debug("Singleton initializtion for Mail Service");
		// Find the host name
		try {
			this.hostName = InetAddress.getLocalHost().getHostName();
		}
		catch(UnknownHostException e) {
			LOG.error("Could not find local host name, using default!");
			this.hostName = "UnknownHost";
		}
	}

	/**
	 * =========================================================================
	 * Generic notifications
	 * =========================================================================
	 */

	public void notify(final String msg) {
		notify(msg, this.toAddressList);
 	}

	public void notify(final String msg, final String toAddress) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(MimeMessage mimeMessage) throws Exception {
				notify.setMessage((msg) != null ? msg : "No detailed message available");
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
				message.setFrom(fromAddress);
				message.setSubject(subject + " - " + hostName);
				message.setTo((toAddress != null) ? toAddress.split(",") : toAddressList.split(","));
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("notifyErr", notifyErr);
				String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, routErrorTemplLoc, "UTF-8",
						model);
				message.setText(text, true);
			}
		};
		this.mailSender.send(preparator);
	}

	/**
	 * =========================================================================
	 * Generic error notifications
	 * =========================================================================
	 */

	public void notifyError(final Exception exception, final String msg) {
		notifyError(exception, msg, this.toAddressList);
	}

	public void notifyError(final Exception exception, final String msg, final String toAddress) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(MimeMessage mimeMessage) throws Exception {
				notifyErr.setExceptionTrace((exception != null) ? (ExceptionUtils.getFullStackTrace(exception))
						: ("No Exception Trace Available"));
				notifyErr.setMessage((msg) != null ? msg : "No detailed message available");
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
				message.setFrom(fromAddress);
				message.setSubject(subject + " - " + hostName);
				message.setTo((toAddress != null) ? toAddress.split(",") : toAddressList.split(","));
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("notifyErr", notifyErr);
				String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, routErrorTemplLoc, "UTF-8",
						model);
				message.setText(text, true);
			}
		};
		this.mailSender.send(preparator);
	}

	/**
	 * =========================================================================
	 * ROUTES related error notifications
	 * =========================================================================
	 */

	public void notifyRouteError(Exception exception, String msg, RouteType route) {
		notifyRouteError(exception, msg, toAddressList, route, null);
	}

	public void notifyRouteError(Exception exception, String msg, RouteType route, Exchange exchange) {
		notifyRouteError(exception, msg, toAddressList, route, exchange);
	}

	public void notifyRouteError(final Exception exception, final String msg, final String toAddress,
			final RouteType route, final Exchange exchange) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			public void prepare(MimeMessage mimeMessage) throws Exception {
				notifyRTErr.setExceptionTrace((exception != null) ? (ExceptionUtils.getFullStackTrace(exception))
						: ("No Exception Trace Available"));
				notifyRTErr.setMessage((msg) != null ? msg : "No detailed message available");
				notifyRTErr.setIntRouteName((route != null ? route.getName() : "Integration Route Name not avaiable"));
				notifyRTErr.setRuntimeHeaders((exchange != null ? exchange.getIn().getHeaders().toString()
						: "Runtime route headers not avaiable"));
				MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
				message.setFrom(fromAddress);
				message.setSubject(subject + " - " + hostName);
				message.setTo((toAddress != null) ? toAddress.split(",") : toAddressList.split(","));
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("notifyErr", notifyRTErr);
				String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, routErrorTemplLoc, "UTF-8",
						model);
				message.setText(text, true);
			}
		};
		this.mailSender.send(preparator);
	}

	/*public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext("com.teliasonera.eias.autoingest");
		MailService mailservice = (ctx.getBean(MailService.class));
		mailservice.notifyRouteError(new Exception("test exception"), null, null, null, null);
	}
*/
}

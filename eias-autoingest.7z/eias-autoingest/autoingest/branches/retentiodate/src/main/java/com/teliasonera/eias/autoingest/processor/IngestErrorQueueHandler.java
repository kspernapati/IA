package com.teliasonera.eias.autoingest.processor;

import org.apache.camel.CamelContext;
import org.apache.camel.ConsumerTemplate;
import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.routes.IAIngestServiceRoute;

/**
 * Handles the ActiveMQ ingest error queue and sends the contents for re-ingestion
 * 
 * @author sce4799
 *
 */

@Component
@Scope("singleton")
public class IngestErrorQueueHandler implements Processor {

	private static final Logger LOG = LoggerFactory.getLogger(IngestErrorQueueHandler.class);

	public IngestErrorQueueHandler() {}

	// Producer templates
	//	@EndpointInject(uri = IAIngestServiceRoute.REINGEST_QUEUE_URI)
	//	@Autowired
	private ProducerTemplate producer;

	//	@EndpointInject(uri = IAIngestServiceRoute.INGEST_SERVICE_URI)
	//	@Autowired
	private ConsumerTemplate consumer;

	public void setProducer(ProducerTemplate producer) {
		this.producer = producer;
	}

	public void setConsumer(ConsumerTemplate consumer) {
		this.consumer = consumer;
	}

	@Override
	public void process(Exchange exchange) throws Exception {

		CamelContext context = exchange.getContext();

		Endpoint queue = context.getEndpoint(IAIngestServiceRoute.REINGEST_QUEUE_URI);
		Endpoint target = context.getEndpoint(IAIngestServiceRoute.INGEST_SERVICE_URI);
		Endpoint dlq = context.getEndpoint("activemq:queue:ActiveMQ.DLQ");

		Exchange ex = null;

		int cnt = 0;
		producer = context.createProducerTemplate();
		consumer = context.createConsumerTemplate();

		// Check if any messages are in the queue

		while((ex = consumer.receive(queue, 1000L)) != null) {
			LOG.info("Sending exchange " + ex.getExchangeId() + " for re-ingestion");
			producer.send(target, ex);	// Pass to the ingest queue
			cnt++;
		}

		LOG.info(cnt + " messages in [sip.reingestion] queue were sent for ingestion");
		
		if(dlq != null) {
			LOG.info("Processing ActiveMQ DeadLetterQueue contents if any...");
			
			cnt = 0;
			while((ex = consumer.receive(dlq, 1000L)) != null) {
				LOG.info("Sending exchange " + ex.getExchangeId() + " from ActiveMQ.DLQ queue for reingestion");
				producer.send(target, ex); // Pass to the ingest queue
				cnt++;
			}
			
			LOG.info(cnt + " messages in [ActiveMQ.DLQ] queue were sent for ingestion");
		}
	}

}

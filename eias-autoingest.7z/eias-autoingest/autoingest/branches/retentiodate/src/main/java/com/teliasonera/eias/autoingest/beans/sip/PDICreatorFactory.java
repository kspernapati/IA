package com.teliasonera.eias.autoingest.beans.sip;

import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Provides PDICreator instances using Spring Lookup feature
 * 
 * @author sce4799
 *
 */

@Component
@Scope("singleton")
public class PDICreatorFactory {

	public PDICreatorFactory() {}
	
	@Lookup
	public PDICreator getPDICreator() {
		return null;	// Spring will override this implementation dynamically and return actual instance
	}

}

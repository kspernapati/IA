package com.teliasonera.eias.autoingest.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.teliasonera.eias.autoingest.beans.email.MailService;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Process exceptions caught in Camel routes
 * 
 * @author sce4799
 */

@Component
@Scope("prototype")
public class XMLErrorHandler implements Processor {
    private RouteType config;

    @Autowired
    MailService mail;

    public RouteType getConfig() {
        return config;
    }

    public void setConfig(RouteType config) {
        this.config = config;
    }

    private static final Logger LOG = LoggerFactory.getLogger(XMLErrorHandler.class);

    public XMLErrorHandler() {
    }

    @Override
    public void process(Exchange exc) throws Exception {
        // Log the caught exception
        Exception e = exc.getException();
        LOG.error(e.getMessage(),e);
        mail.notifyRouteError(e, e.getMessage(), getConfig(), exc);
    }

}

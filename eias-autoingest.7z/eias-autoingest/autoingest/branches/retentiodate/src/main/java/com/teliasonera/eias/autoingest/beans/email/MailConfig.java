package com.teliasonera.eias.autoingest.beans.email;

import java.io.IOException;
import java.util.Properties;

import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.ui.velocity.VelocityEngineFactoryBean;

/**
 * Class responsible for providing email configurations.
 * 
 * @author exq6006
 *
 */

@SuppressWarnings("deprecation")
@Configuration
@PropertySources({ @PropertySource("classpath:/config/mail.properties") })
public class MailConfig {

	@Value("${email.host}")
	private String host;

	@Value("${mail.debug}")
	private String debugEnabled;

	@Value("${resource.loader}")
	private String resourceLoader;

	@Value("${class.resource.loader.class}")
	private String classResourceLoader;

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	@Scope("singleton")
	public JavaMailSender javaMailService() {
		JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl();
		javaMailSender.setHost(host);
		javaMailSender.setDefaultEncoding("UTF-8");
		javaMailSender.setPort(JavaMailSenderImpl.DEFAULT_PORT);
		javaMailSender.setProtocol(JavaMailSenderImpl.DEFAULT_PROTOCOL);

		Properties mailProperties = new Properties();
		mailProperties.put("mail.smtp.debug", debugEnabled);

		/**
		 * Only debug enabled now but in future we might need to add the SMTP
		 * related properties. placeholder for that.
		 * mailProperties.put("mail.smtp.auth", auth);
		 * mailProperties.put("mail.smtp.starttls.enable", starttls);
		 * mailProperties.put("mail.smtp.starttls.required", startlls_required);
		 * mailProperties.put("mail.smtp.socketFactory.port", socketPort);
		 * mailProperties.put("mail.smtp.debug", debug);
		 * mailProperties.put("mail.smtp.socketFactory.class",*
		 * "javax.net.ssl.SSLSocketFactory");
		 * mailProperties.put("mail.smtp.socketFactory.fallback", fallback);
		 * 
		 **/
		javaMailSender.setJavaMailProperties(mailProperties);
		return javaMailSender;
	}

	@Bean
	@Scope("singleton")
	public VelocityEngine velocityEngine() throws VelocityException, IOException {
		VelocityEngineFactoryBean factory = new VelocityEngineFactoryBean();
		Properties props = new Properties();
		props.put("resource.loader", resourceLoader);
		props.put("class.resource.loader.class", classResourceLoader);
		factory.setVelocityProperties(props);
		return factory.createVelocityEngine();
	}

}

package com.teliasonera.eias.autoingest.restful;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;

@Path("")
public interface IARestAPI {
	
	@GET
	@Path("/product-info")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getInstanceInfo(@HeaderParam("Authorization") String authorization);
	
	@GET
	@Path("/systemdata/tenants")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTenantInfo(@HeaderParam("Authorization") String authorization);
	
	@GET
	@Path("/systemdata/tenants/{tenant_id}/applications")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getApplicationInfo(
			@HeaderParam("Authorization") String authorization,
			@PathParam("tenant_id") String tenantId);
	
	@POST
	@Path("/systemdata/applications/{application_id}/aips")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response receiveAip(
			@HeaderParam("Authorization") String authorization,
			@PathParam("application_id") String applicationId,
			@Multipart("body") MultipartBody body);
}

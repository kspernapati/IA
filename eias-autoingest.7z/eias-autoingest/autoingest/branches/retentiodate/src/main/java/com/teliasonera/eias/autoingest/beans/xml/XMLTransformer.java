package com.teliasonera.eias.autoingest.beans.xml;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
public class XMLTransformer {
	
	private static final Logger LOG = LoggerFactory.getLogger(XMLTransformer.class);
	
	@Autowired
	private TransformerFactory trxFactory;

	// Constructor
	private XMLTransformer() {}

	/**
	 * Transform the input XML using the input XSL transform and write to the output file
	 * 
	 * @param xslt
	 *            - Input XSL transform
	 * @param xml
	 *            - Input XML file
	 * @param output
	 *            - Target file to write the output to
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */

	public void transformXML(File xslt, File xml, File output)
			throws TransformerConfigurationException, TransformerException, FileNotFoundException, IOException {

		if (xslt == null || xml == null) {
			throw new TransformerException("Null input file detected!");
		}
		if (output == null) {
			throw new TransformerException("Output file is null!");
		}

		InputStream is = null;

		try {
			// Read the XSLT & create a transformer
			Transformer trx = this.trxFactory.newTransformer(new StreamSource(xslt));
			trx.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			trx.setOutputProperty(OutputKeys.INDENT, "yes");

			trx.transform(new StreamSource(xml), new StreamResult(output));
		} finally {
			IOUtils.closeQuietly(is);
		}
	}

	/**
	 * Transform the given XML with the given XSLT. Returns a JAXP StreamResult object containing the transformed XML
	 * 
	 * @param xslt
	 * @param xml
	 * @return
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */

	public StreamResult transformXML(StreamSource xslt, StreamSource xml) throws TransformerConfigurationException, TransformerException {

		if (xslt == null || xml == null)
			throw new TransformerException("Null input file detected!");

		try {
			// Read the XSLT & create a transformer
			Transformer trx = this.trxFactory.newTransformer(xslt);
			trx.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			trx.setOutputProperty(OutputKeys.INDENT, "yes");

			StreamResult output = new StreamResult(new ByteArrayOutputStream());
			trx.transform(xml, output);
			return output;
		} catch (Exception e) {
			throw new TransformerException("Exception occured in XML Transformer!" + e);
		}
	}
	
	/**
	 * Transform the given XML with the given XSLT. Returns a JAXP StreamResult object containing the transformed XML
	 * 
	 * @param xslt
	 * @param xml
	 * @param params - Pass parameters to the XSLT transform
	 * @return
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */

	public StreamResult transformXML(StreamSource xslt, StreamSource xml, Map<String, String> params) throws TransformerConfigurationException, TransformerException {

		if (xslt == null || xml == null)
			throw new TransformerException("Null input file detected!");

		try {
			// Read the XSLT & create a transformer
			Transformer trx = this.trxFactory.newTransformer(xslt);
			trx.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			trx.setOutputProperty(OutputKeys.INDENT, "yes");
			
			// Set the transformer parameters
			for(String key : params.keySet()) {
				trx.setParameter(key, params.get(key));
			}

			StreamResult output = new StreamResult(new ByteArrayOutputStream());
			trx.transform(xml, output);
			return output;
		} catch (Exception e) {
			throw new TransformerException("Exception occured in XML Transformer!" + e);
		}
	}

	/**
	 * Transform the given XML with the given XSLT. Returns a JAXP StreamResult object containing the transformed XML
	 * 
	 * @param xslt
	 * @param xml
	 * @return
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */

	public StreamResult transformXML(InputStream xslt, InputStream xml) throws TransformerConfigurationException, TransformerException {
		if (xslt == null || xml == null) {
			throw new TransformerException("Null input file detected!");
		}
		return this.transformXML(new StreamSource(xslt), new StreamSource(xml));
	}

	/**
	 * Transform the given XML with the given XSLT. Returns a JAXP StreamResult object containing the transformed XML
	 * 
	 * @param xslt
	 * @param xml
	 * @return
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 * @throws FileNotFoundException
	 */

	public StreamResult transformXML(File xslt, File xml) throws TransformerConfigurationException, TransformerException, FileNotFoundException {
		
		if (xslt == null || xml == null) {
			throw new TransformerException("Null input file detected!");
		}
		
		LOG.debug("XML transform started for file.." + xml.getName());
		LOG.debug("XSTL file.." + xslt.getAbsolutePath());

		InputStream xsltStream = null;
		InputStream xmlStream = null;
		
		try {
			xsltStream = new FileInputStream(xslt);
			xmlStream = new FileInputStream(xml);
			return this.transformXML(xsltStream, xmlStream);
		} catch (Exception e) {
			throw new TransformerException("Exception in XMl transformer!" + e);
		} finally {
			IOUtils.closeQuietly(xmlStream, xsltStream);
		}
	}
}

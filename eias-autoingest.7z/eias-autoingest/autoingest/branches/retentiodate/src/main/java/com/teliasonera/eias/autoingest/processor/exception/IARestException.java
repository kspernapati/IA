package com.teliasonera.eias.autoingest.processor.exception;

public class IARestException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1126053266221029495L;

	public IARestException() {
	}

	public IARestException(String message) {
		super(message);
	}

	public IARestException(Throwable cause) {
		super(cause);
	}

	public IARestException(String message, Throwable cause) {
		super(message, cause);
	}

	public IARestException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}

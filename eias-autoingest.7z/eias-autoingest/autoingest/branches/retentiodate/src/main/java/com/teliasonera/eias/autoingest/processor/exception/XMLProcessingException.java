package com.teliasonera.eias.autoingest.processor.exception;

public class XMLProcessingException extends Exception {

    private static final long serialVersionUID = 7434888155387057296L;

    public XMLProcessingException() {
    }

    public XMLProcessingException(String message) {
        super(message);
    }

    public XMLProcessingException(Throwable cause) {
        super(cause);
    }

    public XMLProcessingException(String message, Throwable cause) {
        super(message, cause);
    }

    public XMLProcessingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

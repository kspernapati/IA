package com.teliasonera.eias.autoingest.processor.exception;

public class XMLTransformException extends XMLProcessingException {

    private static final long serialVersionUID = -7513907286719866953L;

    public XMLTransformException() {
    }

    public XMLTransformException(String message) {
        super(message);
    }

    public XMLTransformException(Throwable cause) {
        super(cause);
    }

    public XMLTransformException(String message, Throwable cause) {
        super(message, cause);
    }

    public XMLTransformException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}

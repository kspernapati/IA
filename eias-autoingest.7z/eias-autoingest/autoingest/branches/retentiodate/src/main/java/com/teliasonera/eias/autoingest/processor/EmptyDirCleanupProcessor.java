package com.teliasonera.eias.autoingest.processor;

import java.io.File;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.teliasonera.eias.autoingest.common.CommonUtils;

@Component
@Scope("prototype")
public class EmptyDirCleanupProcessor implements Processor {
	
	private File target;
	
	public void setTarget(File target) {
		this.target = target;
	}

	@Override
	public void process(Exchange exchange) throws Exception {

		CommonUtils.cleanEmptySubdirs(target);
		
	}

}

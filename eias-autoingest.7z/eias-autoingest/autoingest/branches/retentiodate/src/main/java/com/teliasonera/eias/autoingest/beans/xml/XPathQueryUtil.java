package com.teliasonera.eias.autoingest.beans.xml;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.namespace.QName;
import javax.xml.transform.sax.SAXSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.xml.sax.InputSource;

import com.teliasonera.eias.autoingest.processor.ConfigProcessor;

@Component
@Scope("singleton")
public class XPathQueryUtil {

	private static final Logger LOG = LoggerFactory.getLogger(ConfigProcessor.class);

	@Autowired
	private XPathFactory factory;

	private XPathQueryUtil() throws XPathFactoryConfigurationException {}

	public String queryDocument(InputStream docStream, String xpath) throws XPathExpressionException, IOException {
		LOG.debug("Quering document with xpath.."+xpath);
//		LOG.debug(IOUtils.toString(docStream, "UTF-8"));
		XPath eval = this.factory.newXPath();

		try {
			return eval.evaluate(xpath, new SAXSource(new InputSource(docStream)));
		} finally {
			IOUtils.closeQuietly(docStream);
		}
	}

	public Object queryDocument(InputStream docStream, String xpath, QName returnType) throws XPathExpressionException, IOException {
		LOG.debug("Quering document with xpath.."+xpath);
//		LOG.debug(IOUtils.toString(docStream, "UTF-8"));
		XPath eval = this.factory.newXPath();

		try {
			return eval.evaluate(xpath, new SAXSource(new InputSource(docStream)), returnType);
		} finally {
			IOUtils.closeQuietly(docStream);
		}
	}

	public Object queryDocument(InputSource docSrc, String xpath, QName returnType) throws XPathExpressionException, IOException {
		LOG.debug("Quering document with xpath.."+xpath);
//		LOG.debug(IOUtils.toString(docSrc.getByteStream(), "UTF-8"));
		XPath eval = this.factory.newXPath();

		return eval.evaluate(xpath, new SAXSource(docSrc), returnType);
	}
}

package com.teliasonera.eias.autoingest.routes.test;

//import static org.junit.Assert.*;

import java.io.File;

import org.apache.camel.CamelContext;
import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.camel.test.spring.CamelTestContextBootstrapper;
import org.apache.camel.test.spring.DisableJmx;
import org.apache.camel.test.spring.MockEndpoints;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.BootstrapWith;
import org.springframework.test.context.ContextConfiguration;

import com.teliasonera.eias.autoingest.routes.XmlContentRoute;
import com.teliasonera.eias.autoingest.testutils.TestConfigFactory;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@BootstrapWith(CamelTestContextBootstrapper.class)
@ContextConfiguration(classes = {XMLContentRouteTest.TestConfig.class}, loader = CamelSpringDelegatingTestContextLoader.class)
@DisableJmx(true)
@MockEndpoints("file*")
public class XMLContentRouteTest {

    // Constants
    private static final String ROUTECONFIG = "src/test/resources/config/route_config.xml";
    private static final String ROUTESCHEMA = "src/main/resources/config/route_config.xsd";
    private static final String TESTDIR = "test/xmlprocessing";
    private static final String SRC_VALID = "src/test/resources/validation_files";
    private static final String SRC_INVALID = "src/test/resources/validation_files_fails";
    private static final String SRC_MISSING_CONTENT = "src/test/resources/validation_files_missing_content";
    private static final String SRC_MULTIPLE_CONTENT = "src/test/resources/validation_files_multiple_content";
    private static final String SRC_MULTIPLE_CONTENT_MISSING = "src/test/resources/validation_files_multiple_content2";
//    private static final String SRC_LARGEBATCH = "test/largebatch";

    // Camel stuff...
    @Autowired
    protected CamelContext camelContext;

    @EndpointInject(uri = "mock:file:test/xmlprocessing/work")
    protected MockEndpoint result;

    @EndpointInject(uri = "mock:activemq:queue.ingestService")
    protected MockEndpoint mqResult;

    // Test route instance
    @Produce(uri = "mock:file://test/xmlprocessing")
    protected ProducerTemplate template;

    @Configuration
    @ComponentScan("com.teliasonera.eias.autoingest")
    public static class TestConfig extends SingleRouteCamelConfiguration {
        @Bean
        @Override
        public RouteBuilder route() {

            RouteBuilder out = null;

            try {
                TestConfigFactory fact = new TestConfigFactory(new File(ROUTESCHEMA), new File(ROUTECONFIG));
                out = new XmlContentRoute(fact.getRoute("TestRoute"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return out;
        }
    }

    // =================================================
    // Test begins:

    @Before
    public void setUp() throws Exception {
    }

    @Test
    @DirtiesContext
    public final void testRoute() throws Exception {

        testSetup(SRC_VALID);
        // testSetup(SRC_LARGEBATCH);

        this.result.expectedMessageCount(10);
        // this.result.expectedMessageCount(2071);

        // this.result.setAssertPeriod(20000L);

        this.result.assertIsSatisfied();
    }

    @Test
    @DirtiesContext
    public final void testRouteFails() throws Exception {

        testSetup(SRC_INVALID);

        this.result.expectedMessageCount(7);

        this.result.assertIsSatisfied();
    }

    @Test
    @DirtiesContext
    public final void testRouteMissingContentFile() throws Exception {

        testSetup(SRC_MISSING_CONTENT);

        this.result.expectedMessageCount(9);

        this.result.assertIsSatisfied();
    }

    @Test
    @DirtiesContext
    public final void testRouteMultipleContentFiles() throws Exception {

        testSetup(SRC_MULTIPLE_CONTENT);

        this.result.expectedMessageCount(8);

        this.result.assertIsSatisfied();
    }

    @Test
    @DirtiesContext
    public final void testRouteMultipleContentFileMissing() throws Exception {

        testSetup(SRC_MULTIPLE_CONTENT_MISSING);

        this.result.expectedMessageCount(7);

        this.result.assertIsSatisfied();
    }

    private static final void testSetup(String srcPath) throws Exception {

        File sourceDir = new File(srcPath);
        File testDir = new File(TESTDIR);

        if (testDir.exists()) {
            FileUtils.cleanDirectory(testDir);
        }

        FileUtils.copyDirectory(sourceDir, testDir);
    }
}

package com.teliasonera.eias.autoingest.routes.test;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.ConsumerTemplate;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.jaxrs.CxfRsEndpoint;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.camel.test.spring.CamelTestContextBootstrapper;
import org.apache.camel.test.spring.DisableJmx;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.BootstrapWith;
import org.springframework.test.context.ContextConfiguration;

import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.restful.LoggingFaultInInterceptor;
import com.teliasonera.eias.autoingest.routes.IAIngestServiceRoute;
import com.teliasonera.eias.autoingest.testutils.TestConfigFactory;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@BootstrapWith(CamelTestContextBootstrapper.class)
@ContextConfiguration(classes = {IAIngestRouteTest.TestConfig.class}, loader = CamelSpringDelegatingTestContextLoader.class)
@DisableJmx(false)
public class IAIngestRouteTest {
	
	private static final Logger LOG = LoggerFactory.getLogger(IAIngestRouteTest.class);
	
	// Constants
    private static final String ROUTECONFIG = "src/test/resources/config/route_config.xml";
    private static final String ROUTESCHEMA = "src/main/resources/config/route_config.xsd";
    private static final String IA_USER = "sue@iacustomer.com";
    private static final String IA_PASSWD = "password";
    private static final String TESTFILE = "sample/eias_autoingest_sapmif-2016-10-17-NmN2E1ZGU4YjQ3_1.zip";
//    private static final String TESTFILE_FAIL = "sample/PhoneCallsSample-2001.zip";
	
	// Camel stuff...
    @EndpointInject(uri = "mock:end")
    public MockEndpoint result;
    
    @Produce(uri = "activemq:queue:sip.ingest")
    public ProducerTemplate template; 
    
    @Produce(uri = "direct:getLoginToken")
    public ProducerTemplate loginTemplate;
    
    @Configuration
    @ComponentScan({"com.teliasonera.eias.autoingest.processor", "com.teliasonera.eias.autoingest.common", "com.teliasonera.eias.autoingest.beans.email"})
    @PropertySources({ @PropertySource("classpath:/config/autoingest.properties") })
    public static class TestConfig extends SingleRouteCamelConfiguration {
    	
        @Bean
        @Override
        public RouteBuilder route() {

        	RouteBuilder out = null;

            try {
                TestConfigFactory fact = new TestConfigFactory(new File(ROUTESCHEMA), new File(ROUTECONFIG));
                out = new IAIngestServiceRoute(fact.getRestConfig());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return out;
        }
        
        @Bean
        @Override
        public CamelContext camelContext() throws Exception {
        	CamelContext ctx = super.camelContext();
        	ctx.addComponent("activemq", ActiveMQComponent.activeMQComponent("vm://localhost?broker.persistent=false"));
        	
        	// Add CXF fault loggers to the endpoints
        	TestConfigFactory fact = new TestConfigFactory(new File(ROUTESCHEMA), new File(ROUTECONFIG));
        	
        	CxfRsEndpoint loginService = (CxfRsEndpoint) ctx.getEndpoint(CommonUtils.getCamelURI(fact.getRestConfig().getLoginServiceEndpoint()));
        	CxfRsEndpoint restService = (CxfRsEndpoint) ctx.getEndpoint(CommonUtils.getCamelURI(fact.getRestConfig().getRestApiEndpoint()));
        	
        	loginService.getInInterceptors().add(new LoggingFaultInInterceptor());
        	restService.getInInterceptors().add(new LoggingFaultInInterceptor());
        	
        	return ctx;
        }
        
        @Bean
		@Autowired
		public ProducerTemplate producer() throws Exception {
			return camelContext().createProducerTemplate();
		}
		
		@Bean
		@Autowired
		public ConsumerTemplate consumer() throws Exception {
			return camelContext().createConsumerTemplate();
		}
    }
    
	@Before
	public void setUp() throws Exception {
	}

	@Test
	@DirtiesContext
	public final void testIngestRoute() throws Exception {
		
		Exchange exc = template.getDefaultEndpoint().createExchange();
		
		File file = new File(TESTFILE);
		
		InputStream str = new FileInputStream(file);
		
		exc.getIn().setHeader(IAConstants.IA_APP_NAME, "sapmif");
		exc.getIn().setHeader(IAConstants.IA_TENANT_NAME, "INFOARCHIVE");
		exc.getIn().setHeader(IAConstants.IA_USERNAME, IA_USER);
		exc.getIn().setHeader(IAConstants.IA_PASSWORD, IA_PASSWD);
		exc.getIn().setHeader(Exchange.FILE_NAME, file.getName());
		exc.getIn().setBody(str);
		
		LOG.debug("Processing file: " + exc.getIn().getHeader(Exchange.FILE_NAME));
		
		this.template.send(exc);
		
		Thread.sleep(5000L);
		result.await(30L, TimeUnit.SECONDS);
		
		str.close();
		
		assertTrue("No exchanges received from the route!", result.getExchanges().size() > 0);
		
		Exchange out =  result.getExchanges().get(0);
		
		assertNotNull("Output exhange was null!");
		
		out.setPattern(ExchangePattern.InOut);
		
		String tenantUuid = (String) out.getProperty(IAConstants.IA_TENANT_UUID);
		String appUuid = (String) out.getProperty(IAConstants.IA_APP_UUID);
		
		assertNotNull(tenantUuid);
		assertNotNull(appUuid);
		
		assertThat(tenantUuid, is(not("")));
		assertThat(appUuid, is(not("")));
		
		LOG.info("Received tenant ID: " + tenantUuid);
		LOG.info("Received app ID: " + appUuid);
		
		JSONObject response = new JSONObject(out.getIn().getBody(String.class));
		
		assertThat(response.getString("state"), is("Completed"));
	}
	
//	@Test
//	@DirtiesContext
//	public final void testIngestRouteReceptionFail() throws Exception {
//		
//		Exchange exc = template.getDefaultEndpoint().createExchange();
//		
//		File file = new File(TESTFILE_FAIL);
//		
//		InputStream str = new FileInputStream(file);
//		
//		exc.getIn().setHeader(IAConstants.IA_APP_NAME, "sapmif");
//		exc.getIn().setHeader(IAConstants.IA_TENANT_NAME, "INFOARCHIVE");
//		exc.getIn().setHeader(IAConstants.IA_USERNAME, IA_USER);
//		exc.getIn().setHeader(IAConstants.IA_PASSWORD, IA_PASSWD);
//		exc.getIn().setHeader(Exchange.FILE_NAME, file.getName());
//		exc.getIn().setBody(str);
//		
//		LOG.debug("Processing file: " + exc.getIn().getHeader(Exchange.FILE_NAME));
//		
//		this.template.send(exc);
//		
//		Thread.sleep(1000L);
//		result.await(30L, TimeUnit.SECONDS);
//		
//		str.close();
//		
//		result.assertIsNotSatisfied();
//	}
}


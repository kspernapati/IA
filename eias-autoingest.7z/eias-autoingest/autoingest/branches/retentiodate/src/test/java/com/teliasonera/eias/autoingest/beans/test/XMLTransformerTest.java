package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Calendar;

import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.annotation.Scope;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.teliasonera.eias.autoingest.beans.xml.XMLTransformer;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {XMLTransformerTest.TestConfig.class})
public class XMLTransformerTest {

    private static final String TEST_ROOT = "src/test/resources/";

    private static final String XSLTFILE = "transform_test/historical_archive_pankration.xsl";
    private static final String TESTFILE = "transform_test/eas_pdi_in.xml";
    private static final String OUTFILE = "output/transform_out.xml";

    private static final long FILE_MOD_TOL = 10000L;

    @Configuration
    @ComponentScan({"com.teliasonera.eias.autoingest.common", "com.teliasonera.eias.autoingest.beans.xml"})
    public static class TestConfig {
    	    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public TransformerFactory transformerFactory() {
    		System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
    		return TransformerFactory.newInstance();
    	}
    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public SchemaFactory schemaFactory() {
    		System.setProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema", "com.saxonica.ee.jaxp.SchemaFactoryImpl");
    		return SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
    	}
    }
    
    @Autowired
    private XMLTransformer trf;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public final void testTransformXMLSuccess1() throws Exception {

        File xslt = new File(TEST_ROOT + XSLTFILE);
        File xml = new File(TEST_ROOT + TESTFILE);
        File out = new File(OUTFILE);

        this.trf.transformXML(xslt, xml, out);

        assertTrue("Output file seems not to be updated!", out.lastModified() >= Calendar.getInstance().getTimeInMillis() - FILE_MOD_TOL);
        assertTrue("Output file size is zero!", out.length() > 0);
    }

    /**
     * This tests all 'public StreamResult transformXML()' methods end-to-end
     * 
     * @throws Exception
     */

    @Test
    public final void testTransformXmlSuccess2() throws Exception {

        File xslt = new File(TEST_ROOT + XSLTFILE);
        File xml = new File(TEST_ROOT + TESTFILE);

        StreamResult out = this.trf.transformXML(xslt, xml);

        assertNotNull("Null object returned!", out);
        assertNotNull("Null output stream returned!", out.getOutputStream());
        assertTrue("Output stream length is zero!", ((ByteArrayOutputStream)out.getOutputStream()).size() > 0);
    }

    @Test
    public final void testTransformXMLNullInput1() throws Exception {

        File xslt = null;
        File xml = null;

        thrown.expect(TransformerException.class);
        thrown.expectMessage("Null input file detected");

        StreamResult out = this.trf.transformXML(xslt, xml);

        assertNull("Result should not be created!", out);
    }

    @Test
    public final void testTransformXMLNullInput2() throws Exception {

        InputStream xslt = null;
        InputStream xml = null;

        thrown.expect(TransformerException.class);
        thrown.expectMessage("Null input file detected");

        StreamResult out = this.trf.transformXML(xslt, xml);

        assertNull("Result should not be created!", out);
    }

    @Test
    public final void testTransformXMLNullInput3() throws Exception {

        StreamSource xslt = null;
        StreamSource xml = null;

        thrown.expect(TransformerException.class);
        thrown.expectMessage("Null input file detected");

        StreamResult out = this.trf.transformXML(xslt, xml);

        assertNull("Result should not be created!", out);
    }

    @Test
    public final void testTransformXMLNullInput4() throws Exception {

        File xslt = new File(TEST_ROOT + XSLTFILE);
        File xml = new File(TEST_ROOT + TESTFILE);

        File out = null;

        thrown.expect(TransformerException.class);
        thrown.expectMessage("Output file is null");

        this.trf.transformXML(xslt, xml, out);

        assertNull("Result should not be created!", out);
    }

    @Test
    public final void testTransformXMLNonExistentFile1() throws Exception {

        File xslt = new File("someDir/somefile.xsl");
        File xml = new File(TEST_ROOT + TESTFILE);

        thrown.expect(TransformerException.class);
        thrown.expectMessage("The system cannot find the path specified");

        StreamResult out = this.trf.transformXML(xslt, xml);

        assertNull("Result should not be created!", out);
    }

    @Test
    public final void testTransformXMLNonExistentFile2() throws Exception {

        File xslt = new File(TEST_ROOT + XSLTFILE);
        File xml = new File("someDir/somefile.xml");

        thrown.expect(TransformerException.class);
        thrown.expectMessage("The system cannot find the path specified");

        StreamResult out = this.trf.transformXML(xslt, xml);

        assertNull("Result should not be created!", out);
    }
}

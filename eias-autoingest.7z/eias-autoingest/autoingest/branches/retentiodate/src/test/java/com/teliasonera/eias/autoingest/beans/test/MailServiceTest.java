package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ui.velocity.VelocityEngineFactoryBean;

import com.teliasonera.eias.autoingest.beans.email.MailService;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;
import com.teliasonera.eias.autoingest.testutils.TestConfigFactory;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MailServiceTest.TestConfig.class})
public class MailServiceTest {
	
	@Configuration
	@ComponentScan({"com.teliasonera.eias.autoingest.beans.email"})
	public static class TestConfig {
		
		private static final String ROUTECONFIG = "src/test/resources/config/route_config.xml";
	    private static final String ROUTESCHEMA = "src/main/resources/config/route_config.xsd";
		
		private String host = "smtp.dave.sonera.fi";
		private String debugEnabled = "true";
		private String resourceLoader = "class";
		private String classResourceLoader = "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader";
		
		@Bean
		@Scope("singleton")
		public JavaMailSender javaMailService() {
			JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl();
			javaMailSender.setHost(host);
			javaMailSender.setDefaultEncoding("UTF-8");
			javaMailSender.setPort(JavaMailSenderImpl.DEFAULT_PORT);
			javaMailSender.setProtocol(JavaMailSenderImpl.DEFAULT_PROTOCOL);

			Properties mailProperties = new Properties();
			mailProperties.put("mail.smtp.debug", debugEnabled);

			/**
			 * Only debug enabled now but in future we might need to add the SMTP
			 * related properties. placeholder for that.
			 * mailProperties.put("mail.smtp.auth", auth);
			 * mailProperties.put("mail.smtp.starttls.enable", starttls);
			 * mailProperties.put("mail.smtp.starttls.required", startlls_required);
			 * mailProperties.put("mail.smtp.socketFactory.port", socketPort);
			 * mailProperties.put("mail.smtp.debug", debug);
			 * mailProperties.put("mail.smtp.socketFactory.class",*
			 * "javax.net.ssl.SSLSocketFactory");
			 * mailProperties.put("mail.smtp.socketFactory.fallback", fallback);
			 * 
			 **/
			javaMailSender.setJavaMailProperties(mailProperties);
			return javaMailSender;
		}

		@Bean
		@Scope("singleton")
		public VelocityEngine velocityEngine() throws VelocityException, IOException {
			VelocityEngineFactoryBean factory = new VelocityEngineFactoryBean();
			Properties props = new Properties();
			props.put("resource.loader", resourceLoader);
			props.put("class.resource.loader.class", classResourceLoader);
			factory.setVelocityProperties(props);
			return factory.createVelocityEngine();
		}
		
		@Bean
		@Scope("singleton")
		public TestConfigFactory testConfigFactory() throws Exception {
			return new TestConfigFactory(new File(ROUTESCHEMA), new File(ROUTECONFIG));
		}
	}
	
	// Class under test
	@Autowired
	private MailService service;

	@Autowired
	private TestConfigFactory factory;
	
	
	@Test
	public void testNotifyString() {
		this.service.notify("Test message from MailService test!");
	}
	
	@Test
	public void testNotifyRouteError() {
		
		RouteType route = this.factory.getRoute("sapmif");
		Exception ex = new Exception("Test Exception");
		String msg = "TEST error message from AutoIngest";
		
		this.service.notifyRouteError(ex, msg, route);
	}

}

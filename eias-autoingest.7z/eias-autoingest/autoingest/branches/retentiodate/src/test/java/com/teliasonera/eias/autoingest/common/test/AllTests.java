package com.teliasonera.eias.autoingest.common.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({CommonUtilsTest.class})
public class AllTests {

}

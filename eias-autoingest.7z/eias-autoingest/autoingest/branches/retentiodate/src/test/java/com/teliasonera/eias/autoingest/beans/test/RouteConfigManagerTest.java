package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.teliasonera.eias.autoingest.beans.routemgmt.RouteConfigFactory;
import com.teliasonera.eias.autoingest.beans.routemgmt.RouteConfigManager;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test_context/camel-context.xml"})
public class RouteConfigManagerTest {

    // Object under test
    @InjectMocks
    private RouteConfigManager manager;

    @Mock
    private RouteConfigFactory factory;

    @Mock
    private RouteConfig rcfg;

    @Mock
    private RouteType rtype;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private List<RouteType> routes;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        this.routes = new ArrayList<>();
        this.routes.add(this.rtype);

        // Mock behavior
        when(this.factory.getRouteConfig(any(File.class), any(File.class))).thenReturn(this.rcfg);
        when(this.factory.getRouteConfig(any(InputStream.class), any(InputStream.class))).thenReturn(this.rcfg);
        when(this.rcfg.getRoute()).thenReturn(this.routes);
        when(this.rtype.getName()).thenReturn("TestRoute");
    }

    @Test
    public final void testGetRouteConfig() throws Exception {

        RouteConfig rc = this.manager.getRouteConfig();

        assertEquals(this.rcfg, rc);
    }

    @Test
    public final void testUpdateConfig() throws Exception {

        this.manager.updateConfig();

        // Test should complete without exceptions being thrown
    }

    @Test
    public final void testUpdateConfigException() throws Exception {

        // Override mock
        when(this.factory.getRouteConfig(any(File.class), any(File.class))).thenThrow(new JAXBException("Error!"));

        thrown.expect(JAXBException.class);
        thrown.expectMessage("Error!");

        this.manager.updateConfig();

        fail("No exception was thrown!");
    }

    @Test
    public final void testGetRouteNames() {

        List<String> names = this.manager.getRouteNames();

        assertTrue("No correct name found!", names.contains("TestRoute"));
    }

    @Test
    public final void testGetRoute() {

        RouteType route = this.manager.getRoute("TestRoute");

        assertEquals(this.rtype, route);
    }

}

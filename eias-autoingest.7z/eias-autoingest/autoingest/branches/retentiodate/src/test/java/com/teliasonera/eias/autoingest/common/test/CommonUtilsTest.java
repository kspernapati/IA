package com.teliasonera.eias.autoingest.common.test;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.teliasonera.eias.autoingest.common.CommonUtils;
import com.teliasonera.eias.autoingest.routeconfig.CamelUriType;
import com.teliasonera.eias.autoingest.routeconfig.OptionType;
import com.teliasonera.eias.autoingest.routeconfig.OptionsType;

public class CommonUtilsTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public final void testGetFileEndpointURIOneOption() {

        // Test endpoint
        CamelUriType ep = new CamelUriType();
        OptionsType opt = new OptionsType();

        ep.setName("test/xmlprocessing");
        ep.setType("file");
        ep.setOptions(opt);

        OptionType op1 = new OptionType();
        op1.setName("test");
        op1.setValue("testvalue");
        opt.getOption().add(op1);

        String test = CommonUtils.getCamelURI(ep);

        assertEquals("URI format not as expected", "file:test/xmlprocessing?test=testvalue", test);
    }

    @Test
    public final void testGetFileEndpointUriTwoOptions() {

        // Test endpoint
        CamelUriType ep = new CamelUriType();
        OptionsType opt = new OptionsType();

        ep.setName("test/xmlprocessing");
        ep.setType("file");
        ep.setOptions(opt);

        OptionType op1 = new OptionType();
        OptionType op2 = new OptionType();
        op1.setName("test");
        op1.setValue("testvalue");
        op2.setName("anotherTest");
        op2.setValue("anotherTestValue");
        opt.getOption().add(op1);
        opt.getOption().add(op2);

        String test = CommonUtils.getCamelURI(ep);

        assertEquals("URI format not as expected", "file:test/xmlprocessing?test=testvalue&anotherTest=anotherTestValue", test);
    }

    @Test
    public final void testGetFileEndpointURINoOptions() {

        // Test endpoint
        CamelUriType ep = new CamelUriType();
        ep.setName("test/xmlprocessing");
        ep.setType("file");

        String test = CommonUtils.getCamelURI(ep);

        assertEquals("URI format not as expected", "file:test/xmlprocessing", test);
    }

    @Test
    public final void testGetFileEndpointURIEmptyOptions() {

        // Test endpoint
        CamelUriType ep = new CamelUriType();
        OptionsType opt = new OptionsType();
        ep.setName("test/xmlprocessing");
        ep.setType("file");
        ep.setOptions(opt);

        String test = CommonUtils.getCamelURI(ep);

        assertEquals("URI format not as expected", "file:test/xmlprocessing", test);
    }

    @Test
    public final void testGetCamelURI() {

        // Test endpoint
        CamelUriType ep = new CamelUriType();
        OptionsType opt = new OptionsType();

        ep.setName("//test/someName");
        ep.setType("quartz2");
        ep.setOptions(opt);

        OptionType op1 = new OptionType();
        OptionType op2 = new OptionType();
        op1.setName("test");
        op1.setValue("testvalue");
        op2.setName("anotherTest");
        op2.setValue("anotherTestValue");
        opt.getOption().add(op1);
        opt.getOption().add(op2);

        String out = CommonUtils.getCamelURI(ep);

        assertEquals("URI format not as expected", "quartz2://test/someName?test=testvalue&anotherTest=anotherTestValue", out);
    }

    @Test
    public final void testGetSipID() {

        String pattern = "SAPMIF-%1$tY-%1$tm-%1$td-%%UUID%%";

        String out = CommonUtils.getSipID(pattern);

        System.out.println("Generated ID: " + out);

        assertEquals("Incorrect SIP ID length", CommonUtils.SIP_ID_LENGTH, out.length());
    }

    @Test
    public final void testConvertFileNames() throws Exception {

        List<String> names = new ArrayList<>();

        names.add("this_is_A_VALID_FileName including spaces and , - chars.txt");
        names.add("Tämä nimi sisältää ErikoisMERKKEJÄ: ÅÄÖåäö^~*@£$%&üÜáà+?=()[]{}'.txt");
        names.add("This+Name@has_some%unallowed#special?chars!.txt");

        for (String s : names) {
            String out = CommonUtils.getIACompliantFileName(s);
            System.out.println("Original: " + s + "\tResult: " + out);
        }
    }
    
    @Test
    public final void testDirCleanup() throws Exception {
    	
    	// Set up test dir
    	File testdir = new File("test/dir_cleanup");
    	if(testdir.exists())
    		FileUtils.forceDelete(testdir);
    	
    	testdir.mkdirs();
    	File source = new File("src/test/resources/dir_cleanup");
    	
    	FileUtils.copyDirectory(source, testdir);
    	
    	// Start test
    	CommonUtils.cleanEmptySubdirs(testdir);
    }
}

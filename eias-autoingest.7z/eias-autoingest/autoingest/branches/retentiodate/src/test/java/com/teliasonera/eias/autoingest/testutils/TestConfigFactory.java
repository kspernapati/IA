package com.teliasonera.eias.autoingest.testutils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.teliasonera.eias.autoingest.routeconfig.RestConfigType;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;

public class TestConfigFactory {

    private static final Logger LOG = LoggerFactory.getLogger(TestConfigFactory.class);

    private RouteConfig cfg;
    private File schema;
    private File xml;

    public TestConfigFactory(File schema, File xml) throws FileNotFoundException, SAXParseException, JAXBException, SAXException {
        if (schema == null || xml == null) {
            throw new FileNotFoundException("Null file given!");
        }
        this.schema = schema;
        this.xml = xml;
    }

    public RouteConfig getRouteConfig() {
        if (this.cfg == null) {
            try {
                this.cfg = this.getRouteConfigFromFile(this.schema, this.xml);
            } catch (Exception e) {
                LOG.error("Error while initializing RouteConfig", e);
            }
        }
        return this.cfg;
    }

    public RouteType getRoute(String name) {

        if (this.cfg == null)
            this.getRouteConfig();

        List<RouteType> routes = this.cfg.getRoute();

        for (RouteType r : routes) {
            if (r.getName().equals(name))
                return r;
        }

        LOG.error("Could not find route [%s]", name);
        
        return null;
    }
    
    /**
     * Get the REST API configurations from RouteConfig
     * 
     * @return RestConfigType
     */
    public RestConfigType getRestConfig() {
    	
    	if (this.cfg == null)
            this.getRouteConfig();
    	
    	return this.cfg.getRestConfig();
    }

    private RouteConfig getRouteConfigFromFile(File schemaFile, File xmlFile) throws JAXBException, SAXException {

        try {
            System.setProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema", "com.saxonica.ee.jaxp.SchemaFactoryImpl");
            JAXBContext ctx = JAXBContext.newInstance(RouteConfig.class);
            SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
            Schema schema = factory.newSchema(schemaFile);
            Unmarshaller unmarshaller = ctx.createUnmarshaller();
            unmarshaller.setSchema(schema);

            return (RouteConfig)unmarshaller.unmarshal(xmlFile);
        } catch (Exception e) {
            throw e;
        }
    }
}

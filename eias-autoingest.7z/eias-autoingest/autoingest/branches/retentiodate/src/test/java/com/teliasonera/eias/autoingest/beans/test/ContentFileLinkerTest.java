package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Collection;

import javax.xml.transform.TransformerFactory;
import javax.xml.validation.SchemaFactory;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.teliasonera.eias.autoingest.beans.sip.ContentFileLinker;
import com.teliasonera.eias.autoingest.beans.sip.ContentFileLinkerException;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;
import com.teliasonera.eias.autoingest.testutils.TestConfigFactory;

import net.sf.saxon.lib.NamespaceConstant;
import net.sf.saxon.xpath.XPathFactoryImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ContentFileLinkerTest.TestConfig.class})
public class ContentFileLinkerTest {

    private static final String ROUTECONFIG = "src/test/resources/config/route_config.xml";
    private static final String ROUTESCHEMA = "src/main/resources/config/route_config.xsd";
    private static final String SRC_DIR = "src/test/resources/content_linker";
    private static final String TESTDIR = "test/content_linker";

    @Configuration
    @ComponentScan({"com.teliasonera.eias.autoingest.common", "com.teliasonera.eias.autoingest.beans.xml", "com.teliasonera.eias.autoingest.beans.sip"})
    public static class TestConfig {
    	    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public TransformerFactory transformerFactory() {
    		System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
    		return TransformerFactory.newInstance();
    	}
    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public SchemaFactory schemaFactory() {
    		System.setProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema", "com.saxonica.ee.jaxp.SchemaFactoryImpl");
    		return SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
    	}
    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public XPathFactory xpathFactory() throws XPathFactoryConfigurationException {
    		System.setProperty("javax.xml.xpath.XPathFactory:" + NamespaceConstant.OBJECT_MODEL_SAXON, "net.sf.saxon.xpath.XPathFactoryImpl");
    		return XPathFactoryImpl.newInstance(NamespaceConstant.OBJECT_MODEL_SAXON);
    	}
    }
    
    // Class under test
    @Autowired
    private ContentFileLinker linker;

    private RouteType config;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
        TestConfigFactory f = new TestConfigFactory(new File(ROUTESCHEMA), new File(ROUTECONFIG));
        this.config = f.getRoute("tsops");
        this.linker.setMetaExtension("xml");
        this.linker.setRenameFiles(true);
        this.linker.setWorkDir(new File(TESTDIR));
    }

    @Test
    public final void testLinkContentFiles() throws Exception {

        testSetup(SRC_DIR);

        File testDir = new File(TESTDIR);

        Collection<File> files = FileUtils.listFiles(testDir, new SuffixFileFilter("xml", IOCase.INSENSITIVE), null);

        OutputStream out = null;

        for (File f : files) {
            out = this.linker.linkContentFiles(new FileInputStream(f), f.getName(), this.config.getContentLinks().getContentLink());

            String str = os2String(out);

            System.out.println("Result:\n" + str);

            assertNotNull(str);
            assertTrue(str.contains("<file format=\"tif\" mime_type=\"image/tiff\""));
        }
    }

    @Test
    public final void testLinkContentFilesFail() throws Exception {

        testSetup(SRC_DIR);

        File testDir = new File(TESTDIR + "/fails");
        this.linker.setWorkDir(testDir);

        Collection<File> files = FileUtils.listFiles(testDir, new SuffixFileFilter("xml", IOCase.INSENSITIVE), null);

        for (File f : files) {

            thrown.expect(ContentFileLinkerException.class);

            this.linker.linkContentFiles(new FileInputStream(f), f.getName(), this.config.getContentLinks().getContentLink());

            fail("No exception was thrown!");
        }
    }

    /**
     * Convert OutputStream to String
     * 
     * @param os
     * @return
     * @throws Exception
     */

    private static String os2String(OutputStream os) throws Exception {

        byte[] bytes = ((ByteArrayOutputStream)os).toByteArray();
        os.close();

        return new String(bytes, Charset.forName("UTF-8"));
    }

    private static final void testSetup(String srcPath) throws Exception {

        File sourceDir = new File(srcPath);
        File testDir = new File(TESTDIR);

        if (testDir.exists()) {
            FileUtils.cleanDirectory(testDir);
        }

        FileUtils.copyDirectory(sourceDir, testDir);
    }
}

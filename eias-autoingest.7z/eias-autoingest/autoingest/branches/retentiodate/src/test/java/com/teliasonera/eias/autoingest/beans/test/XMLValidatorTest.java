package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.xml.transform.TransformerFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.teliasonera.eias.autoingest.beans.xml.XMLValidator;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {XMLValidatorTest.TestConfig.class})
public class XMLValidatorTest {

    private static final String TEST_ROOT = "src/test/resources/";

    private static final String XMLSCHEMA1 = "src/main/resources/config/route_config.xsd";
//    private static final String XMLSCHEMA2 = "validation_files/coor_scan_tsops.xsd";
    private static final String TESTFILE = "config/route_config.xml";
    private static final String TESTFILE_INVALID = "config/route_config_invalid.xml";
//    private static final String TESTFILE_DIR = "validation_files";
//    private static final String TESTFILE_DIR_FAILS = "validation_files_fails";

    @Configuration
    @ComponentScan({"com.teliasonera.eias.autoingest.common", "com.teliasonera.eias.autoingest.beans.xml"})
    public static class TestConfig {
    	    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public TransformerFactory transformerFactory() {
    		System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
    		return TransformerFactory.newInstance();
    	}
    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public SchemaFactory schemaFactory() {
    		System.setProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema", "com.saxonica.ee.jaxp.SchemaFactoryImpl");
    		return SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
    	}
    }
    
    // Declare object under test
    @Autowired
    private XMLValidator validator;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public final void testValidateSuccess() throws Exception {
        this.validator.validate(new File(XMLSCHEMA1), new File(TEST_ROOT + TESTFILE));
    }

    @Test
    public final void testValidateFail() throws Exception {

        thrown.expect(SAXParseException.class);
        this.validator.validate(new File(XMLSCHEMA1), new File(TEST_ROOT + TESTFILE_INVALID));

        fail("Validation succeeded when expecting failure!");
    }

    @Test
    public final void testValidateStAXSuccess() throws Exception {
        this.validator.validate(new File(XMLSCHEMA1), new File(TEST_ROOT + TESTFILE));
    }

    @Test
    public final void testValidateStAXFail() throws Exception {

        thrown.expect(SAXException.class);
        this.validator.validateStAX(new FileInputStream(new File(XMLSCHEMA1)), new FileInputStream(new File(TEST_ROOT + TESTFILE_INVALID)));

        fail("Validation succeeded when expecting failure!");
    }

    @Test
    public final void testValidateNullInput1() throws Exception {

        InputStream is1 = null;
        InputStream is2 = null;

        thrown.expect(SAXParseException.class);
        this.validator.validate(is1, is2);

        fail("Validation should not have passed!");
    }

    @Test
    public final void testValidateNullInput2() throws Exception {

        File f1 = null;
        File f2 = null;

        thrown.expect(FileNotFoundException.class);
        thrown.expectMessage("Given file is pointing to null!");
        this.validator.validate(f1, f2);

        fail("Validation should not have passed!");
    }

    @Test
    public final void testGetSchema1() throws Exception {

        Schema schema = this.validator.getSchema(new File(XMLSCHEMA1));

        assertNotNull("Null schema was returned", schema);
    }

    @Test
    public final void testGetSchema2() throws Exception {

        Schema schema = this.validator.getSchema(new FileInputStream(new File(XMLSCHEMA1)));

        assertNotNull("Null schema was returned", schema);
    }

    @Test
    public final void testGetSchemaNullInput1() throws Exception {

        File f1 = null;

        thrown.expect(FileNotFoundException.class);

        this.validator.getSchema(f1);

        fail("No exception was thrown!");
    }

    @Test
    public final void testGetSchemaNullInput2() throws Exception {

        InputStream is = null;

        thrown.expect(SAXParseException.class);

        this.validator.getSchema(is);

        fail("No exception was thrown!");
    }
}

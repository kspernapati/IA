package com.teliasonera.eias.autoingest.routes.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.ConsumerTemplate;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.camel.test.spring.CamelTestContextBootstrapper;
import org.apache.camel.test.spring.DisableJmx;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.BootstrapWith;
import org.springframework.test.context.ContextConfiguration;

import com.teliasonera.eias.autoingest.common.IAConstants;
import com.teliasonera.eias.autoingest.routes.IAIngestServiceRoute;
import com.teliasonera.eias.autoingest.routes.IAReingestQueueHandlerRoute;
import com.teliasonera.eias.autoingest.testutils.TestConfigFactory;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@BootstrapWith(CamelTestContextBootstrapper.class)
@ContextConfiguration(classes = {IARestFailQueueHandlerRouteTest.TestConfig.class}, loader = CamelSpringDelegatingTestContextLoader.class)
@DisableJmx(false)
public class IARestFailQueueHandlerRouteTest {

	private static final Logger LOG = LoggerFactory.getLogger(IARestFailQueueHandlerRouteTest.class);

	// Constants
	private static final String ROUTECONFIG = "src/test/resources/config/route_config.xml";
	private static final String ROUTESCHEMA = "src/main/resources/config/route_config.xsd";
	private static final String IA_USER = "sue@iacustomer.com";
	private static final String IA_PASSWD = "password";
	//	    private static final String TESTFILE = "sample/eas_archive_documentum_32-SAPMIF-2016-Q1-2016-09-09-HKC_1.zip";
	private static final String TESTFILE = "sample/PhoneCallsSample-2001.zip";

	// Camel stuff...
	@EndpointInject(uri = "mock:" + IAIngestServiceRoute.INGEST_SERVICE_URI)
	public MockEndpoint result;
	
	@Produce(uri = IAIngestServiceRoute.REINGEST_QUEUE_URI)
	public ProducerTemplate template; 
	
	@Configuration
	@ComponentScan({"com.teliasonera.eias.autoingest.processor", "com.teliasonera.eias.autoingest.common", "com.teliasonera.eias.autoingest.beans.email"})
	@PropertySources({ @PropertySource("classpath:/config/autoingest.properties") })
	public static class TestConfig extends SingleRouteCamelConfiguration {

		@Bean
		@Override
		public RouteBuilder route() {

			RouteBuilder out = null;

			try {
				TestConfigFactory fact = new TestConfigFactory(new File(ROUTESCHEMA), new File(ROUTECONFIG));
				out = new IAReingestQueueHandlerRoute(fact.getRestConfig());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return out;
		}

		@Bean
		@Override
		public CamelContext camelContext() throws Exception {
			CamelContext ctx = super.camelContext();
			ctx.addComponent("activemq", ActiveMQComponent.activeMQComponent("vm://localhost?broker.persistent=false"));
			return ctx;
		}
	}
	

	@Before
	public void setUp() throws Exception {
	}

	@Test
	@DirtiesContext
	public final void testErrorRoute() throws Exception {
		
		Exchange exc = template.getDefaultEndpoint().createExchange();
		
		InputStream str = new FileInputStream(new File(TESTFILE));
		
		exc.getIn().setHeader(IAConstants.IA_APP_NAME, "PhoneCalls");
		exc.getIn().setHeader(IAConstants.IA_TENANT_NAME, "INFOARCHIVE");
		exc.getIn().setHeader(IAConstants.IA_USERNAME, IA_USER);
		exc.getIn().setHeader(IAConstants.IA_PASSWORD, IA_PASSWD);
		exc.getIn().setHeader(Exchange.FILE_NAME, "filename.zip");
		exc.getIn().setBody(str);
		
		LOG.debug("Processing file: " + exc.getIn().getHeader("CamelFileName"));
		
		this.template.send(exc);
		
		Thread.sleep(5000L);
		
		str.close();
		
		result.assertIsSatisfied();
	}
}

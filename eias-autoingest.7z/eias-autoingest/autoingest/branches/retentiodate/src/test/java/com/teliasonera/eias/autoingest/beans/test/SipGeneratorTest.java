package com.teliasonera.eias.autoingest.beans.test;

//import static org.junit.Assert.*;
//import static org.mockito.Mockito.*;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.teliasonera.eias.autoingest.beans.sip.SIPGenerator;
import com.teliasonera.eias.autoingest.routeconfig.RouteType;
import com.teliasonera.eias.autoingest.testutils.TestConfigFactory;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SipGeneratorTest.TestConfig.class})
public class SipGeneratorTest {
	
	private static final Logger LOG = LoggerFactory.getLogger(SipGeneratorTest.class);

    private static final String CONFIG = "src/test/resources/config/route_config.xml";
    private static final String CONFIG_XSD = "src/main/resources/config/route_config.xsd";
    private static final String TEST_SRC = "src/test/resources/sip_generation";
    private static final String TEST_SRC2 = "src/test/resources/sip_generation_recovery";

    @Configuration
    @ComponentScan({"com.teliasonera.eias.autoingest.processor", "com.teliasonera.eias.autoingest.common", 
    	"com.teliasonera.eias.autoingest.beans.sip", "com.teliasonera.eias.autoingest.beans.xml"})
    public static class TestConfig {
    	@Bean
    	public ThreadPoolTaskExecutor taskExecutor() {
    		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    		executor.setCorePoolSize(5);
    		executor.setMaxPoolSize(10);
    		executor.setThreadNamePrefix("SipProcessing - ");
    		return executor;
    	}
    }
    
    private RouteType config;

    // Class under test
    @Autowired
    private SIPGenerator gen;

    @Before
    public void setUp() throws Exception {
    	
    	
        TestConfigFactory fact = new TestConfigFactory(new File(CONFIG_XSD), new File(CONFIG));
        this.config = fact.getRoute("tsops");
    }

    @Test
    public final void testGenerateSIPs() throws Exception {

        this.testSetup(TEST_SRC);

        this.gen.setConfig(this.config);

        this.gen.generateSIPs();
        
        Thread.sleep(3000L);
    }

    @Test
    public final void testGenerateSIPsRecovery() throws Exception {

        this.testSetup(TEST_SRC2);

        this.gen.setConfig(this.config);

        this.gen.generateSIPs();
        
        Thread.sleep(3000L);
    }

    private final void testSetup(String srcPath) throws Exception {
    	
        File sourceDir = new File(srcPath);
        File testDir = new File(this.config.getSipProcessorWorkDirEndpoint().getName());

        LOG.info("Using source data dir: " + sourceDir.getPath());
        LOG.info("Setting up test dir: " + testDir.getPath());
        
        if (testDir.exists()) {
        	LOG.info("Cleaning test dir...");
            FileUtils.cleanDirectory(testDir);
        }

        FileUtils.copyDirectory(sourceDir, testDir);
    }
}

package com.teliasonera.eias.autoingest.beans.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.teliasonera.eias.autoingest.beans.sip.PDICreator;

@RunWith(Suite.class)
@SuiteClasses({RouteConfigFactoryTest.class, RouteConfigManagerTest.class, XMLTransformerTest.class, XMLValidatorTest.class, XPathQueryUtilTest.class,
               SipGeneratorTest.class, ContentFileLinkerTest.class})
public class AllTests {

}

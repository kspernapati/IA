package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.xml.bind.UnmarshalException;
import javax.xml.validation.Schema;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.xml.sax.SAXParseException;

import com.teliasonera.eias.autoingest.beans.routemgmt.RouteConfigFactory;
import com.teliasonera.eias.autoingest.beans.xml.XMLValidator;
import com.teliasonera.eias.autoingest.routeconfig.RouteConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:test_context/camel-context_autowired.xml"})
public class RouteConfigFactoryTest {

    // Object under test
    @InjectMocks
    private RouteConfigFactory factory;

    @Mock
    private XMLValidator validator;

    @Autowired
    private XMLValidator val;

    private Schema schema;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private static final String BASEDIR = "src/test/resources/";
    private static final String TEST_FILE = BASEDIR + "config/route_config.xml";
    private static final String TEST_FILE_INVALID = BASEDIR + "config/route_config_invalid.xml";
    private static final String TEST_FILE_INVALID2 = BASEDIR + "config/route_config_invalid2.xml";
    private static final String TEST_SCHEMA = "src/main/resources/config/route_config.xsd";

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        this.schema = this.val.getSchema(new File(TEST_SCHEMA));

        // Mock behaviour
        when(this.validator.getSchema(any(File.class))).thenReturn(this.schema);
        when(this.validator.getSchema(any(InputStream.class))).thenReturn(this.schema);
    }

    @Test
    public final void testGetRouteConfig1() throws Exception {

        RouteConfig cfg = this.factory.getRouteConfig(new File(TEST_SCHEMA), new File(TEST_FILE));

        assertNotNull("Null was returned!", cfg);
        assertNotNull("RouteConfig was not properly initialized", cfg.getRoute());
        assertFalse("No routes inside config object", cfg.getRoute().size() == 0);
    }

    @Test
    public final void testGetRouteConfig2() throws Exception {

        RouteConfig cfg = this.factory.getRouteConfig(new FileInputStream(new File(TEST_SCHEMA)), new FileInputStream(new File(TEST_FILE)));

        assertNotNull("Null was returned!", cfg);
        assertNotNull("RouteConfig was not properly initialized", cfg.getRoute());
        assertFalse("No routes inside config object", cfg.getRoute().size() == 0);
    }

    @Test
    public final void testGetRouteConfigInvalidSchema() throws Exception {

        // Override default mock behavior
        when(this.validator.getSchema(any(File.class))).thenReturn(null);

        RouteConfig cfg = this.factory.getRouteConfig(new File(TEST_SCHEMA), new File(TEST_FILE));

        assertNotNull("Null was returned!", cfg);
        assertNotNull("RouteConfig was not properly initialized", cfg.getRoute());
        assertFalse("No routes inside config object", cfg.getRoute().size() == 0);
    }

    @Test
    public final void testGetRouteConfigInvalidFile() throws Exception {

        thrown.expect(UnmarshalException.class);
        thrown.expectCause(org.hamcrest.CoreMatchers.any(SAXParseException.class));

        this.factory.getRouteConfig(new File(TEST_SCHEMA), new File(TEST_FILE_INVALID));

        fail("No exception was thrown!");
    }

    @Test
    public final void testGetRouteConfigInvalidFileDuplicateRoutes() throws Exception {

        thrown.expect(UnmarshalException.class);
        thrown.expectCause(org.hamcrest.CoreMatchers.any(SAXParseException.class));

        this.factory.getRouteConfig(new File(TEST_SCHEMA), new File(TEST_FILE_INVALID2));

        fail("No exception was thrown!");
    }

    @Test
    public final void testGetRouteConfigNullInput1() throws Exception {

        File f1 = null;
        File f2 = null;

        thrown.expect(FileNotFoundException.class);

        this.factory.getRouteConfig(f1, f2);

        fail("No exception was thrown!");
    }

    @Test
    public final void testGetRouteConfigNullInput2() throws Exception {

        InputStream i1 = null;
        InputStream i2 = null;

        thrown.expect(IllegalArgumentException.class);

        this.factory.getRouteConfig(i1, i2);

        fail("No exception was thrown!");
    }
}

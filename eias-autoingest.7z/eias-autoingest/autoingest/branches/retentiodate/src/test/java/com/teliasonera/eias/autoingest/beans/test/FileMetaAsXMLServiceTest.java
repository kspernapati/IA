package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import java.io.ByteArrayOutputStream;
import java.io.File;

import javax.xml.transform.TransformerFactory;
import javax.xml.validation.SchemaFactory;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.teliasonera.eias.autoingest.beans.xml.FileMetaAsXMLService;

import net.sf.saxon.lib.NamespaceConstant;
import net.sf.saxon.xpath.XPathFactoryImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {FileMetaAsXMLServiceTest.TestConfig.class})
public class FileMetaAsXMLServiceTest {
	
	@Configuration
	@ComponentScan({"com.teliasonera.eias.autoingest.beans.xml"})
	public static class TestConfig {
		/** 
		 * 	Beans used by XML processors
		 */
		
		@Bean
		@Scope("singleton")
		@Autowired
		public TransformerFactory transformerFactory() {
			System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
			return TransformerFactory.newInstance();
		}
		
		@Bean
		@Scope("singleton")
		@Autowired
		public SchemaFactory schemaFactory() {
			System.setProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema", "com.saxonica.ee.jaxp.SchemaFactoryImpl");
			return SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
		}
		
		@Bean
		@Scope("singleton")
		@Autowired
		public XPathFactory xpathFactory() throws XPathFactoryConfigurationException {
			System.setProperty("javax.xml.xpath.XPathFactory:" + NamespaceConstant.OBJECT_MODEL_SAXON, "net.sf.saxon.xpath.XPathFactoryImpl");
			return XPathFactoryImpl.newInstance(NamespaceConstant.OBJECT_MODEL_SAXON);
		}
	}
	
	private static final String TEST_FILE = "src/test/resources/sip_generation/TSOPS_20160317_000003_117_234_F_bw.tif";
//	private static final String BASE_DIR = "src/test";
	private static final String BASE_DIR = "C:/Work/JavaDev/temp/eias-autoingest-spring-boot/src/test";

	// Class under test
	@Autowired
	private FileMetaAsXMLService service;
	
	@Test
	public void testGetMetainfoAsXMLStream() throws Exception {
		
		File file = new File(TEST_FILE);
		File baseDir = new File(BASE_DIR);
		
		ByteArrayOutputStream str = this.service.getMetainfoAsXMLStream(file, baseDir, "path/path2");
		
		assertNotNull(str);
		
		String xml = str.toString("UTF-8");
		
		assertThat(xml.length(), is(not(0)));
		
		System.out.println(xml);
	}

}

package com.teliasonera.eias.autoingest.beans.test;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.xml.transform.TransformerFactory;
import javax.xml.validation.SchemaFactory;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.teliasonera.eias.autoingest.beans.xml.XPathQueryUtil;

import net.sf.saxon.lib.NamespaceConstant;
import net.sf.saxon.xpath.XPathFactoryImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {XPathQueryUtilTest.TestConfig.class})
public class XPathQueryUtilTest {

	@Configuration
    @ComponentScan({"com.teliasonera.eias.autoingest.common", "com.teliasonera.eias.autoingest.beans.xml"})
    public static class TestConfig {
    	    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public TransformerFactory transformerFactory() {
    		System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
    		return TransformerFactory.newInstance();
    	}
    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public SchemaFactory schemaFactory() {
    		System.setProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema", "com.saxonica.ee.jaxp.SchemaFactoryImpl");
    		return SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
    	}
    	
    	@Bean
    	@Scope("singleton")
    	@Autowired
    	public XPathFactory xpathFactory() throws XPathFactoryConfigurationException {
    		System.setProperty("javax.xml.xpath.XPathFactory:" + NamespaceConstant.OBJECT_MODEL_SAXON, "net.sf.saxon.xpath.XPathFactoryImpl");
    		return XPathFactoryImpl.newInstance(NamespaceConstant.OBJECT_MODEL_SAXON);
    	}
    }
	
    // Object under test
    @Autowired
    private XPathQueryUtil xpUtil;

    private static final String TEST_FILE = "src/test/resources/validation_files/TSOPS_20160317_000003_117_234_F_bw.xml";
    private static final String XPATH = "/DOCUMENT/BUNDLE/FILENAME";

    @Test
    public final void testQueryDocument() throws Exception {

        InputStream str = new FileInputStream(new File(TEST_FILE));

        String out = this.xpUtil.queryDocument(str, XPATH);

        assertEquals("Incorrect response from query!", "TSOPS_20160317_000003_117_234_F_bw.tif", out);
    }

}
